# Routebook

Load named route destinations from JSON using only the Python standard library.

## Python API

```python
from routebook import load_routes, load_routes_text

routes = load_routes('config.json')
routes_from_text = load_routes_text(
    '{"include": "defaults.json", "routes": {"home": "/home"}}',
    base_dir='.',
)
```

Both functions return a dictionary of route names to destinations and share the
same loading and validation logic. The existing `load_routes(path)` API accepts
a string or `pathlib.Path`. `load_routes_text(text, *, base_dir)` requires a
keyword-only base directory (a string or `pathlib.Path`) for includes in the text.

## Configuration and includes

Every configuration must be a JSON object containing a `routes` object, even when
it includes another file. Route names and destinations must be strings; an empty
`routes` object is allowed.

For example, `defaults.json`:

```json
{"routes": {"home": "/default", "help": "/help"}}
```

And `config.json` in the same directory:

```json
{"include": "defaults.json", "routes": {"home": "/home"}}
```

Loading `config.json` returns `{"home": "/home", "help": "/help"}`. Each file
loads its include recursively, then overrides inherited routes with its own.
The optional `include` must be a nonempty relative filename; absolute paths are
rejected. Paths such as `nested/defaults.json` and `../defaults.json` are resolved
relative to the containing file. For text input, the first include is relative to
`base_dir`; subsequent includes are relative to their containing files.

Cycles are detected using resolved paths, including symbolic links, and raise
`ValueError` with `cycle` in the message. Distinct files with the same basename
are allowed. Missing files raise `FileNotFoundError`. Invalid JSON or malformed
configuration structures raise `ValueError`, including errors in included files.

## CLI

```sh
python3 -m routebook config.json
python3 -m routebook --stdin < config.json
```

Both modes emit a JSON object with sorted keys and a trailing newline on stdout.
File mode resolves includes relative to the config file. `--stdin` reads JSON
from standard input and resolves the first include from the current working
directory, regardless of where a redirected input file lives.

Provide exactly one input source: either a positional config path or `--stdin`.
Combining them, or providing neither, is an argparse usage error (exit status 2).

## Tests

Run the API and CLI regression suite with `python3 -m unittest -v`.
