import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

from routebook import load_routes, load_routes_text


PROJECT_ROOT = Path(__file__).resolve().parent


class RouteTests(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory(
            prefix='.routebook-tests-', dir=PROJECT_ROOT
        )
        self.addCleanup(temporary.cleanup)
        self.folder = Path(temporary.name)

    def write_config(self, name, data):
        path = self.folder / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(data))
        return path

    def loaders(self, path):
        return (
            ('file', lambda: load_routes(path)),
            ('text', lambda: load_routes_text(
                path.read_text(), base_dir=path.parent
            )),
        )

    def test_legacy(self):
        path = self.write_config(
            'routes.json', {'routes': {'home': 'https://example.invalid'}}
        )
        for source in (path, str(path)):
            with self.subTest(source=source):
                self.assertEqual(
                    load_routes(source), {'home': 'https://example.invalid'}
                )

    def test_text_without_includes(self):
        self.assertEqual(
            load_routes_text(
                '{"routes": {"home": "https://example.invalid"}}',
                base_dir=str(self.folder),
            ),
            {'home': 'https://example.invalid'},
        )

    def test_empty_routes(self):
        path = self.write_config('routes.json', {'routes': {}})
        for source, load in self.loaders(path):
            with self.subTest(source=source):
                self.assertEqual(load(), {})

    def test_recursive_includes_and_local_overrides(self):
        self.write_config('base.json', {'routes': {
            'base_only': '/base', 'shared': '/base', 'middle_wins': '/base',
        }})
        self.write_config('nested/middle.json', {
            'include': '../base.json',
            'routes': {'shared': '/middle', 'middle_wins': '/middle'},
        })
        path = self.write_config('routes.json', {
            'include': 'nested/middle.json',
            'routes': {'shared': '/local', 'local_only': '/local'},
        })
        expected = {
            'base_only': '/base', 'shared': '/local',
            'middle_wins': '/middle', 'local_only': '/local',
        }
        for source, load in self.loaders(path):
            with self.subTest(source=source):
                self.assertEqual(load(), expected)

    def test_empty_local_routes_preserve_inherited_routes(self):
        self.write_config('base.json', {'routes': {'home': '/home'}})
        path = self.write_config('routes.json', {
            'include': 'base.json', 'routes': {},
        })
        for source, load in self.loaders(path):
            with self.subTest(source=source):
                self.assertEqual(load(), {'home': '/home'})

    def test_same_basename_is_not_a_cycle(self):
        self.write_config('nested/routes.json', {'routes': {'home': '/home'}})
        path = self.write_config('routes.json', {
            'include': 'nested/routes.json', 'routes': {},
        })
        for source, load in self.loaders(path):
            with self.subTest(source=source):
                self.assertEqual(load(), {'home': '/home'})
                self.assertEqual(load(), {'home': '/home'})

    def test_direct_cycle(self):
        path = self.write_config('routes.json', {
            'include': './routes.json', 'routes': {},
        })
        for source, load in self.loaders(path):
            with self.subTest(source=source):
                with self.assertRaisesRegex(ValueError, 'cycle'):
                    load()

    def test_indirect_cycle_with_parent_path(self):
        path = self.write_config('routes.json', {
            'include': 'nested/next.json', 'routes': {},
        })
        self.write_config('nested/next.json', {
            'include': '../routes.json', 'routes': {},
        })
        for source, load in self.loaders(path):
            with self.subTest(source=source):
                with self.assertRaisesRegex(ValueError, 'cycle'):
                    load()

    def test_cycle_through_symlink(self):
        path = self.write_config('routes.json', {
            'include': 'alias.json', 'routes': {},
        })
        try:
            (self.folder / 'alias.json').symlink_to(path.name)
        except (OSError, NotImplementedError) as error:
            self.skipTest(f'symlinks unavailable: {error}')
        for source, load in self.loaders(path):
            with self.subTest(source=source):
                with self.assertRaisesRegex(ValueError, 'cycle'):
                    load()

    def test_missing_files(self):
        with self.assertRaises(FileNotFoundError):
            load_routes(self.folder / 'missing.json')
        self.write_config('middle.json', {
            'include': 'missing.json', 'routes': {},
        })
        path = self.write_config('routes.json', {
            'include': 'middle.json', 'routes': {},
        })
        for source, load in self.loaders(path):
            with self.subTest(source=source):
                with self.assertRaises(FileNotFoundError):
                    load()

    def test_invalid_structures(self):
        invalid = [None, [], 'text', 1, True, {}]
        invalid.extend({'routes': value} for value in (
            None, [], 'text', 1, True,
        ))
        invalid.extend({'routes': {'home': value}} for value in (
            None, [], {}, 1, True,
        ))
        for data in invalid:
            path = self.write_config('routes.json', data)
            for source, load in self.loaders(path):
                with self.subTest(data=data, source=source):
                    with self.assertRaises(ValueError):
                        load()

    def test_invalid_includes(self):
        for include in ('', None, 1, False, [], {}, str(self.folder / 'base.json')):
            path = self.write_config('routes.json', {
                'include': include, 'routes': {},
            })
            for source, load in self.loaders(path):
                with self.subTest(include=include, source=source):
                    with self.assertRaises(ValueError):
                        load()

    def test_routes_required_even_with_include(self):
        self.write_config('base.json', {'routes': {'home': '/home'}})
        path = self.write_config('routes.json', {'include': 'base.json'})
        for source, load in self.loaders(path):
            with self.subTest(source=source):
                with self.assertRaises(ValueError):
                    load()

    def test_invalid_included_structures_cannot_be_overridden(self):
        path = self.write_config('routes.json', {
            'include': 'base.json', 'routes': {'home': '/valid'},
        })
        for included in ([], {}, {'routes': {'home': 42}}):
            self.write_config('base.json', included)
            for source, load in self.loaders(path):
                with self.subTest(included=included, source=source):
                    with self.assertRaises(ValueError):
                        load()

    def test_malformed_json(self):
        path = self.folder / 'routes.json'
        path.write_text('{broken json')
        for source, load in self.loaders(path):
            with self.subTest(source=source):
                with self.assertRaises(ValueError):
                    load()
        wrapper = self.write_config('wrapper.json', {
            'include': 'routes.json', 'routes': {},
        })
        for source, load in self.loaders(wrapper):
            with self.subTest(source=source, included=True):
                with self.assertRaises(ValueError):
                    load()

    def run_cli(self, *args, stdin=''):
        return subprocess.run(
            [sys.executable, '-m', 'routebook', *args],
            input=stdin, text=True, capture_output=True, cwd=self.folder,
            env={**os.environ, 'PYTHONPATH': str(PROJECT_ROOT)}, timeout=10,
        )

    def test_file_cli_output_compatible(self):
        self.write_config('routes.json', {'routes': {'z': '/z', 'a': '/a'}})
        result = self.run_cli('routes.json')
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(result.stdout, '{"a": "/a", "z": "/z"}\n')
        self.assertEqual(result.stderr, '')

    def test_file_cli_resolves_include_from_config_directory(self):
        self.write_config('nested/base.json', {'routes': {'home': '/nested'}})
        self.write_config('nested/routes.json', {
            'include': 'base.json', 'routes': {},
        })
        self.write_config('base.json', {'routes': {'home': '/wrong'}})
        result = self.run_cli('nested/routes.json')
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(json.loads(result.stdout), {'home': '/nested'})

    def test_stdin_cli_resolves_nested_includes_from_cwd(self):
        self.write_config('base.json', {'routes': {'home': '/base', 'a': '/a'}})
        self.write_config('nested/middle.json', {
            'include': '../base.json', 'routes': {'home': '/middle'},
        })
        result = self.run_cli('--stdin', stdin=json.dumps({
            'include': 'nested/middle.json', 'routes': {'home': '/stdin'},
        }))
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(result.stdout, '{"a": "/a", "home": "/stdin"}\n')
        self.assertEqual(result.stderr, '')

    def test_stdin_cli_without_includes(self):
        result = self.run_cli('--stdin', stdin='{"routes": {}}')
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(result.stdout, '{}\n')

    def test_cli_requires_exactly_one_input_source(self):
        for args in ((), ('--stdin', 'missing.json'), ('missing.json', '--stdin')):
            with self.subTest(args=args):
                result = self.run_cli(*args, stdin='not JSON')
                self.assertEqual(result.returncode, 2, result.stderr)
                self.assertIn('usage:', result.stderr)
                self.assertNotIn('Traceback', result.stderr)
                self.assertEqual(result.stdout, '')


if __name__ == '__main__':
    unittest.main()
