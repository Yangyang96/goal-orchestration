import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

from routebook import load_routes, load_routes_text


class ConfigTestCase(unittest.TestCase):
    def setUp(self):
        folder = tempfile.TemporaryDirectory(dir=Path(__file__).resolve().parent)
        self.addCleanup(folder.cleanup)
        self.base_dir = Path(folder.name)

    def write_config(self, name, data):
        path = self.base_dir / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(data))
        return path

    def load_config(self, data, source):
        if source == 'text':
            return load_routes_text(json.dumps(data), base_dir=self.base_dir)
        return load_routes(self.write_config('config.json', data))


class RouteTests(ConfigTestCase):
    def test_legacy(self):
        path = self.write_config('routes.json', {'routes': {'home': 'https://example.invalid'}})
        self.assertEqual(load_routes(path), {'home': 'https://example.invalid'})

    def test_text_without_include(self):
        self.assertEqual(
            load_routes_text('{"routes": {"home": "/home"}}',
                             base_dir=str(self.base_dir)),
            {'home': '/home'},
        )

    def test_text_requires_keyword_only_base_dir(self):
        with self.assertRaises(TypeError):
            load_routes_text('{"routes": {}}')
        with self.assertRaises(TypeError):
            load_routes_text('{"routes": {}}', self.base_dir)

    def test_empty_routes(self):
        for source in ('file', 'text'):
            with self.subTest(source=source):
                self.assertEqual(self.load_config({'routes': {}}, source), {})

    def test_nested_include_and_local_overrides(self):
        self.write_config('shared/routes.json', {
            'routes': {'shared': '/shared', 'home': '/default', 'help': '/help'},
        })
        self.write_config('nested/routes.json', {
            'include': '../shared/routes.json',
            'routes': {'nested': '/nested', 'home': '/nested-home', 'help': '/nested-help'},
        })
        data = {'include': 'nested/routes.json', 'routes': {'home': '/首页'}}
        expected = {
            'shared': '/shared', 'nested': '/nested',
            'home': '/首页', 'help': '/nested-help',
        }
        for source in ('file', 'text'):
            with self.subTest(source=source):
                self.assertEqual(self.load_config(data, source), expected)

    def test_distinct_files_with_same_basename_are_not_cycles(self):
        self.write_config('nested/config.json', {'routes': {'included': '/included'}})
        data = {'include': 'nested/config.json', 'routes': {}}
        for source in ('file', 'text'):
            with self.subTest(source=source):
                self.assertEqual(self.load_config(data, source), {'included': '/included'})

    def test_cycles(self):
        (self.base_dir / 'nested').mkdir()
        cases = {
            'self': {'include': 'a.json', 'routes': {}},
            'resolved_alias': {'include': 'nested/../a.json', 'routes': {}},
            'indirect': {'include': 'nested/b.json', 'routes': {}},
        }
        self.write_config('nested/b.json', {'include': '../a.json', 'routes': {}})
        for name, data in cases.items():
            self.write_config('a.json', data)
            for source in ('file', 'text'):
                with self.subTest(cycle=name, source=source):
                    with self.assertRaisesRegex(ValueError, 'cycle'):
                        self.load_config({'include': 'a.json', 'routes': {}}, source)

    def test_symlink_cycle(self):
        self.write_config('a.json', {'include': 'alias.json', 'routes': {}})
        try:
            (self.base_dir / 'alias.json').symlink_to('a.json')
        except (OSError, NotImplementedError) as error:
            self.skipTest(f'symlinks unavailable: {error}')
        for source in ('file', 'text'):
            with self.subTest(source=source):
                with self.assertRaisesRegex(ValueError, 'cycle'):
                    self.load_config({'include': 'a.json', 'routes': {}}, source)

    def test_missing_root_file(self):
        with self.assertRaises(FileNotFoundError):
            load_routes(str(self.base_dir / 'missing.json'))

    def test_missing_nested_include(self):
        self.write_config('nested/routes.json', {'include': 'missing.json', 'routes': {}})
        data = {'include': 'nested/routes.json', 'routes': {}}
        for source in ('file', 'text'):
            with self.subTest(source=source):
                with self.assertRaises(FileNotFoundError):
                    self.load_config(data, source)

    def test_invalid_structures(self):
        invalid_configs = [
            None, [], 'config', 12, True, {},
            {'routes': None}, {'routes': []}, {'routes': 'routes'},
            {'routes': 1}, {'routes': False},
            *({'routes': {'home': value}} for value in (None, 1, True, [], {})),
            *({'routes': {}, 'include': value}
              for value in ('', None, False, 1, [], {})),
            {'routes': {}, 'include': str(self.base_dir / 'absolute.json')},
        ]
        for data in invalid_configs:
            for source in ('file', 'text'):
                with self.subTest(data=data, source=source):
                    with self.assertRaises(ValueError):
                        self.load_config(data, source)

    def test_include_does_not_replace_required_routes(self):
        self.write_config('defaults.json', {'routes': {'home': '/home'}})
        for source in ('file', 'text'):
            with self.subTest(source=source):
                with self.assertRaises(ValueError):
                    self.load_config({'include': 'defaults.json'}, source)

    def test_invalid_included_structure_even_when_locally_overridden(self):
        for included in ({}, {'routes': {'home': 42}}):
            self.write_config('defaults.json', included)
            for source in ('file', 'text'):
                with self.subTest(included=included, source=source):
                    with self.assertRaises(ValueError):
                        self.load_config({
                            'include': 'defaults.json', 'routes': {'home': '/valid'},
                        }, source)

    def test_invalid_json(self):
        path = self.base_dir / 'invalid.json'
        path.write_text('{invalid json')
        with self.assertRaises(ValueError):
            load_routes(path)
        with self.assertRaises(ValueError):
            load_routes_text(path.read_text(), base_dir=self.base_dir)
        for source in ('file', 'text'):
            with self.subTest(source=source):
                with self.assertRaises(ValueError):
                    self.load_config({'include': 'invalid.json', 'routes': {}}, source)


class CLITests(ConfigTestCase):
    def run_cli(self, *args, stdin=''):
        env = os.environ.copy()
        project_dir = str(Path(__file__).resolve().parent)
        env['PYTHONPATH'] = os.pathsep.join(filter(None, [project_dir, env.get('PYTHONPATH')]))
        return subprocess.run(
            [sys.executable, '-m', 'routebook', *args],
            input=stdin, text=True, capture_output=True,
            cwd=self.base_dir, env=env, timeout=10,
        )

    def test_file_output_stays_compatible(self):
        self.write_config('config.json', {'routes': {'z': '/z', 'a': '/a'}})
        result = self.run_cli('config.json')
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(result.stdout, '{"a": "/a", "z": "/z"}\n')
        self.assertEqual(result.stderr, '')

    def test_file_include_is_relative_to_config(self):
        self.write_config('configs/defaults.json', {'routes': {'home': '/default', 'help': '/help'}})
        self.write_config('configs/config.json', {
            'include': 'defaults.json', 'routes': {'home': '/local'},
        })
        result = self.run_cli('configs/config.json')
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(json.loads(result.stdout), {'home': '/local', 'help': '/help'})

    def test_stdin_without_include(self):
        result = self.run_cli('--stdin', stdin='{"routes": {"z": "/z", "a": "/a"}}')
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(result.stdout, '{"a": "/a", "z": "/z"}\n')
        self.assertEqual(result.stderr, '')

    def test_stdin_resolves_nested_includes_from_cwd(self):
        self.write_config('nested/shared.json', {'routes': {'help': '/help', 'home': '/default'}})
        self.write_config('nested/routes.json', {
            'include': 'shared.json', 'routes': {'nested': '/nested'},
        })
        result = self.run_cli('--stdin', stdin=json.dumps({
            'include': 'nested/routes.json', 'routes': {'home': '/local'},
        }))
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(json.loads(result.stdout), {
            'home': '/local', 'help': '/help', 'nested': '/nested',
        })
        self.assertEqual(result.stderr, '')

    def test_invalid_argument_combinations_are_usage_errors(self):
        for args in ((), ('--stdin', 'config.json'), ('config.json', '--stdin')):
            with self.subTest(args=args):
                result = self.run_cli(*args)
                self.assertEqual(result.returncode, 2)
                self.assertIn('usage:', result.stderr)
                self.assertNotIn('Traceback', result.stderr)
                self.assertEqual(result.stdout, '')


if __name__ == '__main__':
    unittest.main()
