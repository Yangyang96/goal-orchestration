# Routebook

Load a route table from JSON using only the Python standard library.

## Configuration

Every configuration must be a JSON object with a `routes` object, including files
that only include another configuration (use `"routes": {}`). Route names and
destinations must be strings.

```json
{
  "include": "defaults/routes.json",
  "routes": {
    "home": "https://example.invalid",
    "help": "https://example.invalid/help"
  }
}
```

The optional `include` must be a nonempty relative filename; absolute paths are
rejected. Includes are loaded recursively relative to the file containing them.
Local routes override included routes with the same name, while other included
routes are retained. Parent-relative paths such as `../shared/routes.json` work.

Cycles are detected using resolved paths, including symbolic links, and raise
`ValueError` with `cycle` in the message. Separate files with the same basename
are allowed. Missing files raise `FileNotFoundError`; invalid JSON or malformed
configuration structures raise `ValueError`, including in an included file.

## Python API

```python
from routebook import load_routes, load_routes_text

routes = load_routes('config.json')
routes = load_routes_text(
    '{"include": "defaults/routes.json", "routes": {"home": "/home"}}',
    base_dir='configs',
)
```

Both functions return a dictionary of route names to destinations and share the
same loading and validation logic. `load_routes(path)` retains the existing file
API and accepts a string or `pathlib.Path`.

`load_routes_text(text, *, base_dir)` takes JSON text and requires the keyword-only
`base_dir` (a string or `pathlib.Path`) for resolving the text's include. Each
included file then resolves its own include relative to its containing directory.

## CLI

```sh
python3 -m routebook config.json
cat config.json | python3 -m routebook --stdin
```

Both modes emit a JSON object with sorted keys on stdout. `--stdin` reads JSON
from standard input and resolves its first include from the current working
directory, regardless of where the input originated. Use exactly one of a config
filename or `--stdin`. Providing both or neither is an argparse usage error
(exit status 2).

## Tests

Run `python3 -m unittest -v`. Python cache files are ignored by Git.
