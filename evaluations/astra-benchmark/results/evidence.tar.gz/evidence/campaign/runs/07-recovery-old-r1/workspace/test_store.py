import sqlite3
import tempfile
import unittest
from pathlib import Path

from store import connect, import_events, list_events


class StoreTests(unittest.TestCase):
    def setUp(self):
        self.db = connect(':memory:')
        self.addCleanup(self.db.close)

    def test_fresh_database(self):
        self.assertEqual(import_events(self.db, [{'id': 'a', 'payload': 'value'}]), 1)
        self.assertEqual(list_events(self.db), [('a', 'value', 'legacy')])

    def test_legacy_database_migrates_in_place_and_reopens(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as folder:
            path = Path(folder) / 'events.db'
            old = sqlite3.connect(path)
            try:
                old.execute('CREATE TABLE events (id TEXT PRIMARY KEY, payload TEXT NOT NULL)')
                old.executemany('INSERT INTO events VALUES (?, ?)',
                                [('old-1', 'existing'), ('old-2', 'preserved')])
                old.execute('CREATE TABLE unrelated (value TEXT)')
                old.execute("INSERT INTO unrelated VALUES ('untouched')")
                old.commit()
            finally:
                old.close()

            expected = [('old-1', 'existing', 'legacy'), ('old-2', 'preserved', 'legacy')]
            for _ in range(2):
                db = connect(path)
                try:
                    self.assertEqual(list_events(db), expected)
                    self.assertEqual(db.execute('SELECT value FROM unrelated').fetchall(),
                                     [('untouched',)])
                    self.assertEqual(import_events(db, [{'id': 'old-1', 'payload': 'existing'}]), 0)
                finally:
                    db.close()

            db = connect(path)
            try:
                self.assertEqual(import_events(db, [{'id': 'new-1', 'payload': 'hello',
                                                     'source': 'queue'}]), 1)
                # The migrated schema must also supply the default to SQL callers.
                db.execute("INSERT INTO events (id, payload) VALUES ('new-2', 'default')")
                db.commit()
            finally:
                db.close()

            db = connect(path)
            try:
                self.assertEqual(list_events(db), [('new-1', 'hello', 'queue'),
                                                   ('new-2', 'default', 'legacy')] + expected)
            finally:
                db.close()

    def test_retries_and_in_batch_duplicates_count_only_new_records(self):
        old = {'id': 'a', 'payload': 'value'}
        new = {'id': 'b', 'payload': 'next', 'source': 'queue'}
        self.assertEqual(import_events(self.db, [old]), 1)
        batch = [old, new, dict(new), dict(old, source='legacy')]
        self.assertEqual(import_events(self.db, iter(batch)), 1)
        self.assertEqual(import_events(self.db, batch), 0)
        self.assertEqual(list_events(self.db), [('a', 'value', 'legacy'), ('b', 'next', 'queue')])
        self.assertFalse(self.db.in_transaction)

    def test_empty_batch(self):
        self.assertEqual(import_events(self.db, iter(())), 0)
        self.assertEqual(list_events(self.db), [])
        self.assertFalse(self.db.in_transaction)

    def assert_batch_rollback(self, batch, error_type=ValueError):
        before = list_events(self.db)
        with self.assertRaises(error_type):
            import_events(self.db, batch)
        self.assertEqual(list_events(self.db), before)
        self.assertFalse(self.db.in_transaction)
        self.assertEqual(import_events(self.db, [{'id': 'later', 'payload': 'works'}]), 1)
        self.assertEqual(list_events(self.db), sorted(before + [('later', 'works', 'legacy')]))
        # Keep the connection usable for subsequent subtests as well.
        with self.db:
            self.db.execute("DELETE FROM events WHERE id = 'later'")

    def test_conflicting_existing_record_rolls_back_batch(self):
        existing = {'id': 'old', 'payload': 'original', 'source': 'queue'}
        import_events(self.db, [existing])
        for field, value in [('payload', 'changed'), ('source', 'other')]:
            with self.subTest(field=field):
                self.assert_batch_rollback([
                    {'id': 'new', 'payload': 'tentative'},
                    dict(existing),
                    dict(existing, **{field: value}),
                ])

    def test_conflicting_record_within_batch_rolls_back_batch(self):
        import_events(self.db, [{'id': 'old', 'payload': 'untouched'}])
        first = {'id': 'new', 'payload': 'original', 'source': 'queue'}
        for field, value in [('payload', 'changed'), ('source', 'other')]:
            with self.subTest(field=field):
                self.assert_batch_rollback([first, dict(first, **{field: value})])

    def test_invalid_fields_roll_back_batch(self):
        import_events(self.db, [{'id': 'old', 'payload': 'untouched'}])
        valid = {'id': 'invalid', 'payload': 'value', 'source': 'queue'}
        invalid_values = ['', None, 0, 1.5, False, b'bytes', [], {}]
        for field in ('id', 'payload', 'source'):
            for value in invalid_values:
                with self.subTest(field=field, value=value):
                    self.assert_batch_rollback([
                        {'id': 'new', 'payload': 'tentative'},
                        dict(valid, **{field: value}),
                    ])
        for field in ('id', 'payload'):
            with self.subTest(missing=field):
                event = dict(valid)
                del event[field]
                self.assert_batch_rollback([{'id': 'new', 'payload': 'tentative'}, event])

    def test_invalid_retry_is_validated_before_duplicate_comparison(self):
        import_events(self.db, [{'id': 'old', 'payload': 'untouched'}])
        self.assert_batch_rollback([{'id': 'old', 'payload': 'untouched', 'source': None}])

    def test_non_mapping_record_rolls_back_batch(self):
        import_events(self.db, [{'id': 'old', 'payload': 'untouched'}])
        for event in (None, 'event', 42, ['id', 'payload']):
            with self.subTest(event=event):
                self.assert_batch_rollback([{'id': 'new', 'payload': 'tentative'}, event])

    def test_generator_exception_rolls_back_batch(self):
        import_events(self.db, [{'id': 'old', 'payload': 'untouched'}])

        def broken_events():
            yield {'id': 'new-1', 'payload': 'tentative'}
            yield {'id': 'new-2', 'payload': 'tentative'}
            raise RuntimeError('input failed')

        self.assert_batch_rollback(broken_events(), RuntimeError)

    def test_database_error_rolls_back_batch(self):
        import_events(self.db, [{'id': 'old', 'payload': 'untouched'}])
        self.db.execute("""CREATE TRIGGER reject_event BEFORE INSERT ON events
                           WHEN NEW.id = 'rejected'
                           BEGIN SELECT RAISE(ABORT, 'rejected by store'); END""")
        self.assert_batch_rollback([
            {'id': 'new', 'payload': 'tentative'},
            {'id': 'rejected', 'payload': 'value'},
        ], sqlite3.IntegrityError)


if __name__ == '__main__':
    unittest.main()
