import unittest
from ledger import summarize, render

class LedgerTests(unittest.TestCase):
    def test_basic(self):
        self.assertEqual(summarize('customer,amount,status\nA,1.20,paid\nB,2,open\n'), {'A': 120})

    def test_render(self):
        self.assertEqual(render({'A': 120}), 'A\t120\n')

    def test_bom_whitespace_status_and_aggregation(self):
        text = (
            '\ufeff customer , amount , status , ignored \n'
            ' Zoe , 1.20 , PAID , extra\n'
            ' Alice , 2 , Paid , extra\n'
            'Zoe, .005 , pAiD , extra\n'
            'alice,1,paid,extra\n'
        )
        totals = summarize(text)
        self.assertEqual(totals, {'Alice': 200, 'Zoe': 121, 'alice': 100})
        self.assertEqual(list(totals), ['Alice', 'Zoe', 'alice'])
        self.assertEqual(render(totals), 'Alice\t200\nZoe\t121\nalice\t100\n')

    def test_rounds_each_row_half_up_including_refunds(self):
        amounts = {
            '0.005': 1, '-0.005': -1,
            '1.005': 101, '-1.005': -101,
            '2.675': 268, '-2.675': -268,
            '0.004': 0, '-0.004': 0,
            '5e-3': 1,
        }
        for amount, cents in amounts.items():
            with self.subTest(amount=amount):
                text = f'customer,amount,status\nA,{amount},paid\nA,{amount},paid\n'
                self.assertEqual(summarize(text), {'A': cents * 2})

    def test_decimal_precision(self):
        text = (
            'customer,amount,status\n'
            'A,1234567890123456789012345678.005,paid\n'
            'B,0.004999999999999999999999999999,paid\n'
        )
        self.assertEqual(summarize(text), {
            'A': 123456789012345678901234567801, 'B': 0,
        })

    def test_blank_amounts_are_zero(self):
        self.assertEqual(summarize(
            'customer,amount,status\nA,,paid\nB,   ,paid\n'
        ), {'A': 0, 'B': 0})

    def test_only_paid_amounts_are_validated(self):
        self.assertEqual(summarize(
            'customer,amount,status\n'
            'A,invalid,open\nB,NaN,void\nC,Infinity,\nD,1,paid\n'
        ), {'D': 100})

    def test_invalid_paid_amounts_include_row_number(self):
        for amount in ['invalid', '1.2.3', 'NaN', 'sNaN', 'Infinity', '-Infinity', '+Inf']:
            with self.subTest(amount=amount):
                with self.assertRaisesRegex(ValueError, r'\brow 2\b'):
                    summarize(f'customer,amount,status\nA,{amount},paid\n')

    def test_quoted_multiline_customer(self):
        self.assertEqual(summarize(
            'customer,amount,status\n  "  Alice\nSmith  " ,1.005,paid\n'
        ), {'Alice\nSmith': 101})

    def test_error_uses_record_ending_physical_line(self):
        for amount in ['invalid', 'NaN']:
            with self.subTest(amount=amount):
                text = (
                    'customer,amount,status\n\n'
                    '"Unpaid\ncustomer",invalid,open\n'
                    f'"Paid\ncustomer",{amount},paid\n'
                )
                with self.assertRaisesRegex(ValueError, r'\brow 6\b'):
                    summarize(text)

if __name__ == '__main__':
    unittest.main()
