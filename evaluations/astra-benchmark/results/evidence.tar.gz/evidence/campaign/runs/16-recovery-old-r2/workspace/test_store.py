from contextlib import closing
from pathlib import Path
import sqlite3
import tempfile
import unittest

from store import connect, import_events, list_events


class StoreTests(unittest.TestCase):
    def setUp(self):
        self.folder = tempfile.TemporaryDirectory(dir=Path(__file__).resolve().parent)
        self.addCleanup(self.folder.cleanup)
        self.path = Path(self.folder.name) / 'events.db'
        self.db = connect(self.path)
        self.addCleanup(self.db.close)

    def assert_batch_rollback(self, events, error=ValueError):
        before = list_events(self.db)
        with self.assertRaises(error):
            import_events(self.db, events)
        self.assertEqual(list_events(self.db), before)
        self.assertFalse(self.db.in_transaction)
        with closing(connect(self.path)) as reopened:
            self.assertEqual(list_events(reopened), before)

    def test_fresh_database(self):
        self.assertEqual(import_events(self.db, [{'id': 'a', 'payload': 'value'}]), 1)
        self.assertEqual(list_events(self.db), [('a', 'value', 'legacy')])
        with closing(connect(self.path)) as reopened:
            self.assertEqual(list_events(reopened), [('a', 'value', 'legacy')])

    def test_legacy_migration_preserves_data_and_reopens(self):
        path = Path(self.folder.name) / 'legacy.db'
        with closing(sqlite3.connect(path)) as old:
            with old:
                old.execute('CREATE TABLE events (id TEXT PRIMARY KEY, payload TEXT NOT NULL)')
                old.executemany('INSERT INTO events VALUES (?, ?)',
                                [('a', 'existing'), ('b', '旧数据')])
                old.execute('CREATE TABLE metadata (value TEXT)')
                old.execute("INSERT INTO metadata VALUES ('keep')")

        expected = [('a', 'existing', 'legacy'), ('b', '旧数据', 'legacy')]
        for attempt in range(3):
            with closing(connect(path)) as db:
                self.assertEqual(list_events(db), expected)
                self.assertEqual(db.execute('SELECT * FROM metadata').fetchall(), [('keep',)])
                self.assertEqual(import_events(db, [{'id': 'a', 'payload': 'existing'}]), 0)
                if attempt == 0:
                    with db:
                        db.execute("INSERT INTO events (id, payload) VALUES ('c', 'default')")
                    self.assertEqual(import_events(db, [
                        {'id': 'd', 'payload': 'new', 'source': 'queue'}
                    ]), 1)
                    expected.extend([('c', 'default', 'legacy'), ('d', 'new', 'queue')])
                self.assertEqual(list_events(db), expected)

    def test_retries_and_duplicates_count_only_new_records(self):
        batch = [
            {'id': 'a', 'payload': 'value'},
            {'id': 'a', 'payload': 'value', 'source': 'legacy'},
            {'id': 'b', 'payload': 'other', 'source': 'queue'},
            {'id': 'b', 'payload': 'other', 'source': 'queue'},
        ]
        self.assertEqual(import_events(self.db, batch), 2)
        self.assertEqual(import_events(self.db, batch), 0)
        self.assertEqual(import_events(self.db, [batch[0], {'id': 'c', 'payload': 'new'}]), 1)
        self.assertEqual(list_events(self.db), [
            ('a', 'value', 'legacy'), ('b', 'other', 'queue'), ('c', 'new', 'legacy')
        ])

    def test_existing_id_conflicts_roll_back(self):
        original = {'id': 'existing', 'payload': 'keep', 'source': 'queue'}
        import_events(self.db, [original])
        for field in ('payload', 'source'):
            with self.subTest(field=field):
                pending = {'id': 'new-' + field, 'payload': 'new'}
                self.assert_batch_rollback([original, pending, {**original, field: 'different'}])
                self.assertEqual(import_events(self.db, [pending]), 1)

    def test_conflicts_within_batch_roll_back(self):
        import_events(self.db, [{'id': 'existing', 'payload': 'keep'}])
        for field in ('payload', 'source'):
            with self.subTest(field=field):
                original = {'id': 'new-' + field, 'payload': 'value', 'source': 'queue'}
                self.assert_batch_rollback([original, {**original, field: 'different'}])
                self.assertEqual(import_events(self.db, [original]), 1)

    def test_invalid_fields_roll_back(self):
        import_events(self.db, [{'id': 'existing', 'payload': 'keep'}])
        pending = {'id': 'pending', 'payload': 'new'}
        for field in ('id', 'payload', 'source'):
            for value in ('', None, 0, False, [], {}, b'bytes'):
                with self.subTest(field=field, value=value):
                    event = {'id': 'invalid', 'payload': 'value', 'source': 'queue'}
                    event[field] = value
                    self.assert_batch_rollback([pending, event])
        for field in ('id', 'payload'):
            with self.subTest(missing=field):
                event = {'id': 'invalid', 'payload': 'value'}
                del event[field]
                self.assert_batch_rollback([pending, event])
        self.assertEqual(import_events(self.db, [pending]), 1)

    def test_invalid_record_types_roll_back(self):
        import_events(self.db, [{'id': 'existing', 'payload': 'keep'}])
        pending = {'id': 'pending', 'payload': 'new'}
        for event in (None, 'invalid', 42, ['id', 'payload']):
            with self.subTest(event=event):
                self.assert_batch_rollback([pending, event])
        self.assertEqual(import_events(self.db, [pending]), 1)

    def test_generator_failure_rolls_back(self):
        original = {'id': 'existing', 'payload': 'keep'}
        pending = {'id': 'pending', 'payload': 'new'}
        import_events(self.db, [original])

        def broken_batch():
            yield pending
            raise RuntimeError('input stream failed')

        self.assert_batch_rollback(broken_batch(), RuntimeError)
        self.assertEqual(import_events(self.db, [pending]), 1)

    def test_generator_failure_before_first_record(self):
        def broken_batch():
            raise RuntimeError('input stream failed')
            yield

        self.assert_batch_rollback(broken_batch(), RuntimeError)
        self.assertEqual(import_events(self.db, [{'id': 'a', 'payload': 'value'}]), 1)

    def test_successful_and_empty_generators(self):
        def batch():
            yield {'id': 'a', 'payload': 'value'}
            yield {'id': 'a', 'payload': 'value', 'source': 'legacy'}
            yield {'id': 'b', 'payload': 'other'}

        self.assertEqual(import_events(self.db, batch()), 2)
        self.assertEqual(import_events(self.db, iter(())), 0)
        self.assertEqual(import_events(self.db, []), 0)
        self.assertEqual(list_events(self.db), [('a', 'value', 'legacy'), ('b', 'other', 'legacy')])


if __name__ == '__main__':
    unittest.main()
