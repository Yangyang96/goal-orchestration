import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

import routebook
from routebook import load_routes


class RouteTests(unittest.TestCase):
    def setUp(self):
        self.folder = tempfile.TemporaryDirectory(dir=Path(__file__).resolve().parent)
        self.addCleanup(self.folder.cleanup)
        self.root = Path(self.folder.name)

    def write_config(self, name, data):
        path = self.root / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(data))
        return path

    def load(self, data, mode):
        if mode == 'text':
            return routebook.load_routes_text(json.dumps(data), base_dir=self.root)
        return load_routes(self.write_config('entry.json', data))

    def test_legacy(self):
        path = self.write_config('routes.json', {'routes': {'home': 'https://example.invalid'}})
        self.assertEqual(load_routes(path), {'home': 'https://example.invalid'})

    def test_public_text_api(self):
        from routebook import load_routes_text

        self.assertIn('load_routes_text', routebook.__all__)
        self.assertEqual(
            load_routes_text('{"routes": {"home": "/home"}}', base_dir=str(self.root)),
            {'home': '/home'},
        )
        with self.assertRaises(TypeError):
            load_routes_text('{"routes": {}}', self.root)
        with self.assertRaises(TypeError):
            load_routes_text('{"routes": {}}')

    def test_empty_routes(self):
        for mode in ('file', 'text'):
            with self.subTest(mode=mode):
                self.assertEqual(self.load({'routes': {}}, mode), {})

    def test_nested_includes_and_local_overrides(self):
        self.write_config('nested/base.json', {
            'routes': {'base': '/base', 'shared': '/base-shared', 'home': '/base-home'},
        })
        self.write_config('nested/middle.json', {
            'include': 'base.json',
            'routes': {'middle': '/middle', 'shared': '/middle-shared', 'home': '/middle-home'},
        })
        data = {'include': 'nested/middle.json', 'routes': {'home': '/local'}}
        for mode in ('file', 'text'):
            with self.subTest(mode=mode):
                self.assertEqual(self.load(data, mode), {
                    'base': '/base', 'middle': '/middle',
                    'shared': '/middle-shared', 'home': '/local',
                })

    def test_same_basename_and_parent_relative_includes(self):
        self.write_config('a/routes.json', {
            'include': '../b/routes.json', 'routes': {'a': '/a'},
        })
        self.write_config('b/routes.json', {'routes': {'b': '/b'}})
        data = {'include': 'a/routes.json', 'routes': {}}
        for mode in ('file', 'text'):
            with self.subTest(mode=mode):
                self.assertEqual(self.load(data, mode), {'a': '/a', 'b': '/b'})

    def test_cycles(self):
        self.write_config('self.json', {'include': './self.json', 'routes': {}})
        self.write_config('a.json', {'include': 'nested/b.json', 'routes': {}})
        self.write_config('nested/b.json', {'include': '../a.json', 'routes': {}})
        for name in ('self.json', 'a.json'):
            for mode in ('file', 'text'):
                with self.subTest(name=name, mode=mode):
                    with self.assertRaisesRegex(ValueError, 'cycle'):
                        self.load({'include': name, 'routes': {}}, mode)

    def test_file_root_participates_in_cycle_detection(self):
        path = self.write_config('routes.json', {'include': 'routes.json', 'routes': {}})
        with self.assertRaisesRegex(ValueError, 'cycle'):
            load_routes(path)

    def test_symlink_cycle_uses_resolved_paths(self):
        directory = self.root / 'nested'
        directory.mkdir()
        try:
            (directory / 'again').symlink_to(directory, target_is_directory=True)
        except (OSError, NotImplementedError) as error:
            self.skipTest(f'symlinks unavailable: {error}')
        self.write_config('nested/routes.json', {'include': 'again/routes.json', 'routes': {}})
        for mode in ('file', 'text'):
            with self.subTest(mode=mode):
                with self.assertRaisesRegex(ValueError, 'cycle'):
                    self.load({'include': 'nested/routes.json', 'routes': {}}, mode)

    def test_invalid_structures(self):
        invalid_configs = [
            None, [], 'config', 1, True, {},
            {'routes': None}, {'routes': []}, {'routes': 'home'},
            {'routes': 1}, {'routes': True},
            *({'routes': {'home': value}} for value in (None, 1, False, [], {})),
            *({'routes': {}, 'include': value} for value in (None, '', 1, False, [], {})),
            {'routes': {}, 'include': str(self.root / 'absolute.json')},
            {'include': 'base.json'},
        ]
        self.write_config('base.json', {'routes': {}})
        for data in invalid_configs:
            for mode in ('file', 'text'):
                with self.subTest(data=data, mode=mode):
                    with self.assertRaises(ValueError):
                        self.load(data, mode)

    def test_invalid_included_structure_is_not_hidden_by_override(self):
        self.write_config('invalid.json', {'routes': {'home': 42}})
        data = {'include': 'invalid.json', 'routes': {'home': '/valid'}}
        for mode in ('file', 'text'):
            with self.subTest(mode=mode):
                with self.assertRaises(ValueError):
                    self.load(data, mode)

    def test_missing_files(self):
        with self.assertRaises(FileNotFoundError):
            load_routes(self.root / 'missing.json')
        for mode in ('file', 'text'):
            with self.subTest(mode=mode):
                with self.assertRaises(FileNotFoundError):
                    self.load({'include': 'missing.json', 'routes': {}}, mode)

    def test_malformed_json(self):
        path = self.root / 'broken.json'
        path.write_text('{broken')
        with self.assertRaises(ValueError):
            load_routes(path)
        with self.assertRaises(ValueError):
            routebook.load_routes_text('{broken', base_dir=self.root)
        for mode in ('file', 'text'):
            with self.subTest(mode=mode):
                with self.assertRaises(ValueError):
                    self.load({'include': 'broken.json', 'routes': {}}, mode)

    def test_repeated_loads_are_independent(self):
        self.write_config('base.json', {'routes': {'home': '/home'}})
        data = {'include': 'base.json', 'routes': {}}
        for mode in ('file', 'text'):
            with self.subTest(mode=mode):
                first = self.load(data, mode)
                first['home'] = '/changed'
                self.assertEqual(self.load(data, mode), {'home': '/home'})


class CliTests(unittest.TestCase):
    def setUp(self):
        self.folder = tempfile.TemporaryDirectory(dir=Path(__file__).resolve().parent)
        self.addCleanup(self.folder.cleanup)
        self.root = Path(self.folder.name)

    def run_cli(self, *args, input_text=''):
        env = os.environ.copy()
        env['PYTHONPATH'] = os.pathsep.join(filter(None, (
            str(Path(__file__).resolve().parent), env.get('PYTHONPATH'),
        )))
        return subprocess.run(
            [sys.executable, '-m', 'routebook', *args],
            input=input_text, text=True, capture_output=True,
            cwd=self.root, env=env, timeout=10,
        )

    def test_legacy_file_output(self):
        (self.root / 'config.json').write_text('{"routes": {"z": "/last", "a": "/first"}}')
        result = self.run_cli('config.json')
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(result.stdout, '{"a": "/first", "z": "/last"}\n')
        self.assertEqual(result.stderr, '')

    def test_file_includes_use_config_directory(self):
        folder = self.root / 'configs'
        folder.mkdir()
        (folder / 'base.json').write_text('{"routes": {"home": "/base"}}')
        (folder / 'config.json').write_text('{"include": "base.json", "routes": {}}')
        result = self.run_cli('configs/config.json')
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(json.loads(result.stdout), {'home': '/base'})
        self.assertEqual(result.stderr, '')

    def test_stdin_includes_use_current_directory(self):
        folder = self.root / 'nested'
        folder.mkdir()
        (folder / 'base.json').write_text('{"routes": {"base": "/base", "home": "/base-home"}}')
        (folder / 'middle.json').write_text('{"include": "base.json", "routes": {"middle": "/middle"}}')
        result = self.run_cli(
            '--stdin',
            input_text='{"include": "nested/middle.json", "routes": {"home": "/local"}}',
        )
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(json.loads(result.stdout), {
            'base': '/base', 'middle': '/middle', 'home': '/local',
        })
        self.assertEqual(result.stderr, '')

    def test_stdin_without_includes(self):
        result = self.run_cli('--stdin', input_text='{"routes": {"z": "/z", "a": "/a"}}')
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(result.stdout, '{"a": "/a", "z": "/z"}\n')
        self.assertEqual(result.stderr, '')

    def test_invalid_argument_combinations(self):
        for args in ((), ('--stdin', 'missing.json'), ('missing.json', '--stdin')):
            with self.subTest(args=args):
                result = self.run_cli(*args, input_text='not JSON')
                self.assertEqual(result.returncode, 2, result.stderr)
                self.assertIn('usage:', result.stderr)
                self.assertNotIn('Traceback', result.stderr)
                self.assertEqual(result.stdout, '')


if __name__ == '__main__':
    unittest.main()
