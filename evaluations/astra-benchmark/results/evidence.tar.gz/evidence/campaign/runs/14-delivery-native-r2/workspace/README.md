# Routebook

Load route tables from JSON files or text using only the Python standard library.

## Python API

```python
from routebook import load_routes, load_routes_text

routes = load_routes('config.json')
routes = load_routes_text(
    '{"include": "base.json", "routes": {"home": "/home"}}',
    base_dir='configs',
)
```

Both functions return a new dictionary mapping route names to destinations and
share the same loading and validation logic. `load_routes(path)` accepts a string
or `Path` and preserves the file API. `load_routes_text(text, *, base_dir)` requires
`base_dir` as a keyword argument (a string or `Path`); it determines where includes
in the supplied text are found. A relative `base_dir` is relative to the current
working directory.

## Configuration and includes

Every configuration must be a JSON object with a `routes` object, which may be
empty. Route names and destinations must be strings. An optional `include` must
be a nonempty relative filename pointing to another JSON configuration; absolute
paths are rejected.

For example, given `configs/base.json`:

```json
{"routes": {"home": "/old-home", "help": "/help"}}
```

and `configs/app.json`:

```json
{"include": "base.json", "routes": {"home": "/home"}}
```

`load_routes('configs/app.json')` returns
`{"home": "/home", "help": "/help"}`. Includes load recursively before local routes
are applied, so local destinations win on duplicate names. Each file resolves its
include relative to its own resolved parent directory, including nested paths
and `..`; the initial text configuration uses `base_dir` instead.

Cycles are detected using resolved full paths, including symlink resolution, and
raise `ValueError` with `cycle` in the message. Distinct files with the same
basename are allowed. Missing files raise `FileNotFoundError`. Invalid JSON or
malformed configuration structures raise `ValueError`, including errors in
included files even when their routes would be overridden locally.

## CLI

```sh
python3 -m routebook configs/app.json
printf '%s\n' '{"include": "configs/base.json", "routes": {"home": "/home"}}' | python3 -m routebook --stdin
```

Both modes emit a JSON object with sorted keys and a trailing newline on stdout.
File mode resolves includes from the configuration file's directory. `--stdin`
reads JSON from standard input and resolves initial includes from the current
working directory. Provide exactly one of a positional config file or `--stdin`:
combining them, or providing neither, produces an argparse usage error on stderr
and exit status 2.

## Tests

Run `python3 -m unittest -v`. Regression tests cover both APIs, nested includes,
overrides, path and symlink cycles, validation, missing files, and both CLI modes.
