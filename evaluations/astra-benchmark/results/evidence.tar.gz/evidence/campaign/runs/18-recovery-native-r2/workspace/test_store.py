import sqlite3
import tempfile
import unittest
from pathlib import Path

from store import connect, import_events, list_events


class StoreTests(unittest.TestCase):
    def open_database(self, path=':memory:'):
        db = connect(path)
        self.addCleanup(db.close)
        return db

    def assert_failed_batch_is_atomic(self, events, exception):
        db = self.open_database()
        existing = {'id': 'existing', 'payload': 'saved', 'source': 'queue'}
        self.assertEqual(import_events(db, [existing]), 1)
        before = list_events(db)

        with self.assertRaises(exception):
            import_events(db, events)

        self.assertEqual(list_events(db), before)
        self.assertFalse(db.in_transaction)
        self.assertEqual(import_events(db, [{'id': 'first', 'payload': 'recovered'}]), 1)
        self.assertEqual(list_events(db), before + [('first', 'recovered', 'legacy')])

    def test_fresh_database(self):
        db = self.open_database()
        self.assertEqual(import_events(db, [{'id': 'a', 'payload': 'value'}]), 1)
        self.assertEqual(list_events(db), [('a', 'value', 'legacy')])

    def test_migrate_legacy_database_and_reopen(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / 'events.db'
            old = sqlite3.connect(path)
            try:
                old.execute('CREATE TABLE events (id TEXT PRIMARY KEY, payload TEXT NOT NULL)')
                old.executemany('INSERT INTO events VALUES (?, ?)',
                                [('old-1', 'existing'), ('old-2', 'also existing')])
                old.execute('CREATE INDEX events_payload ON events(payload)')
                old.execute('CREATE TABLE unrelated (value TEXT)')
                old.execute("INSERT INTO unrelated VALUES ('keep me')")
                old.commit()
            finally:
                old.close()

            expected = [('old-1', 'existing', 'legacy'),
                        ('old-2', 'also existing', 'legacy')]
            for opening in range(3):
                db = connect(path)
                try:
                    self.assertEqual(list_events(db), expected)
                    self.assertEqual(db.execute('SELECT value FROM unrelated').fetchall(),
                                     [('keep me',)])
                    self.assertIn('events_payload',
                                  [row[1] for row in db.execute('PRAGMA index_list(events)')])
                    columns = {row[1]: row for row in db.execute('PRAGMA table_info(events)')}
                    self.assertEqual(columns['source'][2].upper(), 'TEXT')
                    self.assertEqual(columns['source'][3], 1)
                    self.assertFalse(db.in_transaction)
                    self.assertEqual(import_events(db, [{'id': 'old-1', 'payload': 'existing'}]), 0)
                    if opening == 0:
                        self.assertEqual(import_events(db, [
                            {'id': 'new', 'payload': 'hello', 'source': 'queue'}]), 1)
                        # Legacy writers must still receive the column default.
                        db.execute("INSERT INTO events (id, payload) VALUES ('default', 'value')")
                        db.commit()
                        expected = [('default', 'value', 'legacy'),
                                    ('new', 'hello', 'queue')] + expected
                finally:
                    db.close()

    def test_fresh_database_survives_reopen(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / 'events.db'
            event = {'id': 'a', 'payload': 'value', 'source': 'queue'}
            db = connect(path)
            try:
                self.assertEqual(import_events(db, [event]), 1)
            finally:
                db.close()
            reopened = connect(path)
            try:
                self.assertEqual(list_events(reopened), [('a', 'value', 'queue')])
                self.assertEqual(import_events(reopened, [event]), 0)
            finally:
                reopened.close()

    def test_retries_and_duplicates_only_count_new_records(self):
        db = self.open_database()
        first = {'id': 'a', 'payload': 'value'}
        explicit_default = dict(first, source='legacy')
        second = {'id': 'b', 'payload': 'another', 'source': 'queue'}
        batch = [first, explicit_default, second, second]
        self.assertEqual(import_events(db, batch), 2)
        self.assertEqual(import_events(db, batch), 0)
        self.assertEqual(import_events(db, [second, {'id': 'c', 'payload': 'new'}, first]), 1)
        self.assertEqual(list_events(db), [('a', 'value', 'legacy'),
                                          ('b', 'another', 'queue'),
                                          ('c', 'new', 'legacy')])

    def test_conflicts_with_existing_records_roll_back_batch(self):
        existing = {'id': 'existing', 'payload': 'saved', 'source': 'queue'}
        for change in ({'payload': 'changed'}, {'source': 'changed'}):
            with self.subTest(change=change):
                self.assert_failed_batch_is_atomic([
                    {'id': 'first', 'payload': 'new'},
                    existing,
                    dict(existing, **change),
                ], ValueError)

    def test_conflicts_within_batch_roll_back_batch(self):
        first = {'id': 'first', 'payload': 'new'}
        for change in ({'payload': 'changed'}, {'source': 'changed'}):
            with self.subTest(change=change):
                self.assert_failed_batch_is_atomic([
                    first, first, dict(first, **change),
                ], ValueError)

    def test_missing_required_fields_roll_back_batch(self):
        for invalid in ({}, {'id': 'bad'}, {'payload': 'value'}):
            with self.subTest(event=invalid):
                self.assert_failed_batch_is_atomic([
                    {'id': 'first', 'payload': 'new'}, invalid,
                ], ValueError)

    def test_invalid_field_values_roll_back_batch(self):
        for field in ('id', 'payload', 'source'):
            for value in ('', None, 0, False, 1.5, b'bytes', [], {}):
                with self.subTest(field=field, value=value):
                    invalid = {'id': 'bad', 'payload': 'value', 'source': 'queue'}
                    invalid[field] = value
                    self.assert_failed_batch_is_atomic([
                        {'id': 'first', 'payload': 'new'}, invalid,
                    ], ValueError)

    def test_non_mapping_records_raise_value_error_and_roll_back(self):
        for invalid in (None, 1, 'event', ['id', 'payload']):
            with self.subTest(event=invalid):
                self.assert_failed_batch_is_atomic([
                    {'id': 'first', 'payload': 'new'}, invalid,
                ], ValueError)

    def test_generator_failure_rolls_back_and_preserves_exception(self):
        error = RuntimeError('input stream failed')

        def events():
            yield {'id': 'first', 'payload': 'new'}
            yield {'id': 'second', 'payload': 'another', 'source': 'queue'}
            raise error

        db = self.open_database()
        import_events(db, [{'id': 'existing', 'payload': 'saved'}])
        before = list_events(db)
        with self.assertRaises(RuntimeError) as caught:
            import_events(db, events())
        self.assertIs(caught.exception, error)
        self.assertEqual(list_events(db), before)
        self.assertFalse(db.in_transaction)
        self.assertEqual(import_events(db, [{'id': 'first', 'payload': 'recovered'}]), 1)

    def test_iteration_start_failure_leaves_connection_usable(self):
        class BrokenIterable:
            def __iter__(self):
                raise RuntimeError('cannot open input')

        self.assert_failed_batch_is_atomic(BrokenIterable(), RuntimeError)

    def test_generator_success_and_empty_batches(self):
        db = self.open_database()
        events = ({'id': event_id, 'payload': 'value'} for event_id in ('b', 'a', 'b'))
        self.assertEqual(import_events(db, events), 2)
        self.assertEqual(import_events(db, []), 0)
        self.assertEqual(import_events(db, iter(())), 0)
        self.assertEqual(list_events(db), [('a', 'value', 'legacy'), ('b', 'value', 'legacy')])
        self.assertFalse(db.in_transaction)


if __name__ == '__main__':
    unittest.main()
