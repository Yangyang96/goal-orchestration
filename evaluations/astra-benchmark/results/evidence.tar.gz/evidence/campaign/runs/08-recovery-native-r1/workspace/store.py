"""Small SQLite event store, upgraded in place from schema v1."""
import sqlite3
from collections.abc import Mapping


def connect(path):
    db = sqlite3.connect(path)
    try:
        with db:
            # Serialize schema inspection and migration, including concurrent opens.
            db.execute('BEGIN IMMEDIATE')
            db.execute("""
                CREATE TABLE IF NOT EXISTS events (
                    id TEXT PRIMARY KEY,
                    payload TEXT NOT NULL,
                    source TEXT NOT NULL DEFAULT 'legacy'
                )
            """)
            columns = {row[1] for row in db.execute('PRAGMA table_info(events)')}
            if 'source' not in columns:
                db.execute("ALTER TABLE events ADD COLUMN source TEXT NOT NULL DEFAULT 'legacy'")
    except BaseException:
        db.close()
        raise
    return db


def import_events(db, events):
    """Atomically import a batch; identical retries are idempotent.

    Return number of newly inserted records. Existing identical records count
    as zero. A reused id with different payload or source raises ValueError.
    Missing source means 'legacy'. Every id/payload/source must be a nonempty
    string. A failure must leave ALL rows in this batch unapplied.

    The connection must have no caller transaction active.
    """
    inserted = 0
    with db:
        # Hold the write transaction across lookups, inserts and input iteration.
        db.execute('BEGIN IMMEDIATE')
        for event in events:
            if not isinstance(event, Mapping):
                raise ValueError('Each event must be a mapping')
            values = (event.get('id'), event.get('payload'), event.get('source', 'legacy'))
            for field, value in zip(('id', 'payload', 'source'), values):
                if not isinstance(value, str) or not value:
                    raise ValueError(f'{field} must be a nonempty string')

            existing = db.execute('SELECT payload,source FROM events WHERE id = ?',
                                  (values[0],)).fetchone()
            if existing is not None:
                if existing != values[1:]:
                    raise ValueError(f'Conflicting event for id {values[0]!r}')
                continue
            db.execute('INSERT INTO events (id,payload,source) VALUES (?,?,?)', values)
            inserted += 1
    return inserted


def list_events(db):
    return db.execute('SELECT id,payload,source FROM events ORDER BY id').fetchall()
