import sqlite3
import tempfile
import unittest
from pathlib import Path

from store import connect, import_events, list_events


class StoreTests(unittest.TestCase):
    def setUp(self):
        folder = tempfile.TemporaryDirectory(dir=Path(__file__).resolve().parent)
        self.addCleanup(folder.cleanup)
        self.path = Path(folder.name) / 'events.db'
        self.db = connect(self.path)
        self.addCleanup(self.db.close)

    def assert_rows_persisted(self, expected):
        self.assertEqual(list_events(self.db), expected)
        self.assertFalse(self.db.in_transaction)
        other = connect(self.path)
        try:
            self.assertEqual(list_events(other), expected)
        finally:
            other.close()

    def assert_connection_reusable(self):
        self.assertEqual(import_events(self.db, [{'id': 'later', 'payload': 'ok'}]), 1)
        self.assertIn(('later', 'ok', 'legacy'), list_events(self.db))

    def test_fresh_database(self):
        db = connect(':memory:')
        self.addCleanup(db.close)
        self.assertEqual(import_events(db, [{'id': 'a', 'payload': 'value'}]), 1)
        self.assertEqual(list_events(db), [('a', 'value', 'legacy')])

    def test_legacy_migration_preserves_data_and_survives_reopen(self):
        path = self.path.with_name('legacy.db')
        old = sqlite3.connect(path)
        try:
            old.execute('CREATE TABLE events (id TEXT PRIMARY KEY, payload TEXT NOT NULL)')
            old.executemany('INSERT INTO events VALUES (?, ?)',
                            [('old-1', 'existing'), ('old-2', 'another')])
            old.execute('CREATE TABLE unrelated (value TEXT)')
            old.execute("INSERT INTO unrelated VALUES ('keep')")
            old.execute('CREATE INDEX events_payload ON events(payload)')
            old.commit()
        finally:
            old.close()

        expected = [('old-1', 'existing', 'legacy'), ('old-2', 'another', 'legacy')]
        for opening in range(3):
            db = connect(path)
            try:
                self.assertEqual(list_events(db), expected)
                self.assertEqual(db.execute('SELECT * FROM unrelated').fetchall(), [('keep',)])
                self.assertIn('events_payload',
                              [row[1] for row in db.execute('PRAGMA index_list(events)')])
                self.assertEqual(import_events(db, [{'id': 'old-1', 'payload': 'existing'}]), 0)
                if opening == 0:
                    with db:
                        db.execute("INSERT INTO events (id, payload) VALUES ('old-3', 'default')")
                    expected.append(('old-3', 'default', 'legacy'))
                with self.assertRaises(sqlite3.IntegrityError):
                    with db:
                        db.execute("INSERT INTO events VALUES ('null-source', 'bad', NULL)")
            finally:
                db.close()

    def test_retries_and_duplicates_count_only_new_records(self):
        batch = [
            {'id': 'a', 'payload': 'one'},
            {'id': 'a', 'payload': 'one', 'source': 'legacy'},
            {'id': 'b', 'payload': 'two', 'source': 'queue'},
            {'id': 'b', 'payload': 'two', 'source': 'queue'},
        ]
        self.assertEqual(import_events(self.db, iter(batch)), 2)
        self.assertEqual(import_events(self.db, batch), 0)
        self.assertEqual(import_events(self.db, batch + [{'id': 'c', 'payload': 'three'}]), 1)
        self.assert_rows_persisted([
            ('a', 'one', 'legacy'), ('b', 'two', 'queue'), ('c', 'three', 'legacy'),
        ])

    def test_conflicts_roll_back_batch_and_preserve_existing_rows(self):
        existing = {'id': 'existing', 'payload': 'keep', 'source': 'queue'}
        self.assertEqual(import_events(self.db, [existing]), 1)
        for changes in ({'payload': 'different'}, {'source': 'other'}, {'source': 'legacy'}):
            with self.subTest(changes=changes):
                with self.assertRaises(ValueError):
                    import_events(self.db, [
                        existing, {'id': 'new', 'payload': 'rollback'}, {**existing, **changes},
                    ])
                self.assert_rows_persisted([('existing', 'keep', 'queue')])
        self.assert_connection_reusable()

    def test_conflict_within_batch_rolls_back_all_new_rows(self):
        for changes in ({'payload': 'different'}, {'source': 'other'}):
            with self.subTest(changes=changes):
                event = {'id': 'a', 'payload': 'one', 'source': 'queue'}
                with self.assertRaises(ValueError):
                    import_events(self.db, [
                        event, {'id': 'b', 'payload': 'two'}, {**event, **changes},
                    ])
                self.assert_rows_persisted([])
        self.assert_connection_reusable()

    def test_invalid_fields_roll_back_batch(self):
        valid = {'id': 'bad', 'payload': 'value', 'source': 'queue'}
        invalid_events = [{}, {'payload': 'value'}, {'id': 'bad'}]
        for field in ('id', 'payload', 'source'):
            for value in ('', None, 0, 1, False, True, 1.5, b'bytes', [], {}):
                invalid_events.append({**valid, field: value})
        self.assertEqual(import_events(self.db, [{'id': 'existing', 'payload': 'keep'}]), 1)
        for invalid in invalid_events:
            with self.subTest(event=invalid):
                with self.assertRaises(ValueError):
                    import_events(self.db, [{'id': 'new', 'payload': 'rollback'}, invalid])
                self.assert_rows_persisted([('existing', 'keep', 'legacy')])
        self.assert_connection_reusable()

    def test_invalid_record_types_raise_value_error_and_roll_back(self):
        for invalid in (None, 'event', [], 42):
            with self.subTest(event=invalid):
                with self.assertRaises(ValueError):
                    import_events(self.db, [{'id': 'new', 'payload': 'rollback'}, invalid])
                self.assert_rows_persisted([])
        self.assert_connection_reusable()

    def test_generator_failure_rolls_back_and_preserves_original_exception(self):
        self.assertEqual(import_events(self.db, [{'id': 'existing', 'payload': 'keep'}]), 1)
        for error_type in (RuntimeError, KeyboardInterrupt):
            for count in (0, 2):
                with self.subTest(error_type=error_type, count=count):
                    error = error_type('input failed')

                    def failing_events():
                        for index in range(count):
                            yield {'id': str(index), 'payload': 'rollback'}
                        raise error

                    with self.assertRaises(error_type) as raised:
                        import_events(self.db, failing_events())
                    self.assertIs(raised.exception, error)
                    self.assert_rows_persisted([('existing', 'keep', 'legacy')])
        self.assert_connection_reusable()

    def test_database_error_rolls_back_batch(self):
        with self.db:
            self.db.execute("""
                CREATE TRIGGER reject_event BEFORE INSERT ON events
                WHEN NEW.id = 'rejected'
                BEGIN SELECT RAISE(ABORT, 'rejected event'); END
            """)
        self.assertEqual(import_events(self.db, [{'id': 'existing', 'payload': 'keep'}]), 1)
        with self.assertRaises(sqlite3.IntegrityError):
            import_events(self.db, [
                {'id': 'new', 'payload': 'rollback'}, {'id': 'rejected', 'payload': 'bad'},
            ])
        self.assert_rows_persisted([('existing', 'keep', 'legacy')])
        self.assert_connection_reusable()

    def test_empty_batch(self):
        self.assertEqual(import_events(self.db, [{'id': 'existing', 'payload': 'keep'}]), 1)
        self.assertEqual(import_events(self.db, iter(())), 0)
        self.assert_rows_persisted([('existing', 'keep', 'legacy')])


if __name__ == '__main__':
    unittest.main()
