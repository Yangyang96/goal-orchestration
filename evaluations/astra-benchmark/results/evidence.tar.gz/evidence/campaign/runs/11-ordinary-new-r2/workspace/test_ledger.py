import unittest
from ledger import summarize, render

class LedgerTests(unittest.TestCase):
    def test_basic(self):
        self.assertEqual(summarize('customer,amount,status\nA,1.20,paid\nB,2,open\n'), {'A': 120})

    def test_bom_whitespace_and_status_case(self):
        text = '\ufeff customer , amount , status , extra \n Alice , 1.20 , PaId , ignored \n'
        self.assertEqual(summarize(text), {'Alice': 120})

    def test_blank_amounts_duplicates_and_sorted_case_preserving_names(self):
        text = (
            'customer,amount,status\n'
            'Zoe,1,paid\n'
            ' Alice , ,paid\n'
            'Alice,2.30,paid\n'
            'alice,,paid\n'
            'Zoe,-0.25,paid\n'
        )
        totals = summarize(text)
        self.assertEqual(list(totals.items()), [('Alice', 230), ('Zoe', 75), ('alice', 0)])
        self.assertEqual(render(totals), 'Alice\t230\nZoe\t75\nalice\t0\n')

    def test_round_half_up_per_row_including_refunds(self):
        text = (
            'customer,amount,status\n'
            'A,0.005,paid\n'
            'A,0.005,paid\n'
            'B,-0.005,paid\n'
            'B,-0.005,paid\n'
            'C,1.005,paid\n'
            'D,-1.005,paid\n'
            'E,0.0049,paid\n'
            'F,-0.0049,paid\n'
        )
        self.assertEqual(summarize(text), {'A': 2, 'B': -2, 'C': 101, 'D': -101, 'E': 0, 'F': 0})

    def test_large_amounts_keep_decimal_precision(self):
        text = 'customer,amount,status\nA,1234567890123456789012345678.995,paid\n'
        self.assertEqual(summarize(text), {'A': 123456789012345678901234567900})

    def test_only_paid_rows_validate_amounts(self):
        text = (
            'customer,amount,status\n'
            'A,invalid,open\n'
            'B,NaN,void\n'
            'C,Infinity,\n'
            'D,1,paid\n'
        )
        self.assertEqual(summarize(text), {'D': 100})

    def test_invalid_paid_amounts_report_row(self):
        for amount in ('invalid', '1.2.3', 'NaN', '-NaN', 'sNaN', 'Infinity', '-Infinity', 'inf'):
            with self.subTest(amount=amount):
                text = f'customer,amount,status\nA,{amount},paid\n'
                with self.assertRaisesRegex(ValueError, r'\brow 2\b'):
                    summarize(text)

    def test_error_uses_record_ending_physical_line(self):
        text = (
            'customer,amount,status\r\n'
            'Skipped,invalid,open\r\n'
            '\r\n'
            '"Multi\r\nline",invalid,paid\r\n'
        )
        with self.assertRaisesRegex(ValueError, r'\brow 5\b'):
            summarize(text)

    def test_quoted_multiline_customer(self):
        text = 'customer,amount,status\n"  Alice\nSmith  ",1.005,paid\n'
        self.assertEqual(summarize(text), {'Alice\nSmith': 101})

    def test_empty_input(self):
        for text in ('', '\ufeff', 'customer,amount,status\n'):
            with self.subTest(text=text):
                self.assertEqual(summarize(text), {})

    def test_render(self):
        self.assertEqual(render({'A': 120}), 'A\t120\n')

if __name__ == '__main__':
    unittest.main()
