"""Summarize invoice CSV exports. All monetary output is exact, in cents."""
import csv
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP, localcontext
from io import StringIO


def summarize(text):
    """Return customer -> total cents, sorted by customer name.

    Input columns: customer, amount, status. Extra columns are ignored.
    Blank amounts count as zero. Only paid invoices are included.
    Amounts are rounded per row to cents using ROUND_HALF_UP.
    Refunds (negative amounts) are supported.
    Invalid paid amounts raise ValueError with the physical CSV row number.
    """
    totals = {}
    reader = csv.DictReader(StringIO(text.removeprefix('\ufeff'), newline=''), skipinitialspace=True)
    if reader.fieldnames is not None:
        reader.fieldnames = [name.strip() for name in reader.fieldnames]
    for row in reader:
        if (row['status'] or '').strip().casefold() != 'paid':
            continue
        customer = row['customer'].strip()
        try:
            amount = Decimal((row['amount'] or '').strip() or '0')
        except InvalidOperation as exc:
            raise ValueError(f'Invalid amount at row {reader.line_num}') from exc
        if not amount.is_finite():
            raise ValueError(f'Invalid amount at row {reader.line_num}')
        with localcontext() as context:
            # Scaling must stay exact even beyond the default Decimal precision.
            context.prec = max(context.prec, len(amount.as_tuple().digits) + 2)
            cents = int((amount * 100).to_integral_value(rounding=ROUND_HALF_UP))
        totals[customer] = totals.get(customer, 0) + cents
    return dict(sorted(totals.items()))


def render(totals):
    """Stable tab-separated report; no header."""
    return ''.join(f'{name}\t{cents}\n' for name, cents in totals.items())
