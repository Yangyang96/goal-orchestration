import unittest
from ledger import summarize, render

class LedgerTests(unittest.TestCase):
    def test_basic(self):
        self.assertEqual(summarize('customer,amount,status\nA,1.20,paid\nB,2,open\n'), {'A': 120})

    def test_render(self):
        self.assertEqual(render({'A': 120}), 'A\t120\n')

    def test_bom_and_surrounding_whitespace(self):
        text = ('\ufeff customer , amount , status , extra \n'
                ' Alice , 1.20 , PaId , ignored \n'
                'Alice, 0.005 , PAID , ignored \n')
        self.assertEqual(summarize(text), {'Alice': 121})

    def test_blank_amounts_are_zero(self):
        text = 'customer,amount,status\nA,,paid\nB,   ,paid\n'
        self.assertEqual(summarize(text), {'A': 0, 'B': 0})

    def test_round_half_up_including_refunds(self):
        for amount, cents in [('1.005', 101), ('2.675', 268),
                              ('-1.005', -101), ('-2.675', -268),
                              ('0.005', 1), ('-0.005', -1)]:
            with self.subTest(amount=amount):
                text = f'customer,amount,status\nA,{amount},paid\n'
                self.assertEqual(summarize(text), {'A': cents})

    def test_rounds_each_row_before_aggregating(self):
        text = ('customer,amount,status\n'
                'A,0.005,paid\nA,0.005,paid\n'
                'B,-0.005,paid\nB,-0.005,paid\n')
        self.assertEqual(summarize(text), {'A': 2, 'B': -2})

    def test_large_amounts_keep_exact_cents(self):
        text = ('customer,amount,status\n'
                'A,123456789012345678901234567890.005,paid\n'
                'B,999999999999999999999999999999.995,paid\n')
        self.assertEqual(summarize(text), {
            'A': 12345678901234567890123456789001,
            'B': 100000000000000000000000000000000,
        })

    def test_malformed_paid_amounts_report_row(self):
        for amount in ['oops', '1.2.3', 'NaN', 'sNaN', 'Infinity',
                       '-Infinity', '+inf', '-NaN']:
            with self.subTest(amount=amount):
                text = f'customer,amount,status\nA,1,paid\nB,{amount},paid\n'
                with self.assertRaisesRegex(ValueError, r'\brow 3\b'):
                    summarize(text)

    def test_only_paid_amounts_are_validated(self):
        text = ('customer,amount,status\n'
                'A,oops,open\nB,NaN, CANCELLED \nC,Infinity,\n'
                'D,1, Paid \n')
        self.assertEqual(summarize(text), {'D': 100})

    def test_multiline_customer_and_physical_error_line(self):
        text = 'customer,amount,status\n\n" First\nCustomer ",1,paid\n'
        self.assertEqual(summarize(text), {'First\nCustomer': 100})
        for amount in ['oops', 'NaN']:
            with self.subTest(amount=amount):
                with self.assertRaisesRegex(ValueError, r'\brow 6\b'):
                    summarize(text + f'"Bad\nCustomer",{amount},paid\n')

    def test_sorted_aggregation_preserves_customer_case(self):
        text = ('customer,amount,status\n'
                'bob,1,paid\nAlice,2,paid\n Bob ,3,paid\nbob,-0.50,paid\n')
        totals = summarize(text)
        self.assertEqual(list(totals.items()),
                         [('Alice', 200), ('Bob', 300), ('bob', 50)])
        self.assertEqual(render(totals), 'Alice\t200\nBob\t300\nbob\t50\n')

    def test_empty_input(self):
        for text in ['', '\ufeff', 'customer,amount,status\n']:
            with self.subTest(text=text):
                self.assertEqual(summarize(text), {})

if __name__ == '__main__':
    unittest.main()
