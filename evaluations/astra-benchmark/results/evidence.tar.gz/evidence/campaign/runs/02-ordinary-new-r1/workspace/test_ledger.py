import unittest
from ledger import summarize, render

class LedgerTests(unittest.TestCase):
    def test_basic(self):
        self.assertEqual(summarize('customer,amount,status\nA,1.20,paid\nB,2,open\n'), {'A': 120})

    def test_bom_whitespace_status_and_sorted_customers(self):
        text = ('\ufeff customer , amount , status , extra \n'
                ' zed , 1.20 , PAID , ignored \n'
                ' Alice , 2 , PaId , ignored \n'
                ' zed , .005 , paid , ignored \n'
                ' alice , 3 , paid , ignored \n')
        totals = summarize(text)
        self.assertEqual(list(totals.items()),
                         [('Alice', 200), ('alice', 300), ('zed', 121)])

    def test_each_row_rounds_half_up_including_refunds(self):
        text = ('customer,amount,status\n'
                'A,0.005,paid\nA,0.005,paid\n'
                'B,-0.005,paid\nB,-0.005,paid\n'
                'C,1.005,paid\nD,-1.005,paid\n')
        self.assertEqual(summarize(text), {'A': 2, 'B': -2, 'C': 101, 'D': -101})

    def test_large_decimal_amounts_remain_exact(self):
        text = ('customer,amount,status\n'
                'A,90071992547409.93,paid\n'
                'B,123456789012345678901234567890.125,paid\n')
        self.assertEqual(summarize(text),
                         {'A': 9007199254740993,
                          'B': 12345678901234567890123456789013})

    def test_blank_amounts_are_zero(self):
        self.assertEqual(summarize('customer,amount,status\nA,,paid\nB,   ,paid\n'),
                         {'A': 0, 'B': 0})

    def test_only_paid_amounts_are_validated(self):
        text = ('customer,amount,status\n'
                'A,invalid,open\nB,NaN,pending\nC,Infinity,\nD,1,paid\n')
        self.assertEqual(summarize(text), {'D': 100})

    def test_invalid_paid_amounts_report_row(self):
        for amount in ('invalid', '1.2.3', 'NaN', '-NaN', 'sNaN',
                       'Infinity', '-Infinity', 'inf'):
            with self.subTest(amount=amount):
                text = f'customer,amount,status\nA,1,paid\nB, {amount} , PAID \n'
                with self.assertRaisesRegex(ValueError, r'\brow 3\b'):
                    summarize(text)

    def test_multiline_customer_names(self):
        text = 'customer,amount,status\n" Alice\nSmith ",1.005,paid\n'
        self.assertEqual(summarize(text), {'Alice\nSmith': 101})

    def test_error_reports_physical_record_ending_line(self):
        text = ('customer,amount,status\n'
                '"Alice\nSmith",1,paid\n'
                '\n'
                '"Bob\nJones",invalid,paid\n')
        with self.assertRaisesRegex(ValueError, r'\brow 6\b'):
            summarize(text)

    def test_empty_csv(self):
        for text in ('', '\ufeff', 'customer,amount,status\n'):
            with self.subTest(text=text):
                self.assertEqual(summarize(text), {})

    def test_render(self):
        self.assertEqual(render({'A': 120}), 'A\t120\n')

if __name__ == '__main__':
    unittest.main()
