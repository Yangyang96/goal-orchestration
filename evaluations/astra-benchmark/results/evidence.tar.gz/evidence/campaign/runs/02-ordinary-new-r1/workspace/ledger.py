"""Summarize invoice CSV exports. All monetary output is exact, in cents."""
import csv
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP, localcontext
from io import StringIO


def summarize(text):
    """Return customer -> total cents, sorted by customer name.

    Input columns: customer, amount, status. Extra columns are ignored.
    Blank amounts count as zero. Only paid invoices are included.
    Amounts are rounded per row to cents using ROUND_HALF_UP.
    Refunds (negative amounts) are supported.
    Invalid paid amounts raise ValueError with the physical CSV row number.
    """
    totals = {}
    reader = csv.DictReader(StringIO(text.lstrip('\ufeff'), newline=''),
                            skipinitialspace=True)
    if reader.fieldnames is not None:
        reader.fieldnames = [name.strip() for name in reader.fieldnames]
    for row in reader:
        if (row['status'] or '').strip().lower() != 'paid':
            continue
        customer = row['customer'].strip()
        try:
            amount = Decimal((row['amount'] or '').strip() or '0')
            if not amount.is_finite():
                raise ValueError('amount must be finite')
            with localcontext() as context:
                # Keep large amounts exact, allowing a carry when rounding to cents.
                context.prec = max(context.prec, len(amount.as_tuple().digits),
                                   amount.adjusted() + 4)
                cents = int(amount.quantize(Decimal('0.01'),
                                            rounding=ROUND_HALF_UP) * 100)
        except (InvalidOperation, ValueError) as exc:
            raise ValueError(f'Invalid amount at row {reader.line_num}') from exc
        totals[customer] = totals.get(customer, 0) + cents
    return dict(sorted(totals.items()))


def render(totals):
    """Stable tab-separated report; no header."""
    return ''.join(f'{name}\t{cents}\n' for name, cents in totals.items())
