# Routebook

Load route tables from JSON using only the Python standard library.

## Python API

```python
from routebook import load_routes, load_routes_text

routes = load_routes('config.json')
routes = load_routes_text(
    '{"include": "defaults.json", "routes": {"home": "/home"}}',
    base_dir='configs',
)
```

Both functions return a new dictionary mapping route names to destinations and
share the same loading and validation logic. `load_routes(path)` accepts a string
or `pathlib.Path` and preserves the existing file API. The text API requires the
keyword-only `base_dir` argument, also a string or `pathlib.Path`, to locate the
first included file. A relative `base_dir` is interpreted from the current working
directory. Each nested include is relative to its containing file.

## Configuration and includes

Every config must be a JSON object with a `routes` object, including configs that
only include another file (`"routes": {}` is valid). Route names and destinations
must be strings.

For example, given `configs/defaults.json`:

```json
{"routes": {"home": "/old-home", "health": "/health"}}
```

and `configs/config.json`:

```json
{"include": "defaults.json", "routes": {"home": "/home"}}
```

Loading `configs/config.json` returns `{"home": "/home", "health": "/health"}`.
The optional `include` must be a nonempty relative filename; absolute paths are
rejected. Included files may themselves include other files, including through
`..` paths. At each level, local routes override included routes with the same
name and preserve other included routes.

Include cycles raise `ValueError` with `cycle` in the message. Cycle detection
uses resolved paths, including symlink resolution; separate files with the same
basename are allowed. File loading uses the resolved file's directory for includes.
Missing files propagate `FileNotFoundError`. Invalid JSON, malformed config
structures, non-string destinations and invalid include values raise `ValueError`.

## CLI

Read a file with the existing command:

```sh
python3 -m routebook configs/config.json
```

Or read JSON from stdin, resolving the first include from the current working
directory:

```sh
printf '%s\n' '{"include": "configs/defaults.json", "routes": {"home": "/home"}}' | python3 -m routebook --stdin
```

Both modes emit a JSON object on stdout with sorted keys and a trailing newline.
Provide exactly one input mode: combining `--stdin` with a config filename, or
providing neither, produces an argparse usage error (exit status 2).

## Tests

```sh
python3 -m unittest -v
```
