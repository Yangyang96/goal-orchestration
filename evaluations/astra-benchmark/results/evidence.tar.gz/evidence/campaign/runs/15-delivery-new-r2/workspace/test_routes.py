import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from routebook import load_routes, load_routes_text


PROJECT_DIR = Path(__file__).resolve().parent


class RouteTests(unittest.TestCase):
    def setUp(self):
        directory = tempfile.TemporaryDirectory(dir=PROJECT_DIR)
        self.addCleanup(directory.cleanup)
        self.folder = Path(directory.name)

    def write_config(self, name, data):
        path = self.folder / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(data))
        return path

    def test_legacy(self):
        routes = {'home': 'https://example.invalid'}
        path = self.write_config('routes.json', {'routes': routes})
        for argument in (path, str(path)):
            with self.subTest(argument=argument):
                self.assertEqual(load_routes(argument), routes)

    def test_text_api(self):
        for routes in ({}, {'': '', '首页': '/欢迎'}):
            for base_dir in (self.folder, str(self.folder)):
                with self.subTest(routes=routes, base_dir=base_dir):
                    self.assertEqual(
                        load_routes_text(json.dumps({'routes': routes}), base_dir=base_dir),
                        routes,
                    )

    def test_text_base_dir_is_required_and_keyword_only(self):
        with self.assertRaises(TypeError):
            load_routes_text('{"routes": {}}')
        with self.assertRaises(TypeError):
            load_routes_text('{"routes": {}}', self.folder)

    def test_nested_includes_same_basename_and_local_overrides(self):
        self.write_config('defaults/routes.json', {
            'routes': {'base': '/base', 'shared': '/base-shared', 'middle': '/base-middle'},
        })
        self.write_config('nested/routes.json', {
            'include': '../defaults/routes.json',
            'routes': {'shared': '/middle-shared', 'middle': '/middle'},
        })
        path = self.write_config('routes.json', {
            'include': 'nested/routes.json',
            'routes': {'shared': '/local', 'local': '/local-only'},
        })
        expected = {
            'base': '/base', 'middle': '/middle', 'shared': '/local', 'local': '/local-only',
        }
        self.assertEqual(load_routes(path), expected)
        self.assertEqual(load_routes_text(path.read_text(), base_dir=self.folder), expected)
        self.assertEqual(load_routes(self.folder / 'defaults/routes.json')['shared'], '/base-shared')

    def test_empty_local_routes_preserve_included_routes(self):
        self.write_config('base.json', {'routes': {'home': '/home'}})
        text = json.dumps({'include': 'base.json', 'routes': {}})
        self.assertEqual(load_routes_text(text, base_dir=self.folder), {'home': '/home'})

    def test_relative_base_dir(self):
        self.write_config('base.json', {'routes': {'home': '/home'}})
        base_dir = os.path.relpath(self.folder, Path.cwd())
        self.assertEqual(load_routes_text(
            '{"include": "base.json", "routes": {}}', base_dir=base_dir,
        ), {'home': '/home'})

    def assert_invalid_config(self, data):
        path = self.write_config('invalid.json', data)
        with self.assertRaises(ValueError):
            load_routes(path)
        with self.assertRaises(ValueError):
            load_routes_text(path.read_text(), base_dir=self.folder)
        with self.assertRaises(ValueError):
            load_routes_text(
                '{"include": "invalid.json", "routes": {}}', base_dir=self.folder,
            )

    def test_invalid_structures_in_root_and_included_configs(self):
        invalid = [None, True, 7, 'text', [], {}, {'include': 'base.json'}]
        invalid.extend({'routes': value} for value in (None, False, 3, 'text', []))
        invalid.extend({'routes': {'home': value}} for value in (None, False, 3, [], {}))
        for data in invalid:
            with self.subTest(data=data):
                self.assert_invalid_config(data)

    def test_invalid_includes(self):
        for include in ('', None, False, 1, [], {}, str(self.folder / 'absolute.json')):
            with self.subTest(include=include):
                self.assert_invalid_config({'include': include, 'routes': {}})

    def test_malformed_json(self):
        path = self.folder / 'invalid.json'
        for text in ('', '{', '{"routes": {},}'):
            with self.subTest(text=text):
                path.write_text(text)
                with self.assertRaises(ValueError):
                    load_routes_text(text, base_dir=self.folder)
                with self.assertRaises(ValueError):
                    load_routes(path)
                with self.assertRaises(ValueError):
                    load_routes_text(
                        '{"include": "invalid.json", "routes": {}}', base_dir=self.folder,
                    )

    def test_missing_root_and_nested_files(self):
        with self.assertRaises(FileNotFoundError):
            load_routes(self.folder / 'missing.json')
        path = self.write_config('routes.json', {'include': 'nested/base.json', 'routes': {}})
        self.write_config('nested/base.json', {'include': 'missing.json', 'routes': {}})
        with self.assertRaises(FileNotFoundError):
            load_routes(path)
        with self.assertRaises(FileNotFoundError):
            load_routes_text(path.read_text(), base_dir=self.folder)

    def test_self_include_cycles_use_resolved_paths(self):
        (self.folder / 'nested').mkdir()
        for include in ('routes.json', './routes.json', 'nested/../routes.json'):
            with self.subTest(include=include):
                path = self.write_config('routes.json', {'include': include, 'routes': {}})
                with self.assertRaisesRegex(ValueError, 'cycle'):
                    load_routes(path)
                with self.assertRaisesRegex(ValueError, 'cycle'):
                    load_routes_text(path.read_text(), base_dir=self.folder)

    def test_nested_include_cycle_and_recovery(self):
        path = self.write_config('routes.json', {'include': 'nested/base.json', 'routes': {}})
        self.write_config('nested/base.json', {'include': '../routes.json', 'routes': {}})
        with self.assertRaisesRegex(ValueError, 'cycle'):
            load_routes(path)
        with self.assertRaisesRegex(ValueError, 'cycle'):
            load_routes_text(path.read_text(), base_dir=self.folder)
        self.write_config('nested/base.json', {'routes': {'recovered': '/ok'}})
        self.assertEqual(load_routes(path), {'recovered': '/ok'})

    def test_symlink_include_cycle(self):
        path = self.write_config('routes.json', {'include': 'alias.json', 'routes': {}})
        try:
            (self.folder / 'alias.json').symlink_to(path.name)
        except (OSError, NotImplementedError):
            self.skipTest('symlinks are unavailable')
        with self.assertRaisesRegex(ValueError, 'cycle'):
            load_routes(path)
        with self.assertRaisesRegex(ValueError, 'cycle'):
            load_routes_text(path.read_text(), base_dir=self.folder)


class CLITests(unittest.TestCase):
    def setUp(self):
        directory = tempfile.TemporaryDirectory(dir=PROJECT_DIR)
        self.addCleanup(directory.cleanup)
        self.folder = Path(directory.name)

    def run_cli(self, *args, text=''):
        env = os.environ.copy()
        env['PYTHONPATH'] = os.pathsep.join(filter(None, (
            str(PROJECT_DIR), env.get('PYTHONPATH'),
        )))
        return subprocess.run(
            [sys.executable, '-m', 'routebook', *args], input=text,
            text=True, capture_output=True, cwd=self.folder, env=env, timeout=10,
        )

    def test_file_cli_output_unchanged(self):
        (self.folder / 'routes.json').write_text('{"routes": {"z": "/last", "a": "/first"}}')
        result = self.run_cli('routes.json')
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(result.stdout, '{"a": "/first", "z": "/last"}\n')
        self.assertEqual(result.stderr, '')

    def test_file_cli_resolves_include_from_config_directory(self):
        nested = self.folder / 'nested'
        nested.mkdir()
        (nested / 'base.json').write_text('{"routes": {"base": "/base", "home": "/old"}}')
        (nested / 'routes.json').write_text(
            '{"include": "base.json", "routes": {"home": "/new"}}',
        )
        result = self.run_cli('nested/routes.json')
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(json.loads(result.stdout), {'base': '/base', 'home': '/new'})

    def test_stdin_cli_without_include(self):
        result = self.run_cli('--stdin', text='{ "routes": {"z": "/last", "a": "/first"} }')
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(result.stdout, '{"a": "/first", "z": "/last"}\n')
        self.assertEqual(result.stderr, '')

    def test_stdin_cli_resolves_nested_includes_from_cwd(self):
        nested = self.folder / 'nested'
        nested.mkdir()
        (nested / 'base.json').write_text('{"routes": {"base": "/base", "home": "/old"}}')
        (self.folder / 'routes.json').write_text(
            '{"include": "nested/base.json", "routes": {"middle": "/middle"}}',
        )
        result = self.run_cli('--stdin', text='{"include": "routes.json", "routes": {"home": "/new"}}')
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(json.loads(result.stdout), {'base': '/base', 'home': '/new', 'middle': '/middle'})
        self.assertEqual(result.stderr, '')

    def test_invalid_argument_combinations_are_usage_errors(self):
        for args in ((), ('--stdin', 'missing.json'), ('missing.json', '--stdin')):
            with self.subTest(args=args):
                result = self.run_cli(*args, text='invalid JSON')
                self.assertEqual(result.returncode, 2)
                self.assertEqual(result.stdout, '')
                self.assertIn('usage:', result.stderr)
                self.assertNotIn('Traceback', result.stderr)


if __name__ == '__main__':
    unittest.main()
