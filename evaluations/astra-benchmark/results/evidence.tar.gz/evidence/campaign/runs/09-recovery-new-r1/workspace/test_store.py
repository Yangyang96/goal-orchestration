import sqlite3
import tempfile
import unittest
from pathlib import Path

from store import connect, import_events, list_events


class StoreTests(unittest.TestCase):
    def setUp(self):
        folder = tempfile.TemporaryDirectory(dir=Path(__file__).parent)
        self.addCleanup(folder.cleanup)
        self.path = Path(folder.name) / 'events.db'
        self.db = self.open_database()

    def open_database(self):
        db = connect(self.path)
        self.addCleanup(db.close)
        return db

    def assert_failed_batch_unchanged(self, batch, error=ValueError):
        original = [{'id': 'existing', 'payload': 'saved', 'source': 'queue'}]
        self.assertEqual(import_events(self.db, original), 1)
        before = list_events(self.db)
        with self.assertRaises(error):
            import_events(self.db, batch)
        self.assertFalse(self.db.in_transaction)
        self.assertEqual(list_events(self.db), before)
        self.assertEqual(list_events(self.open_database()), before)
        self.assertEqual(import_events(self.db, [{'id': 'later', 'payload': 'ok'}]), 1)
        self.assertEqual(list_events(self.open_database()), before + [('later', 'ok', 'legacy')])

    def test_fresh_database(self):
        db = connect(':memory:')
        self.addCleanup(db.close)
        self.assertEqual(import_events(db, [{'id': 'a', 'payload': 'value'}]), 1)
        self.assertEqual(list_events(db), [('a', 'value', 'legacy')])

    def test_legacy_database_migrates_in_place_and_reopens(self):
        legacy_path = self.path.with_name('legacy.db')
        old = sqlite3.connect(legacy_path)
        with old:
            old.execute('CREATE TABLE events (id TEXT PRIMARY KEY, payload TEXT NOT NULL)')
            old.executemany('INSERT INTO events VALUES (?, ?)', [('old-1', 'saved'), ('old-2', 'also saved')])
            old.execute('CREATE TABLE unrelated (value TEXT)')
            old.execute("INSERT INTO unrelated VALUES ('keep me')")
        old.close()

        expected = [('old-1', 'saved', 'legacy'), ('old-2', 'also saved', 'legacy')]
        for _ in range(3):
            db = connect(legacy_path)
            try:
                self.assertEqual(list_events(db), expected)
                self.assertEqual(db.execute('SELECT value FROM unrelated').fetchall(), [('keep me',)])
                self.assertEqual(import_events(db, [{'id': 'old-1', 'payload': 'saved'}]), 0)
                if len(expected) == 2:
                    self.assertEqual(import_events(db, [{'id': 'new', 'payload': 'hello', 'source': 'queue'}]), 1)
                    # The migrated schema must retain the SQL-level default, too.
                    with db:
                        db.execute("INSERT INTO events (id, payload) VALUES ('direct', 'default')")
                    expected = [('direct', 'default', 'legacy'), ('new', 'hello', 'queue')] + expected
            finally:
                db.close()

    def test_retries_and_duplicates_count_only_new_records(self):
        a = {'id': 'a', 'payload': 'first'}
        explicit_a = dict(a, source='legacy')
        b = {'id': 'b', 'payload': 'second', 'source': 'queue'}
        self.assertEqual(import_events(self.db, [a, explicit_a, b, b]), 2)
        self.assertEqual(import_events(self.db, [b, a, explicit_a]), 0)
        self.assertEqual(import_events(self.db, [a, {'id': 'c', 'payload': 'third'}, b]), 1)
        self.assertEqual(list_events(self.open_database()), [
            ('a', 'first', 'legacy'), ('b', 'second', 'queue'), ('c', 'third', 'legacy')])
        self.assertEqual(import_events(self.open_database(), [a, b]), 0)

    def test_empty_batch(self):
        self.assertEqual(import_events(self.db, iter(())), 0)
        self.assertEqual(list_events(self.db), [])
        self.assertFalse(self.db.in_transaction)

    def test_existing_payload_conflict_rolls_back_batch(self):
        self.assert_failed_batch_unchanged([
            {'id': 'new', 'payload': 'rollback'},
            {'id': 'existing', 'payload': 'changed', 'source': 'queue'},
        ])

    def test_existing_source_conflict_rolls_back_batch(self):
        self.assert_failed_batch_unchanged([
            {'id': 'new', 'payload': 'rollback'},
            {'id': 'existing', 'payload': 'saved'},
        ])

    def test_conflict_within_batch_rolls_back_batch(self):
        self.assert_failed_batch_unchanged([
            {'id': 'new', 'payload': 'same', 'source': 'first'},
            {'id': 'new', 'payload': 'same', 'source': 'second'},
        ])

    def test_invalid_fields_roll_back_batch(self):
        original = [{'id': 'existing', 'payload': 'saved'}]
        import_events(self.db, original)
        before = list_events(self.db)
        valid = {'id': 'invalid', 'payload': 'value', 'source': 'queue'}
        invalid_events = [None, 1, 'record', [], ()]
        for field in ('id', 'payload'):
            event = valid.copy()
            del event[field]
            invalid_events.append(event)
        for field in ('id', 'payload', 'source'):
            for value in ('', None, 0, 1, 1.5, False, b'bytes', [], {}):
                invalid_events.append(dict(valid, **{field: value}))
        for event in invalid_events:
            with self.subTest(event=event):
                with self.assertRaises(ValueError):
                    import_events(self.db, [{'id': 'new', 'payload': 'rollback'}, event])
                self.assertFalse(self.db.in_transaction)
                self.assertEqual(list_events(self.db), before)
                self.assertEqual(list_events(self.open_database()), before)
        self.assertEqual(import_events(self.db, [{'id': 'new', 'payload': 'ok'}]), 1)

    def test_invalid_duplicate_is_validated(self):
        self.assert_failed_batch_unchanged([
            {'id': 'new', 'payload': 'rollback'},
            {'id': 'existing', 'source': 'queue'},
        ])

    def test_generator_failure_rolls_back_batch(self):
        def broken_events():
            yield {'id': 'new-1', 'payload': 'rollback'}
            yield {'id': 'new-2', 'payload': 'rollback'}
            raise RuntimeError('input stream failed')

        self.assert_failed_batch_unchanged(broken_events(), RuntimeError)

    def test_generator_success(self):
        events = ({'id': str(i), 'payload': 'value'} for i in range(3))
        self.assertEqual(import_events(self.db, events), 3)
        self.assertEqual(list_events(self.open_database()), [
            ('0', 'value', 'legacy'), ('1', 'value', 'legacy'), ('2', 'value', 'legacy')])


if __name__ == '__main__':
    unittest.main()
