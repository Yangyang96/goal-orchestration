import unittest
from ledger import summarize, render

class LedgerTests(unittest.TestCase):
    def test_basic(self):
        self.assertEqual(summarize('customer,amount,status\nA,1.20,paid\nB,2,open\n'), {'A': 120})

    def test_bom_whitespace_status_and_customer_names(self):
        text = (
            '\ufeff customer , amount , status , extra \n'
            ' Bob , 1.005 , PaId , ignored\n'
            'Alice, 2 , PAID , ignored\n'
            'Bob, 1.995 , paid , ignored\n'
            ' alice ,   , paid , ignored\n'
        )
        totals = summarize(text)
        self.assertEqual(list(totals.items()), [('Alice', 200), ('Bob', 301), ('alice', 0)])
        self.assertEqual(render(totals), 'Alice\t200\nBob\t301\nalice\t0\n')

    def test_round_half_up_per_row_including_refunds(self):
        text = (
            'customer,amount,status\n'
            'A,1.005,paid\n'
            'A,0.005,paid\n'
            'A,0.004,paid\n'
            'B,-1.005,paid\n'
            'B,-0.005,paid\n'
            'B,-0.004,paid\n'
            'C,2.675,paid\n'
        )
        self.assertEqual(summarize(text), {'A': 102, 'B': -102, 'C': 268})

    def test_large_amounts_remain_exact(self):
        text = (
            'customer,amount,status\n'
            'A,123456789012345678901234567890.005,paid\n'
            f'B,{"9" * 30}.995,paid\n'
        )
        self.assertEqual(summarize(text), {
            'A': 12345678901234567890123456789001,
            'B': 10 ** 32,
        })

    def test_blank_amounts_are_zero(self):
        text = 'customer,amount,status\nA,,paid\nA,   ,paid\nB, -0.00 ,paid\n'
        self.assertEqual(summarize(text), {'A': 0, 'B': 0})

    def test_only_paid_amounts_are_validated(self):
        text = (
            'customer,amount,status\n'
            'A,not-a-number,open\n'
            'B,NaN,cancelled\n'
            'C,Infinity,\n'
            'D,1.25,paid\n'
        )
        self.assertEqual(summarize(text), {'D': 125})

    def test_invalid_paid_amounts_report_row(self):
        for amount in ('invalid', '1,23', 'NaN', '-NaN', 'sNaN', 'Infinity', '-Infinity', 'inf'):
            with self.subTest(amount=amount):
                text = f'customer,amount,status\nA," {amount} ",paid\n'
                with self.assertRaisesRegex(ValueError, r'\brow 2\b'):
                    summarize(text)

    def test_error_uses_physical_record_ending_line(self):
        for newline in ('\n', '\r\n'):
            for amount in ('invalid', 'NaN'):
                with self.subTest(newline=newline, amount=amount):
                    text = newline.join([
                        'customer,amount,status',
                        '',
                        '"Open',
                        'Customer",invalid,open',
                        '"Bad',
                        f'Customer",{amount},paid',
                        '',
                    ])
                    with self.assertRaisesRegex(ValueError, r'\brow 6\b'):
                        summarize(text)

    def test_quoted_multiline_customer(self):
        text = 'customer,amount,status\n" Alice\nSmith ",1.005,paid\n'
        self.assertEqual(summarize(text), {'Alice\nSmith': 101})

    def test_empty_exports(self):
        for text in ('', '\ufeff', 'customer,amount,status\n'):
            with self.subTest(text=text):
                self.assertEqual(summarize(text), {})

    def test_render(self):
        self.assertEqual(render({'A': 120}), 'A\t120\n')

if __name__ == '__main__':
    unittest.main()
