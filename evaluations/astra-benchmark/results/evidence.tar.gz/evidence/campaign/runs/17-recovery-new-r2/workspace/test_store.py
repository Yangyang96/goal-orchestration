import sqlite3
import tempfile
import unittest
from pathlib import Path

from store import connect, import_events, list_events


class StoreTests(unittest.TestCase):
    def setUp(self):
        folder = tempfile.TemporaryDirectory(dir=Path(__file__).parent)
        self.addCleanup(folder.cleanup)
        self.path = Path(folder.name) / 'events.db'
        self.db = connect(self.path)
        self.addCleanup(self.db.close)

    def test_fresh_database(self):
        self.assertEqual(import_events(self.db, [{'id': 'a', 'payload': 'value'}]), 1)
        self.assertEqual(list_events(self.db), [('a', 'value', 'legacy')])

    def test_legacy_migration_preserves_data_and_survives_reopen(self):
        path = self.path.with_name('legacy.db')
        old = sqlite3.connect(path)
        self.addCleanup(old.close)
        with old:
            old.execute('CREATE TABLE events (id TEXT PRIMARY KEY, payload TEXT NOT NULL)')
            old.executemany('INSERT INTO events VALUES (?, ?)', [('a', 'one'), ('b', 'two')])
            old.execute('CREATE TABLE metadata (value TEXT)')
            old.execute("INSERT INTO metadata VALUES ('keep')")
        old.close()

        expected = [('a', 'one', 'legacy'), ('b', 'two', 'legacy')]
        for _ in range(2):
            db = connect(path)
            self.addCleanup(db.close)
            self.assertEqual(list_events(db), expected)
            self.assertEqual(db.execute('SELECT * FROM metadata').fetchall(), [('keep',)])
            self.assertEqual(import_events(db, [{'id': 'a', 'payload': 'one'}]), 0)
            db.close()

        db = connect(path)
        self.addCleanup(db.close)
        with db:
            db.execute("INSERT INTO events (id, payload) VALUES ('c', 'three')")
        self.assertEqual(list_events(db), expected + [('c', 'three', 'legacy')])
        with self.assertRaises(sqlite3.IntegrityError), db:
            db.execute("INSERT INTO events VALUES ('d', 'four', NULL)")

    def test_retries_count_only_new_records_including_within_batch(self):
        first = {'id': 'a', 'payload': 'one'}
        explicit_default = dict(first, source='legacy')
        second = {'id': 'b', 'payload': 'two', 'source': 'queue'}
        batch = [first, explicit_default, second, second]
        self.assertEqual(import_events(self.db, iter(batch)), 2)
        self.assertEqual(import_events(self.db, batch), 0)
        self.db.close()
        self.db = connect(self.path)
        self.addCleanup(self.db.close)
        self.assertEqual(import_events(self.db, batch), 0)
        self.assertEqual(list_events(self.db), [('a', 'one', 'legacy'), ('b', 'two', 'queue')])

    def assert_batch_failure_is_atomic(self, events, error=ValueError):
        before = list_events(self.db)
        with self.assertRaises(error):
            import_events(self.db, events)
        self.assertEqual(list_events(self.db), before)
        self.assertFalse(self.db.in_transaction)
        observer = connect(self.path)
        try:
            self.assertEqual(list_events(observer), before)
        finally:
            observer.close()
        # Retrying on the same connection must work after any batch failure.
        self.assertEqual(import_events(self.db, [{'id': 'new', 'payload': 'valid'}]), 1)
        self.assertEqual(list_events(self.db), sorted(before + [('new', 'valid', 'legacy')]))
        with self.db:
            self.db.execute("DELETE FROM events WHERE id = 'new'")

    def test_conflicting_existing_id_rolls_back_batch(self):
        original = {'id': 'keep', 'payload': 'original', 'source': 'queue'}
        import_events(self.db, [original])
        for change in ({'payload': 'different'}, {'source': 'other'}):
            with self.subTest(change=change):
                self.assert_batch_failure_is_atomic([
                    {'id': 'new', 'payload': 'valid'},
                    original,
                    dict(original, **change),
                ])

    def test_conflicting_id_within_batch_rolls_back_batch(self):
        import_events(self.db, [{'id': 'keep', 'payload': 'original'}])
        first = {'id': 'new', 'payload': 'valid'}
        for change in ({'payload': 'different'}, {'source': 'other'}):
            with self.subTest(change=change):
                self.assert_batch_failure_is_atomic([first, first, dict(first, **change)])

    def test_invalid_fields_roll_back_batch(self):
        import_events(self.db, [{'id': 'keep', 'payload': 'original'}])
        first = {'id': 'new', 'payload': 'valid'}
        for field in ('id', 'payload', 'source'):
            for value in ('', None, 0, False, b'text', [], {}):
                with self.subTest(field=field, value=value):
                    invalid = dict(first, **{field: value})
                    self.assert_batch_failure_is_atomic([first, invalid])
        for field in ('id', 'payload'):
            with self.subTest(missing=field):
                invalid = dict(first)
                del invalid[field]
                self.assert_batch_failure_is_atomic([first, invalid])

    def test_non_mapping_record_rolls_back_batch(self):
        for record in (None, 12, 'event', []):
            with self.subTest(record=record):
                self.assert_batch_failure_is_atomic([
                    {'id': 'new', 'payload': 'valid'}, record,
                ])

    def test_generator_error_rolls_back_batch_and_propagates(self):
        import_events(self.db, [{'id': 'keep', 'payload': 'original'}])
        failure = RuntimeError('input stream failed')

        def events():
            yield {'id': 'new', 'payload': 'valid'}
            yield {'id': 'second', 'payload': 'also valid', 'source': 'queue'}
            raise failure

        self.assert_batch_failure_is_atomic(events(), RuntimeError)
        with self.assertRaises(RuntimeError) as caught:
            import_events(self.db, events())
        self.assertIs(caught.exception, failure)

    def test_empty_batch(self):
        import_events(self.db, [{'id': 'keep', 'payload': 'original'}])
        self.assertEqual(import_events(self.db, iter(())), 0)
        self.assertEqual(list_events(self.db), [('keep', 'original', 'legacy')])
        self.assertFalse(self.db.in_transaction)


if __name__ == '__main__':
    unittest.main()
