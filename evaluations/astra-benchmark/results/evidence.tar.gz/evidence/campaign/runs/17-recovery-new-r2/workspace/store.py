"""Small SQLite event store, upgraded in place from schema v1."""
import sqlite3
from collections.abc import Mapping


def connect(path):
    db = sqlite3.connect(path)
    try:
        with db:
            db.execute('BEGIN')
            db.execute(
                'CREATE TABLE IF NOT EXISTS events ('
                'id TEXT PRIMARY KEY, payload TEXT NOT NULL, '
                "source TEXT NOT NULL DEFAULT 'legacy')"
            )
            columns = {column[1] for column in db.execute('PRAGMA table_info(events)')}
            if 'source' not in columns:
                db.execute("ALTER TABLE events ADD COLUMN source TEXT NOT NULL DEFAULT 'legacy'")
    except BaseException:
        db.close()
        raise
    return db


def import_events(db, events):
    """Atomically import a batch; identical retries are idempotent.

    Return number of newly inserted records. Existing identical records count
    as zero. A reused id with different payload or source raises ValueError.
    Missing source means 'legacy'. Every id/payload/source must be a nonempty
    string. A failure must leave ALL rows in this batch unapplied.
    """
    inserted = 0
    with db:
        # The dedicated connection has no caller transaction. Include iteration
        # and validation in this transaction so input failures also roll it back.
        db.execute('BEGIN')
        for event in events:
            if not isinstance(event, Mapping):
                raise ValueError('Each event must be a mapping')
            values = (event.get('id'), event.get('payload'), event.get('source', 'legacy'))
            for field, value in zip(('id', 'payload', 'source'), values):
                if not isinstance(value, str) or not value:
                    raise ValueError(f'{field} must be a nonempty string')

            event_id, payload, source = values
            existing = db.execute(
                'SELECT payload,source FROM events WHERE id = ?', (event_id,)
            ).fetchone()
            if existing is not None:
                if existing != (payload, source):
                    raise ValueError(f'Conflicting event id: {event_id!r}')
                continue
            db.execute('INSERT INTO events (id,payload,source) VALUES (?,?,?)', values)
            inserted += 1
    return inserted


def list_events(db):
    return db.execute('SELECT id,payload,source FROM events ORDER BY id').fetchall()
