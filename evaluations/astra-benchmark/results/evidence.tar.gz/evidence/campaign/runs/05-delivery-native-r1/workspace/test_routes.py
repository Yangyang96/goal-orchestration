import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from routebook import load_routes, load_routes_text


class RouteTests(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory(dir=Path(__file__).resolve().parent)
        self.addCleanup(temporary.cleanup)
        self.folder = Path(temporary.name)

    def write_config(self, name, data):
        path = self.folder / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(data))
        return path

    def loaders(self, data):
        path = self.write_config('routes.json', data)
        return (
            ('file', lambda: load_routes(path)),
            ('text', lambda: load_routes_text(json.dumps(data), base_dir=self.folder)),
        )

    def test_legacy(self):
        p = self.write_config('routes.json', {'routes': {'home': 'https://example.invalid'}})
        self.assertEqual(load_routes(p), {'home': 'https://example.invalid'})

    def test_text_api(self):
        self.assertEqual(
            load_routes_text('{"routes": {"home": "/首页"}}', base_dir=str(self.folder)),
            {'home': '/首页'},
        )
        self.assertEqual(load_routes_text('{"routes": {}}', base_dir=self.folder), {})
        with self.assertRaises(TypeError):
            load_routes_text('{"routes": {}}')
        with self.assertRaises(TypeError):
            load_routes_text('{"routes": {}}', self.folder)

    def test_recursive_includes_and_local_overrides(self):
        self.write_config('shared/common.json', {
            'routes': {'home': '/base', 'shared': '/shared', 'nested': '/base'},
        })
        self.write_config('defaults/routes.json', {
            'include': '../shared/common.json',
            'routes': {'home': '/default', 'nested': '/nested'},
        })
        data = {'include': 'defaults/routes.json', 'routes': {'home': '/local'}}
        expected = {'home': '/local', 'shared': '/shared', 'nested': '/nested'}
        for name, load in self.loaders(data):
            with self.subTest(api=name):
                self.assertEqual(load(), expected)

    def test_empty_local_routes_preserve_included_routes(self):
        self.write_config('base.json', {'routes': {'home': '/base'}})
        for name, load in self.loaders({'include': 'base.json', 'routes': {}}):
            with self.subTest(api=name):
                self.assertEqual(load(), {'home': '/base'})

    def test_invalid_structures(self):
        invalid = [
            None, [], 'config', 1, True, {},
            {'routes': None}, {'routes': []}, {'routes': 'home'}, {'routes': 1},
            {'routes': {'home': None}}, {'routes': {'home': 1}},
            {'routes': {'home': True}}, {'routes': {'home': []}},
            {'routes': {'home': {}}},
        ]
        invalid.extend({'routes': {}, 'include': include} for include in (
            None, '', 1, True, [], {}, str(self.folder / 'absolute.json'),
        ))
        for data in invalid:
            for name, load in self.loaders(data):
                with self.subTest(api=name, data=data):
                    with self.assertRaises(ValueError):
                        load()

    def test_invalid_included_structures(self):
        for included in ({}, [], {'routes': {'home': 1}}, {'routes': {}, 'include': None}):
            self.write_config('invalid.json', included)
            data = {'include': 'invalid.json', 'routes': {'home': '/local'}}
            for name, load in self.loaders(data):
                with self.subTest(api=name, included=included):
                    with self.assertRaises(ValueError):
                        load()

    def test_malformed_json(self):
        path = self.folder / 'malformed.json'
        path.write_text('{')
        with self.assertRaises(ValueError):
            load_routes(path)
        with self.assertRaises(ValueError):
            load_routes_text('{', base_dir=self.folder)
        for name, load in self.loaders({'include': path.name, 'routes': {}}):
            with self.subTest(api=name):
                with self.assertRaises(ValueError):
                    load()

    def test_missing_files(self):
        with self.assertRaises(FileNotFoundError):
            load_routes(self.folder / 'missing.json')
        self.write_config('nested.json', {'include': 'missing.json', 'routes': {}})
        for include in ('missing.json', 'nested.json'):
            for name, load in self.loaders({'include': include, 'routes': {}}):
                with self.subTest(api=name, include=include):
                    with self.assertRaises(FileNotFoundError):
                        load()

    def test_self_cycle(self):
        for name, load in self.loaders({'include': 'routes.json', 'routes': {}}):
            with self.subTest(api=name):
                with self.assertRaisesRegex(ValueError, 'cycle'):
                    load()

    def test_indirect_cycle_uses_resolved_paths(self):
        self.write_config('nested/child.json', {'include': '.././routes.json', 'routes': {}})
        data = {'include': 'nested/child.json', 'routes': {}}
        for name, load in self.loaders(data):
            with self.subTest(api=name):
                with self.assertRaisesRegex(ValueError, 'cycle'):
                    load()

    def test_symlink_cycle(self):
        data = {'include': 'alias.json', 'routes': {}}
        path = self.write_config('routes.json', data)
        (self.folder / 'alias.json').symlink_to(path)
        for name, load in self.loaders(data):
            with self.subTest(api=name):
                with self.assertRaisesRegex(ValueError, 'cycle'):
                    load()

    def test_cycle_tracking_is_per_load(self):
        path = self.write_config('routes.json', {'include': 'routes.json', 'routes': {}})
        with self.assertRaisesRegex(ValueError, 'cycle'):
            load_routes(path)
        self.write_config('routes.json', {'routes': {'home': '/fixed'}})
        self.assertEqual(load_routes(path), {'home': '/fixed'})
        self.assertEqual(load_routes(path), {'home': '/fixed'})


class CliTests(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory(dir=Path(__file__).resolve().parent)
        self.addCleanup(temporary.cleanup)
        self.folder = Path(temporary.name)

    def run_cli(self, *args, stdin=''):
        env = os.environ.copy()
        env['PYTHONPATH'] = str(Path(__file__).resolve().parent)
        return subprocess.run(
            [sys.executable, '-m', 'routebook', *args],
            input=stdin, text=True, capture_output=True, cwd=self.folder, env=env,
            timeout=10,
        )

    def test_file_cli_output(self):
        (self.folder / 'routes.json').write_text('{"routes": {"z": "/z", "a": "/a"}}')
        result = self.run_cli('routes.json')
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(result.stdout, '{"a": "/a", "z": "/z"}\n')
        self.assertEqual(result.stderr, '')

    def test_file_cli_includes_relative_to_config(self):
        nested = self.folder / 'nested'
        nested.mkdir()
        (nested / 'base.json').write_text('{"routes": {"home": "/base"}}')
        (nested / 'routes.json').write_text('{"include": "base.json", "routes": {}}')
        result = self.run_cli('nested/routes.json')
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(json.loads(result.stdout), {'home': '/base'})

    def test_stdin_cli_includes_from_cwd(self):
        nested = self.folder / 'nested'
        nested.mkdir()
        (nested / 'base.json').write_text('{"routes": {"home": "/base", "shared": "/shared"}}')
        (nested / 'routes.json').write_text('{"include": "base.json", "routes": {}}')
        result = self.run_cli('--stdin', stdin=json.dumps({
            'include': 'nested/routes.json', 'routes': {'home': '/stdin'},
        }))
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(json.loads(result.stdout), {'home': '/stdin', 'shared': '/shared'})
        self.assertEqual(result.stderr, '')

    def test_stdin_cli_without_include(self):
        result = self.run_cli('--stdin', stdin='{"routes": {"home": "/stdin"}}')
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(json.loads(result.stdout), {'home': '/stdin'})

    def test_cli_requires_exactly_one_input(self):
        for args in ((), ('--stdin', 'missing.json'), ('missing.json', '--stdin')):
            with self.subTest(args=args):
                result = self.run_cli(*args, stdin='not JSON')
                self.assertEqual(result.returncode, 2, result.stderr)
                self.assertIn('usage:', result.stderr)
                self.assertNotIn('Traceback', result.stderr)
                self.assertEqual(result.stdout, '')


if __name__ == '__main__':
    unittest.main()
