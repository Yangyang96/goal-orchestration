# Routebook

Load route destinations from JSON using only the Python standard library.

## Python API

```python
from routebook import load_routes, load_routes_text

routes = load_routes('config.json')
routes = load_routes_text(
    '{"include": "defaults.json", "routes": {"home": "/local"}}',
    base_dir='configs',
)
```

Both functions return a dictionary of route names to destinations and share the
same loading and validation logic. The existing `load_routes(path)` API accepts
a string or path-like file path. `load_routes_text(text, *, base_dir)` accepts
JSON text and requires a keyword-only string or path-like `base_dir` for resolving
its first include. A relative `base_dir` is interpreted from the current working
directory.

## Configuration and includes

Every configuration must be a JSON object with a `routes` object, even when it
includes another file. Route keys and destinations must be strings; an empty
`routes` object is valid. An optional `include` must be a nonempty relative
filename; absolute paths are rejected.

For example, `configs/defaults.json`:

```json
{"routes": {"home": "/default", "health": "/health"}}
```

And `configs/config.json`:

```json
{"include": "defaults.json", "routes": {"home": "/local"}}
```

Loading `configs/config.json` returns
`{"home": "/local", "health": "/health"}`. Includes are loaded recursively,
and each configuration's local routes override the included routes. Each file's
include is resolved relative to that file's resolved parent directory, including
nested paths such as `../shared/routes.json`.

Cycles are detected using resolved file paths, including symlink aliases, and
raise `ValueError` with `cycle` in the message. Separate files with the same
basename are allowed. Missing files raise `FileNotFoundError`; invalid JSON or
malformed configuration structures raise `ValueError`, including in nested files.

## CLI

```sh
python3 -m routebook configs/config.json
echo '{"include": "configs/config.json", "routes": {}}' | python3 -m routebook --stdin
```

Both modes emit a JSON object on stdout with sorted keys and a trailing newline.
File mode resolves includes from the config file's directory. `--stdin` reads JSON
from standard input and resolves the first include from the current working
directory; nested includes use their containing file's directory.

Provide exactly one input mode: a positional config file or `--stdin`. Combining
them, or providing neither, is an argparse usage error with exit status 2.

## Tests

```sh
python3 -m unittest -v
```
