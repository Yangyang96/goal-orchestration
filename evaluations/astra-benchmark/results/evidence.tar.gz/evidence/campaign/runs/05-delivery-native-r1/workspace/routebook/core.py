"""Load route tables from JSON files or text, with relative includes."""
import json
from pathlib import Path


def load_routes(path):
    """Legacy API: return {route_name: destination} from a JSON file."""
    return _load_file(Path(path), set())


def load_routes_text(text, *, base_dir):
    """Load JSON text, resolving its include relative to base_dir."""
    return _load_text(text, Path(base_dir), set())


def _load_file(path, active_paths):
    path = path.resolve()
    if path in active_paths:
        raise ValueError(f'include cycle: {path}')
    active_paths.add(path)
    try:
        return _load_text(path.read_text(), path.parent, active_paths)
    finally:
        active_paths.remove(path)


def _load_text(text, base_dir, active_paths):
    data = json.loads(text)
    if not isinstance(data, dict):
        raise ValueError('config must be an object')
    routes = data.get('routes')
    if not isinstance(routes, dict):
        raise ValueError('routes must be an object')
    if any(not isinstance(key, str) or not isinstance(value, str)
           for key, value in routes.items()):
        raise ValueError('route keys and destinations must be strings')

    result = {}
    if 'include' in data:
        include = data['include']
        if not isinstance(include, str) or not include:
            raise ValueError('include must be a nonempty string')
        if Path(include).is_absolute():
            raise ValueError('include must be a relative path')
        result = _load_file(base_dir / include, active_paths)
    result.update(routes)
    return result
