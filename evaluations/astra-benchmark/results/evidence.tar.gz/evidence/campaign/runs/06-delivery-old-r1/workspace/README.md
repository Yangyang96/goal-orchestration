# Routebook

Load route destinations from JSON using only the Python standard library.

## Python API

```python
from routebook import load_routes, load_routes_text

routes = load_routes('config.json')
routes_from_text = load_routes_text(
    '{"include": "base.json", "routes": {"home": "/home"}}',
    base_dir='.',
)
```

Both APIs return a new dictionary mapping route names to destinations and share
the same loading and validation logic. The existing `load_routes(path)` accepts
a string or `pathlib.Path`. `load_routes_text(text, *, base_dir)` accepts JSON text
and requires a keyword-only base directory (a string or `pathlib.Path`).

## Configuration and includes

Every configuration must be a JSON object with a `routes` object, including
configurations that only include another file (use `"routes": {}`). Route names
and destinations must be strings.

For example, given `shared/base.json`:

```json
{"routes": {"home": "/old-home", "help": "/help"}}
```

and `config.json` beside the `shared` directory:

```json
{"include": "shared/base.json", "routes": {"home": "/home"}}
```

loading `config.json` returns `{"home": "/home", "help": "/help"}`. Included routes
are loaded first; local routes override matching names at each level.

The optional `include` must be a nonempty string containing a relative JSON file
path; absolute paths are rejected. Each included file may itself include another
file, resolved relative to its own directory. Parent paths such as `../base.json`
are supported. The first include in JSON text is resolved relative to `base_dir`.
File paths are resolved before loading, so symbolic links use the target file's
directory for nested includes.

Cycles are detected using resolved file paths, including aliases through `..`
or symbolic links, and raise `ValueError` with `cycle` in the message. Separate
files with the same basename are allowed. Missing files propagate
`FileNotFoundError`; malformed JSON or configuration structures raise `ValueError`,
including errors in included files.

## CLI

Read a configuration file, resolving includes beside that file:

```sh
python3 -m routebook config.json
```

Or read JSON from stdin, resolving its first include from the current working
directory:

```sh
printf '%s\n' '{"include": "shared/base.json", "routes": {"home": "/home"}}' | python3 -m routebook --stdin
```

Both modes emit a JSON object with sorted keys and a trailing newline on stdout.
Exactly one input mode is required: combining `--stdin` with a positional config,
or supplying neither, produces an argparse usage error on stderr with exit code 2.

## Tests

Run the library and CLI regression tests with `python3 -m unittest -v`.
Python cache files are ignored by Git.
