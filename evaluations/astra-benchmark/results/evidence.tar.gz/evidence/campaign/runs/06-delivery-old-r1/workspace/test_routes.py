import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from routebook import load_routes, load_routes_text


ROOT = Path(__file__).resolve().parent


class RouteTests(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory(dir=ROOT, prefix='.routebook-test-')
        self.addCleanup(temporary.cleanup)
        self.folder = Path(temporary.name)

    def write_config(self, name, data):
        path = self.folder / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(data))
        return path

    def load_config(self, data, source):
        if source == 'text':
            return load_routes_text(json.dumps(data), base_dir=str(self.folder))
        return load_routes(self.write_config('main.json', data))

    def test_legacy(self):
        p = self.write_config('routes.json', {'routes': {'home': 'https://example.invalid'}})
        for path in (p, str(p)):
            with self.subTest(path=path):
                self.assertEqual(load_routes(path), {'home': 'https://example.invalid'})

    def test_text_without_include(self):
        self.assertEqual(
            load_routes_text('{"routes": {"home": "/home"}}', base_dir=self.folder),
            {'home': '/home'},
        )
        self.assertEqual(load_routes_text('{"routes": {}}', base_dir=self.folder), {})

    def test_text_requires_keyword_base_dir(self):
        with self.assertRaises(TypeError):
            load_routes_text('{"routes": {}}')
        with self.assertRaises(TypeError):
            load_routes_text('{"routes": {}}', self.folder)

    def test_recursive_include_and_local_overrides(self):
        self.write_config('shared/base.json', {
            'routes': {'base': '/base', 'middle': '/old-middle', 'home': '/old-home'},
        })
        self.write_config('nested/middle.json', {
            'include': '../shared/base.json',
            'routes': {'middle': '/middle', 'home': '/middle-home'},
        })
        data = {'include': 'nested/middle.json', 'routes': {'home': '/home', 'local': '/local'}}
        for source in ('file', 'text'):
            with self.subTest(source=source):
                self.assertEqual(self.load_config(data, source), {
                    'base': '/base', 'middle': '/middle', 'home': '/home', 'local': '/local',
                })

    def test_include_with_empty_local_routes(self):
        self.write_config('base.json', {'routes': {'home': '/home'}})
        for source in ('file', 'text'):
            with self.subTest(source=source):
                self.assertEqual(self.load_config({
                    'include': 'base.json', 'routes': {},
                }, source), {'home': '/home'})

    def test_separate_files_with_same_basename_are_not_cycles(self):
        self.write_config('nested/main.json', {'routes': {'base': '/base'}})
        for source in ('file', 'text'):
            with self.subTest(source=source):
                self.assertEqual(self.load_config({
                    'include': 'nested/main.json', 'routes': {'local': '/local'},
                }, source), {'base': '/base', 'local': '/local'})

    def test_invalid_structures(self):
        cases = [
            None, [], 'config', 3, True, {}, {'include': 'missing.json'},
            *({'routes': value} for value in (None, [], 'routes', 3, True)),
            *({'routes': {'home': value}} for value in (None, [], {}, 3, True)),
            *({'routes': {}, 'include': value} for value in (None, '', [], {}, 3, True)),
            {'routes': {}, 'include': str(self.folder / 'absolute.json')},
        ]
        for source in ('file', 'text'):
            for data in cases:
                with self.subTest(source=source, data=data):
                    with self.assertRaises(ValueError):
                        self.load_config(data, source)

    def test_invalid_included_structures(self):
        for source in ('file', 'text'):
            for data in ([], {}, {'routes': []}, {'routes': {'home': 42}},
                         {'routes': {}, 'include': None}):
                with self.subTest(source=source, data=data):
                    self.write_config('base.json', data)
                    self.write_config('middle.json', {'include': 'base.json', 'routes': {}})
                    with self.assertRaises(ValueError):
                        self.load_config({
                            'include': 'middle.json', 'routes': {'home': '/override'},
                        }, source)

    def test_malformed_json(self):
        for text in ('', '{', '{"routes": {1: "/home"}}'):
            with self.subTest(text=text):
                with self.assertRaises(ValueError):
                    load_routes_text(text, base_dir=self.folder)
                path = self.folder / 'bad.json'
                path.write_text(text)
                with self.assertRaises(ValueError):
                    load_routes(path)
                for source in ('file', 'text'):
                    with self.subTest(source=source):
                        with self.assertRaises(ValueError):
                            self.load_config({'include': 'bad.json', 'routes': {}}, source)

    def test_missing_files_propagate(self):
        with self.assertRaises(FileNotFoundError):
            load_routes(self.folder / 'missing.json')
        self.write_config('middle.json', {'include': 'missing.json', 'routes': {}})
        for source in ('file', 'text'):
            for include in ('missing.json', 'middle.json'):
                with self.subTest(source=source, include=include):
                    with self.assertRaises(FileNotFoundError):
                        self.load_config({'include': include, 'routes': {}}, source)

    def test_direct_cycle_uses_resolved_paths(self):
        (self.folder / 'nested').mkdir()
        data = {'include': 'nested/../main.json', 'routes': {}}
        self.write_config('main.json', data)
        for source in ('file', 'text'):
            with self.subTest(source=source):
                with self.assertRaisesRegex(ValueError, 'cycle'):
                    self.load_config(data, source)

    def test_indirect_cycle(self):
        self.write_config('nested/child.json', {'include': '../main.json', 'routes': {}})
        data = {'include': 'nested/child.json', 'routes': {}}
        self.write_config('main.json', data)
        for source in ('file', 'text'):
            with self.subTest(source=source):
                with self.assertRaisesRegex(ValueError, 'cycle'):
                    self.load_config(data, source)

    def test_symlink_cycle(self):
        data = {'include': 'alias.json', 'routes': {}}
        path = self.write_config('main.json', data)
        (self.folder / 'alias.json').symlink_to(path)
        for source in ('file', 'text'):
            with self.subTest(source=source):
                with self.assertRaisesRegex(ValueError, 'cycle'):
                    self.load_config(data, source)

    def test_loads_do_not_share_state(self):
        path = self.write_config('main.json', {'include': 'main.json', 'routes': {}})
        with self.assertRaisesRegex(ValueError, 'cycle'):
            load_routes(path)
        self.write_config('main.json', {'routes': {'home': '/home'}})
        routes = load_routes(path)
        routes['home'] = '/changed'
        self.assertEqual(load_routes(path), {'home': '/home'})


class CliTests(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory(dir=ROOT, prefix='.routebook-test-')
        self.addCleanup(temporary.cleanup)
        self.folder = Path(temporary.name)

    def run_cli(self, *args, text=''):
        env = os.environ.copy()
        env['PYTHONPATH'] = str(ROOT)
        return subprocess.run(
            [sys.executable, '-m', 'routebook', *args],
            input=text, text=True, capture_output=True, cwd=self.folder, env=env, timeout=10,
        )

    def test_file_cli_output_is_compatible(self):
        (self.folder / 'routes.json').write_text(json.dumps({'routes': {'z': '/z', 'a': '/a'}}))
        result = self.run_cli('routes.json')
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(result.stdout, '{"a": "/a", "z": "/z"}\n')
        self.assertEqual(result.stderr, '')

    def test_file_cli_resolves_include_beside_config(self):
        nested = self.folder / 'nested'
        nested.mkdir()
        (nested / 'base.json').write_text('{"routes": {"base": "/base", "home": "/old"}}')
        (nested / 'main.json').write_text('{"include": "base.json", "routes": {"home": "/home"}}')
        result = self.run_cli('nested/main.json')
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(json.loads(result.stdout), {'base': '/base', 'home': '/home'})

    def test_stdin_cli_resolves_recursive_includes_from_cwd(self):
        nested = self.folder / 'nested'
        nested.mkdir()
        (self.folder / 'base.json').write_text('{"routes": {"base": "/base", "home": "/old"}}')
        (nested / 'child.json').write_text('{"include": "../base.json", "routes": {"child": "/child"}}')
        result = self.run_cli('--stdin', text=json.dumps({
            'include': 'nested/child.json', 'routes': {'home': '/home'},
        }))
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(result.stdout, '{"base": "/base", "child": "/child", "home": "/home"}\n')
        self.assertEqual(result.stderr, '')

    def test_stdin_cli_without_include(self):
        result = self.run_cli('--stdin', text='{"routes": {"home": "/home"}}')
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(json.loads(result.stdout), {'home': '/home'})

    def test_invalid_argument_combinations_are_usage_errors(self):
        for args in ((), ('--stdin', 'missing.json'), ('missing.json', '--stdin')):
            with self.subTest(args=args):
                result = self.run_cli(*args, text='not JSON')
                self.assertEqual(result.returncode, 2, result.stderr)
                self.assertIn('usage:', result.stderr)
                self.assertIn('error:', result.stderr)
                self.assertNotIn('Traceback', result.stderr)
                self.assertEqual(result.stdout, '')


if __name__ == '__main__':
    unittest.main()
