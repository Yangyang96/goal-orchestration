import argparse
import json
import sys
from pathlib import Path
from .core import load_routes, load_routes_text


def main():
    parser = argparse.ArgumentParser(description='Read route destinations')
    parser.add_argument('config', nargs='?', help='JSON configuration file')
    parser.add_argument('--stdin', action='store_true', help='read JSON from stdin')
    args = parser.parse_args()
    if args.stdin and args.config is not None:
        parser.error('--stdin cannot be combined with a config')
    if not args.stdin and args.config is None:
        parser.error('a config or --stdin is required')
    if args.stdin:
        routes = load_routes_text(sys.stdin.read(), base_dir=Path.cwd())
    else:
        routes = load_routes(args.config)
    print(json.dumps(routes, sort_keys=True))


if __name__ == '__main__':
    main()
