"""Summarize invoice CSV exports. All monetary output is exact, in cents."""
import csv
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from io import StringIO


def summarize(text):
    """Return customer -> total cents, sorted by customer name.

    Input columns: customer, amount, status. Extra columns are ignored.
    Blank amounts count as zero. Only paid invoices are included.
    Amounts are rounded per row to cents using ROUND_HALF_UP.
    Refunds (negative amounts) are supported.
    Invalid paid amounts raise ValueError with the physical CSV row number.
    """
    totals = {}
    reader = csv.DictReader(StringIO(text.lstrip('\ufeff'), newline=''))
    reader.fieldnames = [name.strip() for name in (reader.fieldnames or [])]
    for row in reader:
        if (row['status'] or '').strip().casefold() != 'paid':
            continue
        customer = row['customer'].strip()
        try:
            amount = Decimal((row['amount'] or '').strip() or '0')
            if not amount.is_finite():
                raise ValueError('amount must be finite')
            # Shift to cents exactly, without Decimal context precision loss.
            sign, digits, exponent = amount.as_tuple()
            cents = int(Decimal((sign, digits, exponent + 2)).to_integral_value(
                rounding=ROUND_HALF_UP))
        except (InvalidOperation, ValueError) as exc:
            raise ValueError(f'invalid amount at row {reader.line_num}') from exc
        totals[customer] = totals.get(customer, 0) + cents
    return dict(sorted(totals.items()))


def render(totals):
    """Stable tab-separated report; no header."""
    return ''.join(f'{name}\t{cents}\n' for name, cents in totals.items())
