import unittest
from ledger import summarize, render

class LedgerTests(unittest.TestCase):
    def test_basic(self):
        self.assertEqual(summarize('customer,amount,status\nA,1.20,paid\nB,2,open\n'), {'A': 120})

    def test_render(self):
        self.assertEqual(render({'A': 120}), 'A\t120\n')

    def test_bom_whitespace_status_and_customer_order(self):
        text = ('\ufeff customer , amount , status , extra \n'
                ' Bob , 1.20 , PAID ,ignored\n'
                ' Alice , 2 , pAiD ,ignored\n'
                ' Bob , .30 , paid ,ignored\n'
                ' alice , .01 , Paid ,ignored\n')
        totals = summarize(text)
        self.assertEqual(totals, {'Alice': 200, 'Bob': 150, 'alice': 1})
        self.assertEqual(render(totals), 'Alice\t200\nBob\t150\nalice\t1\n')

    def test_rounds_each_row_half_up_including_refunds(self):
        text = ('customer,amount,status\n'
                'A,.005,paid\n'
                'A,.005,paid\n'
                'B,-.005,paid\n'
                'B,-.005,paid\n'
                'C,1.005,paid\n'
                'D,-1.005,paid\n'
                'E,.0049,paid\n'
                'F,-.0049,paid\n')
        self.assertEqual(summarize(text),
                         {'A': 2, 'B': -2, 'C': 101, 'D': -101, 'E': 0, 'F': 0})

    def test_large_amount_keeps_all_decimal_digits(self):
        text = 'customer,amount,status\nA,123456789012345678901234567890.005,paid\n'
        self.assertEqual(summarize(text), {'A': 12345678901234567890123456789001})

    def test_blank_amounts_are_zero(self):
        self.assertEqual(summarize('customer,amount,status\nA,,paid\nB,   ,paid\n'),
                         {'A': 0, 'B': 0})

    def test_only_paid_amounts_are_validated(self):
        text = ('customer,amount,status\n'
                'A,not-a-number,open\n'
                'B,NaN,pending\n'
                'C,Infinity,\n'
                'D,1e-2,paid\n')
        self.assertEqual(summarize(text), {'D': 1})

    def test_invalid_paid_amount_reports_row(self):
        for amount in ('oops', '1.2.3', 'NaN', '-NaN', 'sNaN', 'Infinity', '-Inf', 'inf'):
            with self.subTest(amount=amount):
                with self.assertRaisesRegex(ValueError, r'\brow 2\b'):
                    summarize(f'customer,amount,status\nA,{amount},paid\n')

    def test_error_uses_physical_ending_line_of_record(self):
        text = ('customer,amount,status\n'
                '\n'
                'Skipped,invalid,open\n'
                '"Acme\nLtd",invalid,paid\n')
        with self.assertRaisesRegex(ValueError, r'\brow 5\b'):
            summarize(text)

    def test_quoted_multiline_customer(self):
        text = 'customer,amount,status\n" Acme\nLtd ",1.005,paid\n'
        self.assertEqual(summarize(text), {'Acme\nLtd': 101})

    def test_empty_input(self):
        for text in ('', '\ufeff', 'customer,amount,status\n'):
            with self.subTest(text=text):
                self.assertEqual(summarize(text), {})

if __name__ == '__main__':
    unittest.main()
