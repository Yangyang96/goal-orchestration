# Routebook

Load route tables from JSON files or text using only the Python standard library.

## Configuration and includes

Every config must be a JSON object with a `routes` object. Route names and
destinations must be strings; an empty `routes` object is valid.

An optional `include` names one JSON file to load first. It must be a nonempty
relative path; absolute paths are invalid. Includes may themselves include other
files. Each file resolves its include relative to its own directory (after
resolving symlinks), and its local routes override inherited routes with the same
name. Relative paths may contain `..`.

For example, `config/base.json`:

```json
{"routes": {"home": "https://example.invalid", "docs": "https://example.invalid/docs"}}
```

And `config/routes.json`:

```json
{"include": "base.json", "routes": {"home": "https://local.invalid"}}
```

Loading `config/routes.json` returns:

```json
{"docs": "https://example.invalid/docs", "home": "https://local.invalid"}
```

All included configs are validated, even when their routes are overridden.
Missing files raise `FileNotFoundError`; malformed JSON or config structures raise
`ValueError`. Include cycles raise `ValueError` with `cycle` in the message.
Cycle checks use resolved full paths, so aliases of the same file are detected
while different files with the same basename are allowed.

## Python API

```python
from routebook import load_routes, load_routes_text

routes = load_routes('config/routes.json')
routes_from_text = load_routes_text(
    '{"include": "base.json", "routes": {"home": "https://local.invalid"}}',
    base_dir='config',
)
```

Both functions return a dictionary of route names to destinations and share the
same parsing, validation and include logic. The existing `load_routes(path)` API
accepts a string or path-like object. `load_routes_text(text, *, base_dir)` requires
an explicit keyword-only `base_dir` (string or path-like object) to resolve the
text's include. Subsequent includes resolve relative to their containing files.

## CLI

Read a file, resolving includes from that file's directory:

```sh
python3 -m routebook config/routes.json
```

Read JSON from stdin, resolving its include from the current working directory:

```sh
printf '%s\n' '{"include": "config/base.json", "routes": {}}' | python3 -m routebook --stdin
```

Both modes emit a JSON object with sorted keys and a trailing newline on stdout.
Provide exactly one input mode: combining `--stdin` with a config path, or
providing neither, produces an argparse usage error on stderr with exit code 2.

## Tests

Run the regression suite with `python3 -m unittest -v`.
Python cache files are ignored by Git. Keep personal changes in `NOTES.md`
uncommitted and outside implementation commits.
