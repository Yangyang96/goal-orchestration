"""Load route tables from JSON files or text, with recursive includes."""
import json
from pathlib import Path


def load_routes(path):
    """Return routes from a JSON file, resolving includes beside each file."""
    return _load_routes_file(Path(path), set())


def load_routes_text(text, *, base_dir):
    """Return routes from JSON text, resolving its include from base_dir."""
    return _load_routes_text(text, Path(base_dir), set())


def _load_routes_file(path, active_paths):
    path = path.resolve()
    if path in active_paths:
        raise ValueError(f'include cycle detected: {path}')
    active_paths.add(path)
    try:
        return _load_routes_text(path.read_text(), path.parent, active_paths)
    finally:
        active_paths.remove(path)


def _load_routes_text(text, base_dir, active_paths):
    data = json.loads(text)
    if not isinstance(data, dict):
        raise ValueError('config must be an object')
    routes = data.get('routes')
    if not isinstance(routes, dict):
        raise ValueError('routes must be an object')
    if any(not isinstance(key, str) or not isinstance(value, str)
           for key, value in routes.items()):
        raise ValueError('route names and destinations must be strings')

    merged = {}
    if 'include' in data:
        include = data['include']
        if not isinstance(include, str) or not include:
            raise ValueError('include must be a nonempty relative filename')
        include_path = Path(include)
        if include_path.is_absolute():
            raise ValueError('include must be a relative filename')
        merged = _load_routes_file(base_dir / include_path, active_paths)
    merged.update(routes)
    return merged
