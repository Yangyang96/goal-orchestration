import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from routebook import load_routes, load_routes_text


PROJECT_DIR = Path(__file__).resolve().parent


class ConfigTestCase(unittest.TestCase):
    def setUp(self):
        folder = tempfile.TemporaryDirectory(dir=PROJECT_DIR)
        self.addCleanup(folder.cleanup)
        self.folder = Path(folder.name)

    def write_config(self, name, data):
        path = self.folder / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(data))
        return path

    def assert_loads(self, path, expected):
        self.assertEqual(load_routes(path), expected)
        self.assertEqual(
            load_routes_text(path.read_text(), base_dir=path.parent), expected
        )


class RouteTests(ConfigTestCase):
    def test_legacy(self):
        path = self.write_config(
            'routes.json', {'routes': {'home': 'https://example.invalid'}}
        )
        self.assertEqual(load_routes(str(path)), {'home': 'https://example.invalid'})
        self.assert_loads(path, {'home': 'https://example.invalid'})

    def test_empty_routes(self):
        path = self.write_config('routes.json', {'routes': {}})
        self.assert_loads(path, {})

    def test_nested_includes_and_local_overrides(self):
        self.write_config('shared/base.json', {'routes': {
            'home': 'base', 'docs': 'base-docs', 'help': 'base-help'
        }})
        self.write_config('nested/middle.json', {
            'include': '../shared/base.json',
            'routes': {'home': 'middle', 'docs': 'middle-docs'},
        })
        path = self.write_config('routes.json', {
            'include': 'nested/middle.json',
            'routes': {'home': 'local', 'new': 'local-new'},
        })
        self.assert_loads(path, {
            'home': 'local', 'docs': 'middle-docs',
            'help': 'base-help', 'new': 'local-new',
        })

    def test_same_basename_is_not_a_cycle(self):
        self.write_config('nested/routes.json', {'routes': {'home': 'base'}})
        path = self.write_config('routes.json', {
            'include': 'nested/routes.json', 'routes': {'docs': 'local'},
        })
        self.assert_loads(path, {'home': 'base', 'docs': 'local'})

    def test_text_accepts_string_base_dir(self):
        self.write_config('base.json', {'routes': {'home': 'base'}})
        self.assertEqual(load_routes_text(
            '{"include": "base.json", "routes": {}}',
            base_dir=str(self.folder),
        ), {'home': 'base'})

    def test_text_requires_keyword_base_dir(self):
        with self.assertRaises(TypeError):
            load_routes_text('{"routes": {}}', self.folder)
        with self.assertRaises(TypeError):
            load_routes_text('{"routes": {}}')

    def test_invalid_structures(self):
        invalid_configs = [
            None, [], 'text', 42, True, {},
            {'include': 'missing.json'},
            {'routes': None}, {'routes': []}, {'routes': 'text'},
            {'routes': 42}, {'routes': True},
            *({'routes': {'home': value}} for value in
              [None, 42, True, [], {}]),
            *({'routes': {}, 'include': value} for value in
              [None, '', 42, True, [], {}]),
            {'routes': {}, 'include': str(self.folder / 'absolute.json')},
        ]
        for data in invalid_configs:
            path = self.write_config('routes.json', data)
            for mode in ('file', 'text'):
                with self.subTest(data=data, mode=mode):
                    with self.assertRaises(ValueError):
                        if mode == 'file':
                            load_routes(path)
                        else:
                            load_routes_text(path.read_text(), base_dir=self.folder)

    def test_invalid_included_structure(self):
        self.write_config('base.json', {'routes': {'home': 42}})
        path = self.write_config('routes.json', {
            'include': 'base.json', 'routes': {'home': 'override'},
        })
        with self.assertRaises(ValueError):
            load_routes(path)
        with self.assertRaises(ValueError):
            load_routes_text(path.read_text(), base_dir=self.folder)

    def test_malformed_json(self):
        path = self.folder / 'routes.json'
        path.write_text('{broken')
        with self.assertRaises(ValueError):
            load_routes(path)
        with self.assertRaises(ValueError):
            load_routes_text(path.read_text(), base_dir=self.folder)

    def test_missing_files(self):
        with self.assertRaises(FileNotFoundError):
            load_routes(self.folder / 'missing.json')
        path = self.write_config('routes.json', {
            'include': 'missing.json', 'routes': {},
        })
        with self.assertRaises(FileNotFoundError):
            load_routes(path)
        with self.assertRaises(FileNotFoundError):
            load_routes_text(path.read_text(), base_dir=self.folder)

    def test_self_include_cycle(self):
        path = self.write_config('routes.json', {
            'include': './routes.json', 'routes': {},
        })
        with self.assertRaisesRegex(ValueError, 'cycle'):
            load_routes(path)
        with self.assertRaisesRegex(ValueError, 'cycle'):
            load_routes_text(path.read_text(), base_dir=self.folder)

    def test_nested_cycle_with_parent_path(self):
        path = self.write_config('routes.json', {
            'include': 'nested/other.json', 'routes': {},
        })
        self.write_config('nested/other.json', {
            'include': '../routes.json', 'routes': {},
        })
        with self.assertRaisesRegex(ValueError, 'cycle'):
            load_routes(path)
        with self.assertRaisesRegex(ValueError, 'cycle'):
            load_routes_text(path.read_text(), base_dir=self.folder)

    def test_cycle_through_symlink(self):
        path = self.write_config('routes.json', {
            'include': 'alias.json', 'routes': {},
        })
        (self.folder / 'alias.json').symlink_to(path)
        with self.assertRaisesRegex(ValueError, 'cycle'):
            load_routes(path)
        with self.assertRaisesRegex(ValueError, 'cycle'):
            load_routes_text(path.read_text(), base_dir=self.folder)

    def test_separate_loads_do_not_share_cycle_state(self):
        path = self.write_config('routes.json', {
            'include': 'base.json', 'routes': {},
        })
        with self.assertRaises(FileNotFoundError):
            load_routes(path)
        self.write_config('base.json', {'routes': {'home': 'base'}})
        self.assert_loads(path, {'home': 'base'})
        self.assert_loads(path, {'home': 'base'})


class CLITests(ConfigTestCase):
    def run_cli(self, *args, stdin=''):
        env = os.environ.copy()
        env['PYTHONPATH'] = str(PROJECT_DIR)
        return subprocess.run(
            [sys.executable, '-m', 'routebook', *args], input=stdin,
            text=True, capture_output=True, cwd=self.folder, env=env,
            timeout=10,
        )

    def test_file_cli_output(self):
        self.write_config('config/routes.json', {
            'routes': {'z': 'last', 'a': 'first'},
        })
        result = self.run_cli('config/routes.json')
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(result.stdout, '{"a": "first", "z": "last"}\n')
        self.assertEqual(result.stderr, '')

    def test_file_cli_resolves_include_from_config_directory(self):
        self.write_config('config/base.json', {'routes': {'home': 'base'}})
        self.write_config('config/routes.json', {
            'include': 'base.json', 'routes': {'docs': 'local'},
        })
        result = self.run_cli('config/routes.json')
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(json.loads(result.stdout), {'home': 'base', 'docs': 'local'})

    def test_stdin_resolves_nested_include_from_cwd(self):
        self.write_config('shared/base.json', {
            'routes': {'home': 'base', 'help': 'inherited'},
        })
        self.write_config('nested/routes.json', {
            'include': '../shared/base.json', 'routes': {'home': 'middle'},
        })
        result = self.run_cli('--stdin', stdin=json.dumps({
            'include': 'nested/routes.json', 'routes': {'home': 'stdin'},
        }))
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(result.stdout, '{"help": "inherited", "home": "stdin"}\n')
        self.assertEqual(result.stderr, '')

    def test_stdin_without_include(self):
        result = self.run_cli('--stdin', stdin='{"routes": {}}')
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(result.stdout, '{}\n')

    def test_argument_combinations_are_usage_errors(self):
        for args in [(), ('--stdin', 'missing.json'), ('missing.json', '--stdin')]:
            with self.subTest(args=args):
                result = self.run_cli(*args, stdin='{broken')
                self.assertEqual(result.returncode, 2, result.stderr)
                self.assertIn('usage:', result.stderr)
                self.assertNotIn('Traceback', result.stderr)
                self.assertEqual(result.stdout, '')


if __name__ == '__main__':
    unittest.main()
