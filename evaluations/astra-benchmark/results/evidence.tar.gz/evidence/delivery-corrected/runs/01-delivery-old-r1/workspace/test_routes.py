import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from routebook import load_routes


PROJECT_DIR = Path(__file__).resolve().parent


class RouteTests(unittest.TestCase):
    def test_legacy(self):
        with tempfile.TemporaryDirectory(dir=PROJECT_DIR) as folder:
            p = Path(folder) / 'routes.json'
            p.write_text(json.dumps({'routes': {'home': 'https://example.invalid'}}))
            self.assertEqual(load_routes(p), {'home': 'https://example.invalid'})


class LoaderExtensionTests(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory(dir=PROJECT_DIR)
        self.addCleanup(self.temp_dir.cleanup)
        self.base_dir = Path(self.temp_dir.name)

    def write_config(self, name, data):
        path = self.base_dir / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(data))
        return path

    def load_text(self, text):
        from routebook import load_routes_text
        return load_routes_text(text, base_dir=self.base_dir)

    def assert_invalid_config(self, data):
        path = self.write_config('invalid.json', data)
        for source in ('file', 'text'):
            with self.subTest(source=source), self.assertRaises(ValueError):
                if source == 'file':
                    load_routes(path)
                else:
                    self.load_text(json.dumps(data))

    def test_public_text_api(self):
        import routebook
        self.assertIn('load_routes_text', routebook.__all__)
        self.assertEqual(
            routebook.load_routes_text(
                '{"routes": {"home": "text"}}', base_dir=str(self.base_dir)
            ),
            {'home': 'text'},
        )
        with self.assertRaises(TypeError):
            routebook.load_routes_text('{"routes": {}}', self.base_dir)

    def test_nested_includes_and_local_overrides(self):
        self.write_config('shared/base.json', {
            'routes': {'home': 'base', 'shared': 'base', 'base_only': 'base'},
        })
        self.write_config('nested/child.json', {
            'include': '../shared/base.json',
            'routes': {'home': 'child', 'shared': 'child'},
        })
        root = self.write_config('root.json', {
            'include': 'nested/child.json',
            'routes': {'home': 'root', 'root_only': 'root'},
        })
        expected = {
            'home': 'root', 'shared': 'child',
            'base_only': 'base', 'root_only': 'root',
        }
        self.assertEqual(load_routes(str(root)), expected)
        self.assertEqual(self.load_text(root.read_text()), expected)

    def test_empty_routes_are_valid(self):
        path = self.write_config('empty.json', {'routes': {}})
        self.assertEqual(load_routes(path), {})
        self.assertEqual(self.load_text(path.read_text()), {})

    def test_same_basename_is_not_a_cycle(self):
        self.write_config('child/routes.json', {'routes': {'child': 'ok'}})
        root = self.write_config('routes.json', {
            'include': 'child/routes.json', 'routes': {'root': 'ok'},
        })
        expected = {'child': 'ok', 'root': 'ok'}
        self.assertEqual(load_routes(root), expected)
        self.assertEqual(self.load_text(root.read_text()), expected)

    def test_resolved_path_cycles(self):
        (self.base_dir / 'nested').mkdir()
        for include in ('routes.json', './routes.json', 'nested/../routes.json'):
            root = self.write_config('routes.json', {
                'include': include, 'routes': {},
            })
            for source in ('file', 'text'):
                with self.subTest(include=include, source=source):
                    with self.assertRaisesRegex(ValueError, 'cycle'):
                        if source == 'file':
                            load_routes(root)
                        else:
                            self.load_text(root.read_text())

    def test_indirect_cycle(self):
        root = self.write_config('a.json', {'include': 'b.json', 'routes': {}})
        self.write_config('b.json', {'include': 'a.json', 'routes': {}})
        with self.assertRaisesRegex(ValueError, 'cycle'):
            load_routes(root)
        with self.assertRaisesRegex(ValueError, 'cycle'):
            self.load_text(root.read_text())

    def test_symlink_cycle(self):
        root = self.write_config('routes.json', {
            'include': 'alias.json', 'routes': {},
        })
        try:
            (self.base_dir / 'alias.json').symlink_to(root)
        except (OSError, NotImplementedError) as exc:
            self.skipTest(f'Symlinks unavailable: {exc}')
        with self.assertRaisesRegex(ValueError, 'cycle'):
            load_routes(root)
        with self.assertRaisesRegex(ValueError, 'cycle'):
            self.load_text(root.read_text())

    def test_repeated_loads_are_independent(self):
        root = self.write_config('routes.json', {
            'include': 'routes.json', 'routes': {},
        })
        with self.assertRaisesRegex(ValueError, 'cycle'):
            load_routes(root)
        self.write_config('routes.json', {'routes': {'home': 'ok'}})
        routes = load_routes(root)
        routes['home'] = 'changed by caller'
        self.assertEqual(load_routes(root), {'home': 'ok'})

    def test_invalid_top_level_structures(self):
        for data in (None, [], 'routes', 1, True):
            with self.subTest(data=data):
                self.assert_invalid_config(data)

    def test_missing_or_invalid_routes(self):
        for data in ({}, {'routes': None}, {'routes': []}, {'routes': 'bad'},
                     {'routes': 1}, {'routes': True}):
            with self.subTest(data=data):
                self.assert_invalid_config(data)

    def test_destinations_must_be_strings(self):
        for destination in (None, 1, True, [], {}):
            with self.subTest(destination=destination):
                self.assert_invalid_config({'routes': {'home': destination}})

    def test_invalid_include_values(self):
        absolute_path = str(self.base_dir / 'base.json')
        for include in ('', None, 1, False, [], {}, absolute_path):
            with self.subTest(include=include):
                self.assert_invalid_config({'include': include, 'routes': {}})

    def test_local_routes_required_even_with_include(self):
        self.write_config('base.json', {'routes': {'home': 'base'}})
        self.assert_invalid_config({'include': 'base.json'})

    def test_included_structures_are_validated_before_override(self):
        root = self.write_config('root.json', {
            'include': 'base.json', 'routes': {'home': 'local'},
        })
        for included in ([], {}, {'routes': {'home': 1}},
                         {'routes': {}, 'include': None}):
            self.write_config('base.json', included)
            for source in ('file', 'text'):
                with self.subTest(included=included, source=source):
                    with self.assertRaises(ValueError):
                        if source == 'file':
                            load_routes(root)
                        else:
                            self.load_text(root.read_text())

    def test_missing_files_propagate(self):
        with self.assertRaises(FileNotFoundError):
            load_routes(self.base_dir / 'missing.json')
        root = self.write_config('root.json', {
            'include': 'missing.json', 'routes': {},
        })
        with self.assertRaises(FileNotFoundError):
            load_routes(root)
        with self.assertRaises(FileNotFoundError):
            self.load_text(root.read_text())

    def test_malformed_json_raises_value_error(self):
        path = self.base_dir / 'bad.json'
        path.write_text('{broken')
        with self.assertRaises(ValueError):
            load_routes(path)
        with self.assertRaises(ValueError):
            self.load_text(path.read_text())
        root = self.write_config('root.json', {
            'include': 'bad.json', 'routes': {},
        })
        with self.assertRaises(ValueError):
            load_routes(root)
        with self.assertRaises(ValueError):
            self.load_text(root.read_text())


class CLITests(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory(dir=PROJECT_DIR)
        self.addCleanup(self.temp_dir.cleanup)
        self.base_dir = Path(self.temp_dir.name)

    def run_cli(self, *args, stdin=''):
        env = os.environ.copy()
        env['PYTHONPATH'] = str(PROJECT_DIR)
        return subprocess.run(
            [sys.executable, '-m', 'routebook', *args],
            input=stdin, text=True, capture_output=True,
            cwd=self.base_dir, env=env, timeout=10,
        )

    def test_legacy_file_output(self):
        (self.base_dir / 'routes.json').write_text(
            '{"routes": {"z": "last", "a": "first"}}'
        )
        result = self.run_cli('routes.json')
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(result.stdout, '{"a": "first", "z": "last"}\n')
        self.assertEqual(result.stderr, '')

    def test_file_includes_use_config_directory(self):
        config_dir = self.base_dir / 'configs'
        config_dir.mkdir()
        (config_dir / 'base.json').write_text('{"routes": {"home": "base"}}')
        (config_dir / 'routes.json').write_text(
            '{"include": "base.json", "routes": {"local": "ok"}}'
        )
        result = self.run_cli('configs/routes.json')
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(json.loads(result.stdout), {'home': 'base', 'local': 'ok'})

    def test_stdin_without_include(self):
        result = self.run_cli('--stdin', stdin='{"routes": {"home": "ok"}}')
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(result.stdout, '{"home": "ok"}\n')
        self.assertEqual(result.stderr, '')

    def test_stdin_includes_use_working_directory(self):
        (self.base_dir / 'shared.json').write_text(
            '{"routes": {"home": "base", "shared": "ok"}}'
        )
        config_dir = self.base_dir / 'configs'
        config_dir.mkdir()
        (config_dir / 'base.json').write_text(
            '{"include": "../shared.json", "routes": {"home": "child"}}'
        )
        result = self.run_cli('--stdin', stdin=json.dumps({
            'include': 'configs/base.json', 'routes': {'home': 'local'},
        }))
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(result.stdout, '{"home": "local", "shared": "ok"}\n')
        self.assertEqual(result.stderr, '')

    def test_invalid_argument_combinations_are_usage_errors(self):
        for args in ((), ('--stdin', 'missing.json'), ('missing.json', '--stdin')):
            with self.subTest(args=args):
                result = self.run_cli(*args, stdin='{invalid JSON')
                self.assertEqual(result.returncode, 2, result.stderr)
                self.assertEqual(result.stdout, '')
                self.assertIn('usage:', result.stderr)
                self.assertNotIn('Traceback', result.stderr)


if __name__ == '__main__':
    unittest.main()
