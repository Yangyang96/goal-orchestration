# Routebook

Load route tables from JSON using only the Python standard library.

## Python API

```python
from routebook import load_routes, load_routes_text

routes = load_routes('config.json')
routes = load_routes_text(
    '{"include": "base.json", "routes": {"home": "https://example.invalid"}}',
    base_dir='configs',
)
```

Both functions return a new dictionary mapping route names to destinations and
share the same validation and include logic. The existing `load_routes(path)` API
continues to accept a filename or `pathlib.Path`. The text API requires the
keyword-only `base_dir` argument, also a string or `pathlib.Path`, which sets the
directory for its first include.

## Configs and includes

Every config must be a JSON object with a `routes` object, even if it only
inherits routes. Route names and destinations must be strings; empty `routes`
objects are valid. An optional `include` must be a nonempty relative JSON
filename; absolute paths are rejected.

For example, with `configs/base.json`:

```json
{"routes": {"home": "https://base.invalid", "help": "https://help.invalid"}}
```

and `configs/local.json`:

```json
{"include": "base.json", "routes": {"home": "https://local.invalid"}}
```

`load_routes('configs/local.json')` returns:

```json
{"home": "https://local.invalid", "help": "https://help.invalid"}
```

Includes load recursively, each relative to its containing file's directory.
Subdirectories and `..` are supported. Local routes override included routes at
each level. Every included config is validated, including routes later overridden.

Cycles are detected using resolved full paths, including symlink aliases, and
raise `ValueError` with `cycle` in the message. Distinct files with the same
basename are allowed. Missing files propagate `FileNotFoundError`; malformed JSON
or invalid config structures raise `ValueError`.

## CLI

```sh
python3 -m routebook configs/local.json
printf '%s\n' '{"include": "configs/base.json", "routes": {}}' | python3 -m routebook --stdin
```

Both modes emit one JSON object with sorted keys and a trailing newline on stdout.
File mode resolves includes relative to each config file. `--stdin` reads JSON
from standard input and resolves its first include from the current working
directory; nested includes still resolve relative to their containing files.

Provide exactly one input mode: a positional config file or `--stdin`. Combining
them, or providing neither, produces an argparse usage error (exit status 2).

## Tests

Run the regression suite with `python3 -m unittest -v`.
