# Routebook

Load route tables from JSON using only the Python standard library.

## Configuration and includes

Every configuration must be a JSON object with a `routes` object. Route names and
destinations must be strings; an empty `routes` object is valid. An optional
`include` must be a nonempty relative JSON filename. Absolute include paths are
rejected; relative paths may use `..`.

For example, `shared/base.json`:

```json
{"routes": {"home": "/default", "docs": "/docs"}}
```

And `app/routes.json`:

```json
{"include": "../shared/base.json", "routes": {"home": "/app"}}
```

Loading `app/routes.json` returns `{"home": "/app", "docs": "/docs"}`.
Includes load recursively, with each filename resolved relative to its containing
file. Local routes override inherited routes with the same name. Each included
configuration must also contain a valid `routes` object.

Cycles are detected using resolved paths, including path aliases and symlinks, and
raise `ValueError` with `cycle` in the message. Distinct files sharing a basename
are allowed. Missing files propagate `FileNotFoundError`; malformed JSON or
configuration structures raise `ValueError`.

## Python API

```python
from routebook import load_routes, load_routes_text

routes = load_routes("app/routes.json")
routes = load_routes_text(
    '{"include": "shared/base.json", "routes": {"home": "/custom"}}',
    base_dir=".",
)
```

`load_routes(path)` retains the file API and shares the loading and validation
logic with `load_routes_text(text, *, base_dir)`. Both return a dictionary of route
names to destinations. File paths and `base_dir` accept strings or `Path` objects.
The text API requires the keyword-only `base_dir`, which resolves the text's
initial include; further includes resolve relative to their containing files.

## CLI

```sh
python3 -m routebook app/routes.json
printf '%s\n' '{"include": "shared/base.json", "routes": {}}' | python3 -m routebook --stdin
```

Both modes emit a JSON object with sorted keys and a trailing newline on stdout.
File mode resolves includes relative to the configuration file. `--stdin` reads
JSON from standard input and resolves its initial include from the current
working directory. Provide exactly one input mode: combining `--stdin` with a
positional config, or providing neither, produces an argparse usage error with
exit status 2.

## Tests

Run the regression suite with `python3 -m unittest -v`. Python cache files are
ignored by Git.
