import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from routebook import load_routes, load_routes_text


PROJECT_ROOT = Path(__file__).resolve().parent


class RouteTests(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory(dir=PROJECT_ROOT)
        self.addCleanup(temporary.cleanup)
        self.folder = Path(temporary.name)

    def write_config(self, name, data):
        path = self.folder / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(data))
        return path

    def assert_loads(self, path, expected):
        self.assertEqual(load_routes(path), expected)
        self.assertEqual(
            load_routes_text(path.read_text(), base_dir=path.parent), expected
        )

    def assert_load_error(self, path, error, message=None):
        loaders = {
            'file': lambda: load_routes(path),
            'text': lambda: load_routes_text(path.read_text(), base_dir=path.parent),
        }
        for name, load in loaders.items():
            with self.subTest(api=name):
                with self.assertRaises(error) as caught:
                    load()
                if message is not None:
                    self.assertIn(message, str(caught.exception))

    def test_legacy(self):
        routes = {'home': 'https://example.invalid'}
        path = self.write_config('routes.json', {'routes': routes})
        self.assert_loads(path, routes)
        self.assertEqual(load_routes(str(path)), routes)

    def test_text_api_accepts_string_base_dir(self):
        self.write_config('base.json', {'routes': {'home': '/home'}})
        self.assertEqual(
            load_routes_text(
                '{"include": "base.json", "routes": {}}',
                base_dir=str(self.folder),
            ),
            {'home': '/home'},
        )

    def test_empty_routes(self):
        path = self.write_config('routes.json', {'routes': {}})
        self.assert_loads(path, {})

    def test_nested_relative_includes_and_local_overrides_with_same_basename(self):
        self.write_config('shared/nested/routes.json', {
            'routes': {'home': '/base', 'docs': '/base-docs', 'keep': '/keep'},
        })
        self.write_config('shared/routes.json', {
            'include': 'nested/routes.json',
            'routes': {'home': '/shared', 'docs': '/shared-docs'},
        })
        path = self.write_config('app/routes.json', {
            'include': '../shared/routes.json',
            'routes': {'home': '/local', 'new': '/new'},
        })
        self.assert_loads(path, {
            'home': '/local', 'docs': '/shared-docs', 'keep': '/keep', 'new': '/new',
        })

    def test_self_include_cycle(self):
        path = self.write_config('routes.json', {
            'include': 'routes.json', 'routes': {},
        })
        self.assert_load_error(path, ValueError, 'cycle')

    def test_nested_cycle_through_resolved_path(self):
        path = self.write_config('routes.json', {
            'include': 'nested/routes.json', 'routes': {},
        })
        self.write_config('nested/routes.json', {
            'include': '../nested/../routes.json', 'routes': {},
        })
        self.assert_load_error(path, ValueError, 'cycle')

    def test_symlink_cycle(self):
        path = self.write_config('routes.json', {
            'include': 'alias.json', 'routes': {},
        })
        try:
            (self.folder / 'alias.json').symlink_to(path)
        except (OSError, NotImplementedError) as error:
            self.skipTest(f'symlinks unavailable: {error}')
        self.assert_load_error(path, ValueError, 'cycle')

    def test_invalid_json(self):
        path = self.folder / 'routes.json'
        for text in ('', '{', '{"routes": {}} trailing'):
            with self.subTest(text=text):
                path.write_text(text)
                self.assert_load_error(path, ValueError)

    def test_invalid_config_and_routes(self):
        invalid = [
            None, [], 'text', 42, True, {},
            {'include': 'missing.json'},
            *({'routes': value} for value in (None, [], 'text', 42, True)),
            *({'routes': {'home': value}} for value in (None, [], {}, 42, True)),
        ]
        for data in invalid:
            with self.subTest(data=data):
                path = self.write_config('routes.json', data)
                self.assert_load_error(path, ValueError)

    def test_invalid_include(self):
        absolute = str(self.write_config('base.json', {'routes': {}}))
        for include in ('', None, [], {}, 42, True, absolute):
            with self.subTest(include=include):
                path = self.write_config('routes.json', {
                    'include': include, 'routes': {},
                })
                self.assert_load_error(path, ValueError)

    def test_included_configs_are_validated_before_overrides(self):
        path = self.write_config('routes.json', {
            'include': 'base.json', 'routes': {'home': '/valid'},
        })
        for data in ([], {}, {'routes': []}, {'routes': {'home': 42}},
                     {'routes': {}, 'include': None}):
            with self.subTest(data=data):
                self.write_config('base.json', data)
                self.assert_load_error(path, ValueError)

    def test_malformed_included_json(self):
        path = self.write_config('routes.json', {
            'include': 'base.json', 'routes': {},
        })
        (self.folder / 'base.json').write_text('{')
        self.assert_load_error(path, ValueError)

    def test_missing_root_file(self):
        with self.assertRaises(FileNotFoundError):
            load_routes(self.folder / 'missing.json')

    def test_missing_include(self):
        path = self.write_config('routes.json', {
            'include': 'missing.json', 'routes': {},
        })
        self.assert_load_error(path, FileNotFoundError)

    def test_missing_nested_include(self):
        path = self.write_config('routes.json', {
            'include': 'nested/base.json', 'routes': {},
        })
        self.write_config('nested/base.json', {
            'include': 'missing.json', 'routes': {},
        })
        self.assert_load_error(path, FileNotFoundError)

    def run_cli(self, *args, text=''):
        return subprocess.run(
            [sys.executable, '-m', 'routebook', *args],
            input=text, text=True, capture_output=True, cwd=self.folder,
            env={**os.environ, 'PYTHONPATH': str(PROJECT_ROOT)}, timeout=10,
        )

    def test_file_cli_keeps_sorted_json_output(self):
        self.write_config('routes.json', {'routes': {'z': '/z', 'a': '/a'}})
        result = self.run_cli('routes.json')
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(result.stdout, '{"a": "/a", "z": "/z"}\n')
        self.assertEqual(result.stderr, '')

    def test_file_cli_resolves_include_beside_config(self):
        self.write_config('app/base.json', {'routes': {'home': '/base', 'z': '/z'}})
        self.write_config('app/routes.json', {
            'include': 'base.json', 'routes': {'home': '/local'},
        })
        result = self.run_cli('app/routes.json')
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(result.stdout, '{"home": "/local", "z": "/z"}\n')

    def test_stdin_cli_without_include(self):
        result = self.run_cli('--stdin', text='{"routes": {"z": "/z", "a": "/a"}}')
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(result.stdout, '{"a": "/a", "z": "/z"}\n')
        self.assertEqual(result.stderr, '')

    def test_stdin_cli_resolves_nested_includes_from_cwd(self):
        self.write_config('nested/base.json', {'routes': {'home': '/base', 'z': '/z'}})
        self.write_config('nested/routes.json', {
            'include': 'base.json', 'routes': {'home': '/nested'},
        })
        result = self.run_cli('--stdin', text=json.dumps({
            'include': 'nested/routes.json', 'routes': {'home': '/stdin'},
        }))
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(result.stdout, '{"home": "/stdin", "z": "/z"}\n')

    def test_cli_requires_exactly_one_input_mode(self):
        for args in ((), ('--stdin', 'missing.json'), ('missing.json', '--stdin')):
            with self.subTest(args=args):
                result = self.run_cli(*args, text='invalid JSON')
                self.assertEqual(result.returncode, 2, result.stderr)
                self.assertEqual(result.stdout, '')
                self.assertIn('usage:', result.stderr)
                self.assertNotIn('Traceback', result.stderr)


if __name__ == '__main__':
    unittest.main()
