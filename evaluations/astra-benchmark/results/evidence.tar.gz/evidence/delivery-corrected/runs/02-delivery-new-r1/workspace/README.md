# Routebook

Load route tables from JSON using only the Python standard library.

## Configuration and includes

Every configuration must be a JSON object with a `routes` object. Route names
and destinations must be strings; an empty `routes` object is valid.
An optional `include` names another JSON file using a nonempty relative path.

For example, `common.json`:

```json
{"routes": {"home": "https://example.invalid", "help": "/help"}}
```

And `config.json` in the same directory:

```json
{"include": "common.json", "routes": {"home": "/local"}}
```

Loading `config.json` returns `{"home": "/local", "help": "/help"}`.
Includes are recursive: each file resolves its include relative to its own
directory, loads the inherited routes, then applies its local overrides.
Paths such as `../common.json` are allowed; absolute include paths are rejected.
Included files must also contain a valid `routes` object, even if empty.

Cycles are detected using resolved paths (including symbolic links) and raise
`ValueError` with `cycle` in the message. Separate files with the same basename
are allowed. Missing files propagate `FileNotFoundError`; invalid JSON or
malformed configuration structures raise `ValueError`.

## Python API

```python
from routebook import load_routes, load_routes_text

routes = load_routes("config.json")
routes = load_routes_text(
    '{"include": "common.json", "routes": {"home": "/local"}}',
    base_dir=".",
)
```

`load_routes(path)` preserves the file API. `load_routes_text(text, *, base_dir)`
accepts JSON text and requires the keyword-only `base_dir` for its first include.
Both use the same loading and validation logic and return a route dictionary.
`path` and `base_dir` accept strings or path-like objects.

## Command line

```sh
python3 -m routebook config.json
printf '%s\n' '{"include": "common.json", "routes": {}}' | python3 -m routebook --stdin
```

Both modes emit a JSON object with sorted keys and a trailing newline on stdout.
`--stdin` reads JSON from standard input and resolves its first include from the
current working directory. File mode resolves includes from the config file's
directory. Combining `--stdin` with a config, or providing neither, is an
argparse usage error (exit status 2).

## Tests

Run the regression suite with `python3 -m unittest -v`.
