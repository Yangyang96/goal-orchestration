"""Load and merge route tables from JSON files or text."""
import json
from pathlib import Path


def load_routes(path):
    """Return a route table, resolving includes relative to each JSON file."""
    return _load_routes_file(Path(path), set())


def load_routes_text(text, *, base_dir):
    """Return a route table from JSON text, resolving includes from base_dir."""
    return _load_routes_text(text, base_dir=Path(base_dir), active_paths=set())


def _load_routes_file(path, active_paths):
    path = path.resolve()
    if path in active_paths:
        raise ValueError(f'include cycle detected: {path}')
    return _load_routes_text(
        path.read_text(),
        base_dir=path.parent,
        active_paths=active_paths | {path},
    )


def _load_routes_text(text, *, base_dir, active_paths):
    data = json.loads(text)
    if not isinstance(data, dict):
        raise ValueError('config must be an object')
    routes = data.get('routes')
    if not isinstance(routes, dict):
        raise ValueError('routes must be an object')
    if any(not isinstance(key, str) or not isinstance(value, str)
           for key, value in routes.items()):
        raise ValueError('route names and destinations must be strings')

    result = {}
    if 'include' in data:
        include = data['include']
        if not isinstance(include, str) or not include:
            raise ValueError('include must be a nonempty relative filename')
        include_path = Path(include)
        if include_path.is_absolute():
            raise ValueError('include must be a relative filename')
        result = _load_routes_file(base_dir / include_path, active_paths)
    result.update(routes)
    return result
