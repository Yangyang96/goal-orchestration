import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

from routebook import load_routes, load_routes_text


PROJECT_ROOT = Path(__file__).resolve().parent


class RouteTests(unittest.TestCase):
    def setUp(self):
        folder = tempfile.TemporaryDirectory(dir=PROJECT_ROOT)
        self.addCleanup(folder.cleanup)
        self.folder = Path(folder.name)

    def write_config(self, filename, data):
        path = self.folder / filename
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(data))
        return path

    def assert_loads(self, path, expected):
        self.assertEqual(load_routes(path), expected)
        self.assertEqual(
            load_routes_text(path.read_text(), base_dir=path.parent), expected
        )

    def assert_invalid(self, data):
        path = self.write_config('invalid.json', data)
        with self.assertRaises(ValueError):
            load_routes(path)
        with self.assertRaises(ValueError):
            load_routes_text(path.read_text(), base_dir=path.parent)

    def test_legacy(self):
        routes = {'home': 'https://example.invalid'}
        path = self.write_config('routes.json', {'routes': routes})
        self.assertEqual(load_routes(str(path)), routes)
        self.assert_loads(path, routes)

    def test_text_without_includes(self):
        self.assertEqual(load_routes_text('{"routes": {}}', base_dir=self.folder), {})
        self.assertEqual(
            load_routes_text('{"routes": {"首页": "/首页", "": ""}}',
                             base_dir=str(self.folder)),
            {'首页': '/首页', '': ''},
        )

    def test_text_requires_keyword_base_dir(self):
        with self.assertRaises(TypeError):
            load_routes_text('{"routes": {}}')
        with self.assertRaises(TypeError):
            load_routes_text('{"routes": {}}', self.folder)

    def test_nested_includes_and_local_overrides(self):
        self.write_config('shared/base.json', {'routes': {
            'base': '/base', 'middle': '/old-middle', 'home': '/old-home',
        }})
        self.write_config('nested/middle.json', {
            'include': '../shared/base.json',
            'routes': {'middle': '/middle', 'home': '/middle-home'},
        })
        root = self.write_config('root.json', {
            'include': 'nested/middle.json', 'routes': {'home': '/local'},
        })
        self.assert_loads(root, {
            'base': '/base', 'middle': '/middle', 'home': '/local',
        })

    def test_text_resolves_include_from_base_dir(self):
        self.write_config('nested/base.json', {'routes': {'home': '/base'}})
        self.assertEqual(load_routes_text(
            '{"include": "base.json", "routes": {}}',
            base_dir=str(self.folder / 'nested'),
        ), {'home': '/base'})

    def test_same_basename_is_not_a_cycle(self):
        self.write_config('nested/routes.json', {'routes': {'home': '/base'}})
        root = self.write_config('routes.json', {
            'include': 'nested/routes.json', 'routes': {},
        })
        self.assert_loads(root, {'home': '/base'})

    def test_self_cycle_through_normalized_path(self):
        (self.folder / 'nested').mkdir()
        root = self.write_config('routes.json', {
            'include': 'nested/../routes.json', 'routes': {},
        })
        with self.assertRaisesRegex(ValueError, 'cycle'):
            load_routes(root)
        with self.assertRaisesRegex(ValueError, 'cycle'):
            load_routes_text(root.read_text(), base_dir=self.folder)

    def test_indirect_cycle_and_recovery(self):
        root = self.write_config('root.json', {'include': 'nested/other.json', 'routes': {}})
        self.write_config('nested/other.json', {'include': '../root.json', 'routes': {}})
        with self.assertRaisesRegex(ValueError, 'cycle'):
            load_routes(root)
        with self.assertRaisesRegex(ValueError, 'cycle'):
            load_routes_text(root.read_text(), base_dir=self.folder)
        self.write_config('nested/other.json', {'routes': {'home': '/fixed'}})
        self.assert_loads(root, {'home': '/fixed'})

    def test_symlink_cycle(self):
        root = self.write_config('routes.json', {'include': 'alias.json', 'routes': {}})
        (self.folder / 'alias.json').symlink_to(root)
        with self.assertRaisesRegex(ValueError, 'cycle'):
            load_routes(root)
        with self.assertRaisesRegex(ValueError, 'cycle'):
            load_routes_text(root.read_text(), base_dir=self.folder)

    def test_missing_files(self):
        with self.assertRaises(FileNotFoundError):
            load_routes(self.folder / 'missing.json')
        root = self.write_config('root.json', {'include': 'middle.json', 'routes': {}})
        self.write_config('middle.json', {'include': 'missing.json', 'routes': {}})
        with self.assertRaises(FileNotFoundError):
            load_routes(root)
        with self.assertRaises(FileNotFoundError):
            load_routes_text(root.read_text(), base_dir=self.folder)

    def test_malformed_json(self):
        for text in ('', '{', '{"routes": {},}'):
            with self.subTest(text=text):
                path = self.folder / 'invalid.json'
                path.write_text(text)
                with self.assertRaises(ValueError):
                    load_routes(path)
                with self.assertRaises(ValueError):
                    load_routes_text(text, base_dir=self.folder)

    def test_invalid_config_structures(self):
        for data in (None, [], 'routes', 1, True, {}, {'include': 'base.json'}):
            with self.subTest(data=data):
                self.assert_invalid(data)

    def test_invalid_routes_structures(self):
        for routes in (None, [], '', 1, True):
            with self.subTest(routes=routes):
                self.assert_invalid({'routes': routes})

    def test_invalid_destinations(self):
        for destination in (None, [], {}, 1, 1.5, True):
            with self.subTest(destination=destination):
                self.assert_invalid({'routes': {'home': destination}})

    def test_invalid_include(self):
        for include in ('', None, [], {}, 1, True, str(self.folder / 'base.json')):
            with self.subTest(include=include):
                self.assert_invalid({'include': include, 'routes': {}})

    def test_included_files_are_validated_before_overrides(self):
        root = self.write_config('root.json', {
            'include': 'base.json', 'routes': {'home': '/local'},
        })
        for data in ([], {}, {'routes': []}, {'routes': {'home': 42}},
                     {'routes': {}, 'include': None}):
            with self.subTest(data=data):
                self.write_config('base.json', data)
                with self.assertRaises(ValueError):
                    load_routes(root)
                with self.assertRaises(ValueError):
                    load_routes_text(root.read_text(), base_dir=self.folder)
        (self.folder / 'base.json').write_text('{')
        with self.assertRaises(ValueError):
            load_routes(root)
        with self.assertRaises(ValueError):
            load_routes_text(root.read_text(), base_dir=self.folder)

    def run_cli(self, *args, stdin=None):
        env = dict(os.environ, PYTHONPATH=str(PROJECT_ROOT))
        return subprocess.run(
            [sys.executable, '-B', '-m', 'routebook', *args],
            cwd=self.folder, env=env, input=stdin, text=True,
            capture_output=True, timeout=10,
        )

    def test_file_cli_output_and_include_directory(self):
        self.write_config('base.json', {'routes': {'home': '/wrong-directory'}})
        self.write_config('nested/base.json', {'routes': {'home': '/base', 'about': '/about'}})
        self.write_config('nested/routes.json', {
            'include': 'base.json', 'routes': {'home': '/local'},
        })
        result = self.run_cli('nested/routes.json')
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(result.stdout, '{"about": "/about", "home": "/local"}\n')
        self.assertEqual(result.stderr, '')

    def test_file_cli_without_include(self):
        self.write_config('routes.json', {'routes': {'z': '/z', 'a': '/a'}})
        result = self.run_cli('routes.json')
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(result.stdout, '{"a": "/a", "z": "/z"}\n')
        self.assertEqual(result.stderr, '')

    def test_stdin_cli_includes_from_cwd(self):
        self.write_config('shared/base.json', {'routes': {'home': '/base', 'about': '/about'}})
        self.write_config('nested/routes.json', {
            'include': '../shared/base.json', 'routes': {'home': '/middle'},
        })
        result = self.run_cli('--stdin', stdin=json.dumps({
            'include': 'nested/routes.json', 'routes': {'home': '/local'},
        }))
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(result.stdout, '{"about": "/about", "home": "/local"}\n')
        self.assertEqual(result.stderr, '')

    def test_stdin_cli_without_include(self):
        result = self.run_cli('--stdin', stdin='{"routes": {"home": "/"}}')
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(result.stdout, '{"home": "/"}\n')
        self.assertEqual(result.stderr, '')

    def test_cli_invalid_argument_combinations(self):
        for args in ((), ('--stdin', 'missing.json'), ('missing.json', '--stdin')):
            with self.subTest(args=args):
                result = self.run_cli(*args, stdin='not JSON')
                self.assertEqual(result.returncode, 2, result.stderr)
                self.assertEqual(result.stdout, '')
                self.assertIn('usage:', result.stderr)
                self.assertNotIn('Traceback', result.stderr)

    def test_stdin_cli_rejects_invalid_input(self):
        for text in ('{', '{"routes": []}'):
            with self.subTest(text=text):
                result = self.run_cli('--stdin', stdin=text)
                self.assertNotEqual(result.returncode, 0)
                self.assertEqual(result.stdout, '')


if __name__ == '__main__':
    unittest.main()
