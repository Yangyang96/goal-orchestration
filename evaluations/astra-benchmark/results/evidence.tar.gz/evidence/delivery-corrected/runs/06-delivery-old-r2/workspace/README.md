# Routebook

Load route tables with Python's standard library only.

## Python API

```python
from routebook import load_routes, load_routes_text

routes = load_routes('config.json')
routes = load_routes_text(
    '{"include": "shared/base.json", "routes": {"home": "/local"}}',
    base_dir='.',
)
```

Both functions return a new dictionary of route names to destinations and share
the same loading and validation logic. The existing `load_routes(path)` API accepts
a string or `pathlib.Path`. `load_routes_text(text, *, base_dir)` reads JSON text;
`base_dir` is a required keyword argument accepting a string or `pathlib.Path`.

## Configuration and includes

Every config must be a JSON object with a `routes` object, including configs that
only include another file (use `"routes": {}`). Route names and destinations must
be strings. An optional `include` must be a nonempty relative filename; absolute
paths are rejected. For example, `shared/base.json`:

```json
{"routes": {"home": "/base", "help": "/help"}}
```

and `config.json`:

```json
{"include": "shared/base.json", "routes": {"home": "/local"}}
```

produce `{"home": "/local", "help": "/help"}`. Includes load recursively, with
each config's local routes overriding the included routes. Each included filename
is relative to the directory of its containing file, using resolved file paths;
`..` is supported. Text input resolves its first include relative to `base_dir`.

Cycles are detected using resolved paths (including symlink aliases), and raise
`ValueError` with `cycle` in the message. Separate files with the same basename
are allowed. Missing files propagate `FileNotFoundError`; invalid JSON or config
structures raise `ValueError`, including errors in included files.

## CLI

```sh
python3 -m routebook config.json
python3 -m routebook --stdin < config.json
```

Both modes emit a JSON object with sorted keys and a trailing newline on stdout.
File mode resolves includes relative to the config file. `--stdin` reads JSON
from standard input and resolves its first include from the current working
directory, even when input is redirected from a file elsewhere. Subsequent
includes resolve relative to their containing files as usual.

Supply exactly one of a positional config file or `--stdin`. Combining them, or
providing neither, is an argparse usage error (exit status 2).

## Tests

Run `python3 -m unittest -v` from the project directory. Tests cover the legacy API
and file CLI, text loading, recursive includes and overrides, path aliases and
cycles, validation failures, missing files, and stdin argument handling.
