import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from routebook import load_routes, load_routes_text


PROJECT_DIR = Path(__file__).resolve().parent


class RouteTests(unittest.TestCase):
    def setUp(self):
        self.folder = tempfile.TemporaryDirectory(dir=PROJECT_DIR)
        self.addCleanup(self.folder.cleanup)
        self.base_dir = Path(self.folder.name)

    def write_config(self, name, data):
        path = self.base_dir / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(data))
        return path

    def load_both(self, data):
        path = self.write_config('config.json', data)
        return (
            lambda: load_routes(path),
            lambda: load_routes_text(json.dumps(data), base_dir=self.base_dir),
        )

    def test_legacy(self):
        p = self.write_config('routes.json', {'routes': {'home': 'https://example.invalid'}})
        self.assertEqual(load_routes(p), {'home': 'https://example.invalid'})
        self.assertEqual(load_routes(str(p)), {'home': 'https://example.invalid'})

    def test_text_and_empty_routes(self):
        for routes in ({}, {'home': '/home', '': ''}):
            with self.subTest(routes=routes):
                self.assertEqual(
                    load_routes_text(json.dumps({'routes': routes}), base_dir=str(self.base_dir)),
                    routes,
                )

    def test_text_requires_keyword_base_dir(self):
        with self.assertRaises(TypeError):
            load_routes_text('{"routes": {}}')
        with self.assertRaises(TypeError):
            load_routes_text('{"routes": {}}', self.base_dir)

    def test_nested_includes_and_local_overrides(self):
        self.write_config('shared/base.json', {'routes': {'shared': '/shared', 'home': '/base'}})
        self.write_config('nested/middle.json', {
            'include': '../shared/base.json',
            'routes': {'home': '/middle', 'middle': '/middle'},
        })
        data = {'include': 'nested/middle.json', 'routes': {'home': '/local', 'local': '/local'}}
        for load in self.load_both(data):
            self.assertEqual(load(), {
                'shared': '/shared', 'home': '/local', 'middle': '/middle', 'local': '/local',
            })

    def test_empty_local_routes_preserve_included_routes(self):
        self.write_config('base.json', {'routes': {'home': '/base'}})
        for load in self.load_both({'include': 'base.json', 'routes': {}}):
            self.assertEqual(load(), {'home': '/base'})

    def test_same_basename_in_separate_directories_is_not_a_cycle(self):
        self.write_config('nested/config.json', {'routes': {'included': '/included'}})
        for load in self.load_both({'include': 'nested/config.json', 'routes': {}}):
            self.assertEqual(load(), {'included': '/included'})

    def test_self_cycle(self):
        for load in self.load_both({'include': './config.json', 'routes': {}}):
            with self.assertRaisesRegex(ValueError, 'cycle'):
                load()

    def test_nested_cycle_with_parent_path(self):
        self.write_config('nested/child.json', {'include': '../config.json', 'routes': {}})
        for load in self.load_both({'include': 'nested/child.json', 'routes': {}}):
            with self.assertRaisesRegex(ValueError, 'cycle'):
                load()

    def test_symlink_cycle(self):
        (self.base_dir / 'alias').symlink_to(self.base_dir, target_is_directory=True)
        for load in self.load_both({'include': 'alias/config.json', 'routes': {}}):
            with self.assertRaisesRegex(ValueError, 'cycle'):
                load()

    def test_cycle_tracking_does_not_leak_between_calls(self):
        for load in self.load_both({'include': 'config.json', 'routes': {}}):
            with self.assertRaisesRegex(ValueError, 'cycle'):
                load()
        path = self.write_config('config.json', {'routes': {'home': '/fixed'}})
        self.assertEqual(load_routes(path), {'home': '/fixed'})
        self.assertEqual(load_routes(path), {'home': '/fixed'})

    def test_invalid_structures(self):
        invalid = [
            None, [], 'config', 7, True, {},
            {'routes': None}, {'routes': []}, {'routes': 'routes'},
            {'routes': {'home': 1}}, {'routes': {'home': False}},
            {'routes': {'home': None}}, {'routes': {'home': []}},
            {'routes': {'home': {}}},
            {'include': 'base.json'},
        ]
        for data in invalid:
            for index, load in enumerate(self.load_both(data)):
                with self.subTest(data=data, entry=index), self.assertRaises(ValueError):
                    load()

    def test_invalid_includes(self):
        for include in ('', None, 1, False, [], {}, str(self.base_dir / 'absolute.json')):
            for index, load in enumerate(self.load_both({'include': include, 'routes': {}})):
                with self.subTest(include=include, entry=index), self.assertRaises(ValueError):
                    load()

    def test_invalid_included_structure(self):
        for data in ([], {}, {'routes': {'home': 1}}, {'routes': {}, 'include': None}):
            self.write_config('base.json', data)
            for load in self.load_both({'include': 'base.json', 'routes': {'home': '/local'}}):
                with self.subTest(data=data), self.assertRaises(ValueError):
                    load()

    def test_malformed_json(self):
        path = self.base_dir / 'broken.json'
        path.write_text('{"routes":')
        with self.assertRaises(ValueError):
            load_routes(path)
        with self.assertRaises(ValueError):
            load_routes_text(path.read_text(), base_dir=self.base_dir)
        for load in self.load_both({'include': 'broken.json', 'routes': {}}):
            with self.assertRaises(ValueError):
                load()

    def test_missing_files_propagate(self):
        with self.assertRaises(FileNotFoundError):
            load_routes(self.base_dir / 'missing.json')
        self.write_config('nested/child.json', {'include': 'missing.json', 'routes': {}})
        for include in ('missing.json', 'nested/child.json'):
            for load in self.load_both({'include': include, 'routes': {}}):
                with self.subTest(include=include), self.assertRaises(FileNotFoundError):
                    load()

    def run_cli(self, *args, input_text=''):
        # Start in a separate directory to exercise stdin's current-directory base.
        return subprocess.run(
            [sys.executable, '-m', 'routebook', *args],
            input=input_text, text=True, capture_output=True, cwd=self.base_dir,
            env=dict(os.environ, PYTHONPATH=str(PROJECT_DIR)),
        )

    def test_file_cli_compatibility(self):
        self.write_config('base.json', {'routes': {'z': '/last'}})
        self.write_config('config.json', {'include': 'base.json', 'routes': {'a': '/first'}})
        result = self.run_cli('config.json')
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(result.stdout, '{"a": "/first", "z": "/last"}\n')
        self.assertEqual(result.stderr, '')

    def test_stdin_cli_uses_current_directory_for_includes(self):
        self.write_config('base.json', {'routes': {'home': '/base', 'shared': '/shared'}})
        self.write_config('nested/child.json', {'include': '../base.json', 'routes': {}})
        result = self.run_cli('--stdin', input_text=json.dumps({
            'include': 'nested/child.json', 'routes': {'home': '/stdin'},
        }))
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(json.loads(result.stdout), {'home': '/stdin', 'shared': '/shared'})
        self.assertEqual(result.stderr, '')

    def test_stdin_cli_without_include(self):
        result = self.run_cli('--stdin', input_text='{"routes": {}}')
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(result.stdout, '{}\n')

    def test_cli_argument_errors(self):
        for args in ((), ('--stdin', 'missing.json'), ('missing.json', '--stdin')):
            with self.subTest(args=args):
                result = self.run_cli(*args, input_text='invalid JSON')
                self.assertEqual(result.returncode, 2, result.stderr)
                self.assertIn('usage:', result.stderr)
                self.assertNotIn('Traceback', result.stderr)
                self.assertEqual(result.stdout, '')


if __name__ == '__main__':
    unittest.main()
