"""Load route tables from JSON files or text, including inherited routes."""
import json
from pathlib import Path


def load_routes(path):
    """Return routes from a JSON file, resolving includes beside each file."""
    return _load_file(path, frozenset())


def load_routes_text(text, *, base_dir):
    """Return routes from JSON text, resolving its include relative to base_dir."""
    return _load_text(text, Path(base_dir), frozenset())


def _load_file(path, active_paths):
    path = Path(path).resolve()
    if path in active_paths:
        raise ValueError(f'include cycle: {path}')
    return _load_text(path.read_text(), path.parent, active_paths | {path})


def _load_text(text, base_dir, active_paths):
    data = json.loads(text)
    if not isinstance(data, dict):
        raise ValueError('config must be an object')
    routes = data.get('routes')
    if not isinstance(routes, dict):
        raise ValueError('routes must be an object')
    if any(not isinstance(key, str) or not isinstance(value, str)
           for key, value in routes.items()):
        raise ValueError('route keys and destinations must be strings')

    merged = {}
    if 'include' in data:
        include = data['include']
        if not isinstance(include, str) or not include:
            raise ValueError('include must be a nonempty string')
        include_path = Path(include)
        if include_path.is_absolute():
            raise ValueError('include must be a relative path')
        merged = _load_file(base_dir / include_path, active_paths)
    merged.update(routes)
    return merged
