# Routebook

Load route tables with the Python standard library only.

## Python API

```python
from routebook import load_routes, load_routes_text

routes = load_routes('config.json')
routes = load_routes_text(
    '{"include": "defaults.json", "routes": {"home": "/home"}}',
    base_dir='.',
)
```

Both functions return a new dictionary of route names to destinations and share
the same validation and include loader. The existing `load_routes(path)` API
accepts a string or path-like filename. `load_routes_text(text, *, base_dir)`
accepts JSON text and requires the keyword-only `base_dir` argument, which may
be a string or path-like directory. Files are read as UTF-8.

## Configs and includes

Each config must be a JSON object containing a `routes` object, including configs
that only include another file (use `"routes": {}`). Route names and destinations
must be strings. An optional `include` must be a nonempty relative filename;
absolute paths are rejected.

For example, `defaults.json`:

```json
{"routes": {"home": "/default", "help": "/help"}}
```

And `config.json` in the same directory:

```json
{"include": "defaults.json", "routes": {"home": "/home"}}
```

Loading `config.json` returns `{"home": "/home", "help": "/help"}`. Includes are
loaded recursively before the local routes, so local destinations always win.
For files, each include is relative to the containing file's resolved directory.
For text, the first include is relative to `base_dir`; nested includes are then
relative to their own files. Parent paths such as `../defaults.json` are allowed.

Cycles are detected using resolved full paths, including symlink aliases, and
raise `ValueError` with `cycle` in the message. Separate files with the same
basename are allowed. Missing files propagate `FileNotFoundError`; malformed
JSON or config structures raise `ValueError`. Every included config is validated,
even when its routes would be overridden locally.

## CLI

```sh
python3 -m routebook config.json
python3 -m routebook --stdin < config.json
```

Both modes emit a JSON object with sorted keys and a trailing newline on stdout.
File mode resolves includes from the config file's directory. `--stdin` reads
JSON from standard input and resolves its first include from the current working
directory, regardless of where redirected input came from.

Exactly one input mode is required: combining `--stdin` with a positional config,
or providing neither, produces an argparse usage error (exit status 2).

## Tests

Run the regression suite with `python3 -m unittest -v`. Python cache files are
ignored by Git. Keep personal planning changes in `NOTES.md` uncommitted.
