import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from routebook import load_routes, load_routes_text


PROJECT_ROOT = Path(__file__).resolve().parent


class RouteTests(unittest.TestCase):
    def setUp(self):
        folder = tempfile.TemporaryDirectory(dir=PROJECT_ROOT)
        self.addCleanup(folder.cleanup)
        self.base_dir = Path(folder.name)

    def write_config(self, filename, data):
        path = self.base_dir / filename
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(data), encoding='utf-8')
        return path

    def run_cli(self, *args, input_text=None):
        env = os.environ.copy()
        env['PYTHONPATH'] = str(PROJECT_ROOT)
        return subprocess.run(
            [sys.executable, '-m', 'routebook', *args],
            input=input_text, text=True, capture_output=True,
            cwd=self.base_dir, env=env,
        )

    def test_legacy(self):
        p = self.write_config('routes.json', {
            'routes': {'home': 'https://example.invalid'},
        })
        for path in (p, str(p)):
            with self.subTest(path=path):
                self.assertEqual(load_routes(path), {
                    'home': 'https://example.invalid',
                })

    def test_text_api(self):
        for routes in ({}, {'home': '/首页', '': ''}):
            for base_dir in (self.base_dir, str(self.base_dir)):
                with self.subTest(routes=routes, base_dir=base_dir):
                    self.assertEqual(load_routes_text(
                        json.dumps({'routes': routes}, ensure_ascii=False),
                        base_dir=base_dir,
                    ), routes)

    def test_text_base_dir_is_required_and_keyword_only(self):
        with self.assertRaises(TypeError):
            load_routes_text('{"routes": {}}')
        with self.assertRaises(TypeError):
            load_routes_text('{"routes": {}}', self.base_dir)

    def test_nested_includes_and_local_overrides(self):
        self.write_config('shared/defaults.json', {'routes': {
            'shared': '/shared', 'home': '/default', 'middle': '/default',
        }})
        self.write_config('nested/routes.json', {
            'include': '../shared/defaults.json',
            'routes': {'home': '/nested', 'middle': '/nested'},
        })
        data = {
            'include': 'nested/routes.json',
            'routes': {'home': '/local', 'local': '/local'},
        }
        path = self.write_config('routes.json', data)
        expected = {
            'shared': '/shared', 'home': '/local',
            'middle': '/nested', 'local': '/local',
        }
        self.assertEqual(load_routes(path), expected)
        self.assertEqual(load_routes_text(
            json.dumps(data), base_dir=self.base_dir,
        ), expected)
        # Loading an included file again must not retain overrides or cycle state.
        self.assertEqual(load_routes(self.base_dir / 'nested/routes.json'), {
            'shared': '/shared', 'home': '/nested', 'middle': '/nested',
        })

    def test_same_basename_is_not_a_cycle(self):
        self.write_config('nested/routes.json', {'routes': {'nested': '/nested'}})
        path = self.write_config('routes.json', {
            'include': 'nested/routes.json', 'routes': {},
        })
        self.assertEqual(load_routes(path), {'nested': '/nested'})

    def test_cycles(self):
        for includes in (
            {'a.json': './a.json'},
            {'a.json': 'nested/../a.json'},
            {'a.json': 'b.json', 'b.json': 'a.json'},
        ):
            with self.subTest(includes=includes):
                (self.base_dir / 'nested').mkdir(exist_ok=True)
                for filename, include in includes.items():
                    self.write_config(filename, {'include': include, 'routes': {}})
                with self.assertRaisesRegex(ValueError, 'cycle'):
                    load_routes(self.base_dir / 'a.json')
                with self.assertRaisesRegex(ValueError, 'cycle'):
                    load_routes_text(
                        '{"include": "a.json", "routes": {}}',
                        base_dir=self.base_dir,
                    )

    def test_cycle_through_symlink(self):
        path = self.write_config('routes.json', {
            'include': 'alias.json', 'routes': {},
        })
        alias = self.base_dir / 'alias.json'
        try:
            alias.symlink_to(path)
        except (OSError, NotImplementedError) as error:
            self.skipTest(f'symlinks unavailable: {error}')
        with self.assertRaisesRegex(ValueError, 'cycle'):
            load_routes(path)

    def test_invalid_structures(self):
        invalid_data = [
            None, [], 'config', 1, True, {}, {'include': 'missing.json'},
            *({'routes': routes} for routes in (None, [], '', 1, True)),
            *({'routes': {'home': destination}} for destination in (
                None, [], {}, 1, True,
            )),
            *({'routes': {}, 'include': include} for include in (
                None, '', [], {}, 1, True, str(self.base_dir / 'absolute.json'),
            )),
        ]
        for data in invalid_data:
            with self.subTest(data=data):
                path = self.write_config('invalid.json', data)
                with self.assertRaises(ValueError):
                    load_routes(path)
                with self.assertRaises(ValueError):
                    load_routes_text(json.dumps(data), base_dir=self.base_dir)
                parent = self.write_config('parent.json', {
                    'include': 'invalid.json', 'routes': {},
                })
                with self.assertRaises(ValueError):
                    load_routes(parent)

    def test_malformed_json(self):
        path = self.base_dir / 'invalid.json'
        path.write_text('{', encoding='utf-8')
        with self.assertRaises(ValueError):
            load_routes(path)
        with self.assertRaises(ValueError):
            load_routes_text('{', base_dir=self.base_dir)
        with self.assertRaises(ValueError):
            load_routes_text(
                '{"include": "invalid.json", "routes": {}}',
                base_dir=self.base_dir,
            )

    def test_missing_files(self):
        with self.assertRaises(FileNotFoundError):
            load_routes(self.base_dir / 'missing.json')
        data = {'include': 'missing.json', 'routes': {}}
        path = self.write_config('routes.json', data)
        with self.assertRaises(FileNotFoundError):
            load_routes(path)
        with self.assertRaises(FileNotFoundError):
            load_routes_text(json.dumps(data), base_dir=self.base_dir)

    def test_file_cli(self):
        self.write_config('defaults.json', {'routes': {'z': '/default'}})
        self.write_config('routes.json', {
            'include': 'defaults.json', 'routes': {'a': '/local'},
        })
        result = self.run_cli('routes.json')
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(result.stdout, '{"a": "/local", "z": "/default"}\n')
        self.assertEqual(result.stderr, '')

    def test_stdin_cli_resolves_includes_from_cwd(self):
        self.write_config('nested/routes.json', {
            'include': '../defaults.json', 'routes': {'home': '/nested'},
        })
        self.write_config('defaults.json', {
            'routes': {'shared': '/shared', 'home': '/default'},
        })
        result = self.run_cli('--stdin', input_text=json.dumps({
            'include': 'nested/routes.json', 'routes': {'home': '/stdin'},
        }))
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(result.stdout, '{"home": "/stdin", "shared": "/shared"}\n')
        self.assertEqual(result.stderr, '')

    def test_cli_requires_exactly_one_input_mode(self):
        for args in ((), ('--stdin', 'missing.json'), ('missing.json', '--stdin')):
            with self.subTest(args=args):
                result = self.run_cli(*args, input_text='invalid JSON')
                self.assertEqual(result.returncode, 2, result.stderr)
                self.assertIn('usage:', result.stderr)
                self.assertNotIn('Traceback', result.stderr)
                self.assertEqual(result.stdout, '')

    def test_stdin_cli_without_includes(self):
        result = self.run_cli('--stdin', input_text='{"routes": {}}')
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(result.stdout, '{}\n')


if __name__ == '__main__':
    unittest.main()
