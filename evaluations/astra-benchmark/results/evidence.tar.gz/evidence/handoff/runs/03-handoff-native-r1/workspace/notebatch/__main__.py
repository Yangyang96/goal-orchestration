"""Command-line export of a note batch."""
import argparse
import json
from pathlib import Path
import sys
from . import read_entries, render_json


def main():
    parser = argparse.ArgumentParser(description='Export a note batch')
    parser.add_argument('input', help='JSON file containing an array of notes, or - for stdin')
    parser.add_argument('--format', choices=('json', 'jsonl'), default='json',
                        help='output format (default: json)')
    parser.add_argument('--unique', action='store_true',
                        help='keep the first note for each casefolded title')
    args = parser.parse_args()

    try:
        text = (sys.stdin.read() if args.input == '-'
                else Path(args.input).read_text(encoding='utf-8'))
        entries = read_entries(text)
    except (OSError, ValueError) as error:
        print(f'input error: {error}', file=sys.stderr)
        return 2

    # Validate the whole batch before discarding duplicates or writing output.
    if args.unique:
        seen = set()
        unique_entries = []
        for entry in entries:
            key = entry['title'].casefold()
            if key not in seen:
                seen.add(key)
                unique_entries.append(entry)
        entries = unique_entries

    if args.format == 'jsonl':
        output = ''.join(
            json.dumps(entry, ensure_ascii=False, separators=(',', ':')) + '\n'
            for entry in entries
        )
    else:
        output = render_json(entries)
    sys.stdout.write(output)
    return 0


if __name__ == '__main__':
    sys.exit(main())
