import copy
from itertools import product
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from notebatch import normalize_entries, read_entries, render_json


class NoteBatchTests(unittest.TestCase):
    def test_existing_normalized_entry(self):
        value = [{'title': 'Inbox', 'tags': ['home']}]
        self.assertEqual(normalize_entries(value), value)

    def test_normalizes_titles_tags_and_ignores_unknown_fields(self):
        value = [
            {
                'title': ' \t中文 Inbox\n',
                'tags': [' work ', '', 'home', 'work', '\t', 'Home', '中文'],
                'extra': {'keep': True},
            },
            {'title': ' Second '},
            {'title': '中文 Inbox', 'tags': []},
        ]
        self.assertEqual(normalize_entries(value), [
            {'title': '中文 Inbox', 'tags': ['Home', 'home', 'work', '中文']},
            {'title': 'Second', 'tags': []},
            {'title': '中文 Inbox', 'tags': []},
        ])

    def test_does_not_mutate_or_share_mutable_output_with_input(self):
        value = [
            {'title': ' Inbox ', 'tags': [' home ', 'home'], 'extra': [1]},
            {'title': 'Ready', 'tags': ['work']},
        ]
        original = copy.deepcopy(value)
        result = normalize_entries(value)
        self.assertEqual(value, original)
        result[0]['title'] = 'Changed'
        result[0]['tags'].append('new')
        result[1]['tags'].clear()
        result.append({'title': 'Added', 'tags': []})
        self.assertEqual(value, original)

    def test_default_tags_are_independent(self):
        result = normalize_entries([{'title': 'First'}, {'title': 'Second'}])
        result[0]['tags'].append('new')
        self.assertEqual(result[1]['tags'], [])

    def test_rejects_non_list_collections(self):
        for value in (None, {}, '[]', (), set(), 1, True, iter([])):
            with self.subTest(value=value):
                with self.assertRaises(ValueError):
                    normalize_entries(value)

    def test_rejects_non_object_entries(self):
        for value in (None, 'title', [], (), 1, True):
            with self.subTest(value=value):
                with self.assertRaises(ValueError):
                    normalize_entries([value])

    def test_rejects_missing_or_invalid_titles(self):
        entries = [{}] + [
            {'title': value}
            for value in (None, '', ' \t\n\u3000', 1, True, [], {})
        ]
        for entry in entries:
            with self.subTest(entry=entry):
                with self.assertRaises(ValueError):
                    normalize_entries([entry])

    def test_rejects_non_list_tags(self):
        for tags in (None, 'home', ('home',), {'home'}, {}, 1, True):
            with self.subTest(tags=tags):
                with self.assertRaises(ValueError):
                    normalize_entries([{'title': 'Inbox', 'tags': tags}])

    def test_rejects_non_string_tags(self):
        for tag in (None, 1, True, [], {}):
            with self.subTest(tag=tag):
                with self.assertRaises(ValueError):
                    normalize_entries([{'title': 'Inbox', 'tags': ['valid', tag]}])

    def test_late_invalid_entry_does_not_mutate_input(self):
        value = [
            {'title': ' Inbox ', 'tags': [' work ', 'work']},
            {'title': 'Invalid', 'tags': ['ok', None]},
        ]
        original = copy.deepcopy(value)
        with self.assertRaises(ValueError):
            normalize_entries(value)
        self.assertEqual(value, original)

    def test_read_entries_applies_normalization(self):
        self.assertEqual(
            read_entries('[{"title": " Inbox ", "tags": [" b ", "a", "b"], "id": 1}]'),
            [{'title': 'Inbox', 'tags': ['a', 'b']}],
        )

    def test_read_entries_rejects_invalid_json_or_data(self):
        for text in ('', '[', '[{"title": "Inbox",}]', 'null', '{}', '"text"',
                     '1', 'true', '[null]', '[{}]', '[{"title": " "}]',
                     '[{"title": "Inbox", "tags": null}]',
                     '[{"title": "Inbox", "tags": [1]}]',
                     '[{"title": "Valid"}, {"title": ""}]'):
            with self.subTest(text=text):
                with self.assertRaises(ValueError):
                    read_entries(text)

    def test_empty_batch(self):
        self.assertEqual(read_entries('[]'), [])

    def test_json_output(self):
        value = [{'title': '中文', 'tags': []}]
        rendered = render_json(value)
        self.assertEqual(json.loads(rendered), value)
        self.assertTrue(rendered.endswith('\n'))
        self.assertIn('中文', rendered)

    def test_file_cli_emits_normalized_json_array(self):
        root = Path(__file__).resolve().parent
        with tempfile.TemporaryDirectory(dir=root) as directory:
            source = Path(directory) / 'notes.json'
            source.write_text(
                '[{"title": " 中文 ", "tags": ["b", " a ", "b"]}, '
                '{"title": " 中文 "}]', encoding='utf-8',
            )
            result = subprocess.run(
                [sys.executable, '-m', 'notebatch', str(source)],
                cwd=root, capture_output=True, text=True, encoding='utf-8',
            )
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(result.stderr, '')
        expected = [
            {'title': '中文', 'tags': ['a', 'b']},
            {'title': '中文', 'tags': []},
        ]
        self.assertEqual(json.loads(result.stdout), expected)
        self.assertEqual(
            result.stdout, json.dumps(expected, ensure_ascii=False, indent=2) + '\n',
        )


class NoteBatchCLITests(unittest.TestCase):
    def setUp(self):
        self.root = Path(__file__).resolve().parent
        directory = tempfile.TemporaryDirectory(dir=self.root)
        self.addCleanup(directory.cleanup)
        self.directory = Path(directory.name)

    def run_cli(self, *args, input_text=''):
        return subprocess.run(
            [sys.executable, '-m', 'notebatch', *args],
            input=input_text.encode('utf-8'), cwd=self.root,
            capture_output=True, timeout=10,
        )

    def run_batch(self, text, source, output_format, unique):
        if source == 'stdin':
            args = ['-']
        else:
            path = self.directory / 'notes.json'
            path.write_text(text, encoding='utf-8')
            args = [str(path)]
        if output_format is not None:
            args.extend(['--format', output_format])
        if unique:
            args.append('--unique')
        return self.run_cli(*args, input_text=text if source == 'stdin' else '')

    def assert_input_error(self, result, reason):
        self.assertEqual(result.returncode, 2, result.stderr)
        self.assertEqual(result.stdout, b'')
        self.assertTrue(result.stderr.startswith(b'input error:'), result.stderr)
        self.assertIn(reason, result.stderr)
        self.assertNotIn(b'Traceback', result.stderr)

    def test_sources_formats_and_unique_preserve_first_entries(self):
        text = json.dumps([
            {'title': ' Straße ', 'tags': [' work ', 'home', 'work', '', '家']},
            {'title': ' 中文 ', 'tags': [' b ', 'a', 'b'], 'extra': True},
            {'title': 'STRASSE', 'tags': ['discard']},
            {'title': ' Inbox '},
            {'title': 'inBOX', 'tags': ['late']},
            {'title': '中文', 'tags': ['later']},
        ], ensure_ascii=False)
        expected = [
            {'title': 'Straße', 'tags': ['home', 'work', '家']},
            {'title': '中文', 'tags': ['a', 'b']},
            {'title': 'STRASSE', 'tags': ['discard']},
            {'title': 'Inbox', 'tags': []},
            {'title': 'inBOX', 'tags': ['late']},
            {'title': '中文', 'tags': ['later']},
        ]
        jsonl_lines = [
            '{"title":"Straße","tags":["home","work","家"]}\n',
            '{"title":"中文","tags":["a","b"]}\n',
            '{"title":"STRASSE","tags":["discard"]}\n',
            '{"title":"Inbox","tags":[]}\n',
            '{"title":"inBOX","tags":["late"]}\n',
            '{"title":"中文","tags":["later"]}\n',
        ]
        for source, output_format, unique in product(
                ('file', 'stdin'), (None, 'json', 'jsonl'), (False, True)):
            with self.subTest(source=source, format=output_format, unique=unique):
                result = self.run_batch(text, source, output_format, unique)
                indices = [0, 1, 3] if unique else list(range(len(expected)))
                if output_format == 'jsonl':
                    output = ''.join(jsonl_lines[index] for index in indices)
                else:
                    output = json.dumps(
                        [expected[index] for index in indices],
                        ensure_ascii=False, indent=2,
                    ) + '\n'
                self.assertEqual(result.returncode, 0, result.stderr)
                self.assertEqual(result.stderr, b'')
                self.assertEqual(result.stdout, output.encode('utf-8'))

    def test_empty_batches_have_exact_output(self):
        for source, output_format, unique in product(
                ('file', 'stdin'), (None, 'json', 'jsonl'), (False, True)):
            with self.subTest(source=source, format=output_format, unique=unique):
                result = self.run_batch('[]', source, output_format, unique)
                self.assertEqual(result.returncode, 0, result.stderr)
                self.assertEqual(result.stderr, b'')
                self.assertEqual(
                    result.stdout, b'' if output_format == 'jsonl' else b'[]\n',
                )

    def test_invalid_batches_never_produce_partial_output(self):
        cases = [
            ('', b'Expecting value'),
            ('[{"title":"Good"},', b'Expecting value'),
            ('{}', b'entries must be a list'),
            ('null', b'entries must be a list'),
            ('[{"title":"Good"},null]', b'entry 1 must be an object'),
            ('[{"title":"Good"},{"title":" "}]', b'entry 1 title'),
            ('[{"title":"Good"},{"title":"Bad","tags":null}]', b'entry 1 tags'),
            ('[{"title":"Good"},{"title":"Bad","tags":[null]}]', b'entry 1 tag 0'),
            ('[{"title":" Straße "},{"title":"STRASSE","tags":[null]}]',
             b'entry 1 tag 0'),
            ('{"title":"First"}\n{"title":"Second"}\n', b'Extra data'),
        ]
        for (text, reason), source, output_format, unique in product(
                cases, ('file', 'stdin'), (None, 'json', 'jsonl'), (False, True)):
            with self.subTest(text=text, source=source, format=output_format,
                              unique=unique):
                result = self.run_batch(text, source, output_format, unique)
                self.assert_input_error(result, reason)

    def test_unopenable_files_have_input_errors(self):
        paths = [self.directory / 'missing.json', self.directory]
        for path, output_format, unique in product(
                paths, (None, 'json', 'jsonl'), (False, True)):
            with self.subTest(path=path, format=output_format, unique=unique):
                args = [str(path)]
                if output_format is not None:
                    args.extend(['--format', output_format])
                if unique:
                    args.append('--unique')
                result = self.run_cli(*args)
                self.assert_input_error(result, str(path).encode('utf-8'))
                self.assertIn(b'[Errno ', result.stderr)

    def test_argument_errors_keep_argparse_behavior(self):
        cases = [
            ([], b'input'),
            (['-', '--format', 'yaml'], b'invalid choice'),
            (['-', '--unknown'], b'unrecognized arguments'),
        ]
        for args, reason in cases:
            with self.subTest(args=args):
                result = self.run_cli(*args)
                self.assertEqual(result.returncode, 2, result.stderr)
                self.assertEqual(result.stdout, b'')
                self.assertTrue(result.stderr.startswith(b'usage:'), result.stderr)
                self.assertIn(reason, result.stderr)
                self.assertNotIn(b'input error:', result.stderr)
                self.assertNotIn(b'Traceback', result.stderr)


if __name__ == '__main__':
    unittest.main()
