"""Utilities for preparing a batch of notes for export."""
import json


def normalize_entries(entries):
    """Return fresh normalized entries, raising ValueError for invalid data."""
    if not isinstance(entries, list):
        raise ValueError('entries must be a list of objects')

    normalized = []
    for index, entry in enumerate(entries):
        if not isinstance(entry, dict):
            raise ValueError(f'entry {index} must be an object')

        title = entry.get('title')
        if not isinstance(title, str) or not title.strip():
            raise ValueError(f'entry {index} title must be a nonempty string')

        tags = entry.get('tags', [])
        if not isinstance(tags, list):
            raise ValueError(f'entry {index} tags must be a list of strings')
        cleaned_tags = set()
        for tag_index, tag in enumerate(tags):
            if not isinstance(tag, str):
                raise ValueError(f'entry {index} tag {tag_index} must be a string')
            cleaned_tag = tag.strip()
            if cleaned_tag:
                cleaned_tags.add(cleaned_tag)

        normalized.append({'title': title.strip(), 'tags': sorted(cleaned_tags)})
    return normalized


def read_entries(text):
    """Parse a JSON batch and normalize it; invalid JSON or data raises ValueError."""
    return normalize_entries(json.loads(text))


def render_json(entries):
    """Legacy output is a JSON array with one final newline."""
    return json.dumps(entries, ensure_ascii=False, indent=2) + '\n'
