# NoteBatch
A small local note-export utility using Python's standard library.

Run `python3 -m unittest -v` to test the package.
Public functions: `normalize_entries(entries)`, `read_entries(text)`,
`render_json(entries)`.

## CLI usage

```sh
python3 -m notebatch notes.json
python3 -m notebatch notes.json --format json
python3 -m notebatch notes.json --format jsonl --unique
python3 -m notebatch - < notes.json
python3 -m notebatch - --format jsonl --unique < notes.json
```

The required positional argument `input` accepts a file path or a single `-` to
read stdin. Files are read as UTF-8. Both sources must contain a JSON array and
use the same normalization rules below. JSONL is an output format only; JSONL
input is not accepted.

`--format json|jsonl` defaults to `json`:

- `json` emits the normalized array with two-space indentation, Unicode
  characters preserved, and one final newline. An empty batch emits `[]\n`.
- `jsonl` emits one compact JSON object per line, with no spaces after commas or
  colons and Unicode characters preserved. Every object, including the last,
  ends with a newline. An empty batch emits zero bytes, with no blank line.

For example, JSONL output can be:

```jsonl
{"title":"中文","tags":["home","work"]}
{"title":"Straße","tags":[]}
```

Duplicates are preserved by default. With `--unique`, entries are compared by
their stripped title's `casefold()` value, so ` Straße ` and `STRASSE` match.
Keep the first complete normalized object and its title casing, tags and order;
later duplicates do not contribute tags. This option works with both output
formats. Every entry is validated before deduplication, including duplicates.

Invalid JSON, normalization failures, or files that cannot be opened cause exit
code `2`, empty stdout, and a message on stderr starting with `input error:` and
explaining the cause, without a traceback. The whole batch is validated before
any output, so a late invalid entry cannot leave partial results. Argument
usage errors, such as missing `input` or an unsupported `--format`, retain
argparse's usual usage/error messages and exit code `2`.

## Input normalization
Input is a list of objects. Each object has a nonempty string title after
stripping whitespace. Tags are an optional list of strings, defaulting to [].
Strip each tag, discard empty tags, deduplicate exactly and sort by Python string
order. Tag matching is case-sensitive. Output contains only title and tags;
unknown fields are ignored. Preserve entry order and duplicates, and never
mutate input data. Return fresh lists and objects, including separate tag lists.
Invalid entry collections, titles, or tags raise `ValueError`, with zero-based
entry indices where applicable. `read_entries` parses JSON and applies
normalization. `render_json` continues to emit an indented JSON array with a
final newline.

## Development handoff
Stages 1 and 2 are complete. The agreed CLI contract and verification status
are recorded in [HANDOFF.md](HANDOFF.md).
