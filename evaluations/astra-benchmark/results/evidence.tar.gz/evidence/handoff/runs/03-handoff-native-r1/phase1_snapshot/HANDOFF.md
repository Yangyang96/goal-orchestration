# NoteBatch 阶段 2 交接

## 工作范围与状态

用户将任务分为两天：阶段 1 已完成，下一次任务直接完成下面的阶段 2，
补充测试和使用文档并运行相关检查，不需要再次确认方案。两个阶段都不要
Git commit；阶段 1 的成果保留在同一工作树的未提交改动中，请保护这些改动。

只在当前工作目录内工作，其他目录有独立工作，不能修改；不要读取工作目录
之外的项目、测试判卷器、其他候选结果或全局 Skill。仅允许当前提供的 Skill
（如有），不要委派子 Agent，也不要调用外部应用。可用本地 shell、文件工具和
Git，遵守现有权限限制。默认使用简体中文沟通。

## 阶段 1 已完成

- `notebatch/__init__.py`：`normalize_entries(entries)` 要求输入为 list，
  每项为 dict；title 必须是去除首尾空白后非空的字符串。
  tags 缺省为独立的空列表，显式提供时必须是字符串列表。标签去除首尾空白、
  丢弃空字符串、按大小写敏感的精确匹配去重，再按 Python 字符串顺序排序。
  输出只保留 title 和 tags，忽略未知字段，保持条目顺序及所有重复条目。
  返回新列表、对象和标签列表，不修改输入；非法集合、条目、标题或标签抛出
  `ValueError`，校验消息带有从 0 开始的条目索引（适用时）。
- `read_entries(text)` 仍通过 `json.loads` 解析后调用上述归一化。
  非法 JSON 的 `JSONDecodeError` 本身是 `ValueError` 子类。
- 保留公开 API：`normalize_entries(entries)`、`read_entries(text)`、
  `render_json(entries)`。`render_json` 仍为 `ensure_ascii=False`、`indent=2`，
  输出 JSON 数组并附一个结尾换行。
- `notebatch/__main__.py` 未修改：目前仅接受文件路径，并输出归一化 JSON 数组。
  stdin、格式选项、去重选项和统一 CLI 错误处理均尚未实现，属于阶段 2。
- `test_notebatch.py` 覆盖归一化、非法输入、输入不变性、输出可变对象独立性、
  `read_entries` 校验以及真实文件 CLI 的旧格式回归。
- 已运行 `python3 -m unittest -v`，15 项测试全部通过。

## 阶段 2 固定接口（已与消费端约定，不可改名或替换）

1. 位置参数仍叫 `input`，除文件路径外接受单独的 `-`，表示读取 stdin。
   文件和 stdin 的输入都是同一种 JSON 数组，都调用阶段 1 归一化。
   `jsonl` 仅是输出格式，不改变输入格式。
2. 增加 `--format json|jsonl`，默认 `json`，保持现有 JSON 数组输出。
   `jsonl` 每个归一化对象一行紧凑 JSON，逗号、冒号后不加空格，
   保留 Unicode 原字符。非空批次最后一行也必须有换行；
   空批次必须输出零字节，不能输出 `[]` 或空行。
3. 增加 `--unique`，默认不开启，默认保留所有条目。
   开启后按清洗后的 `title.casefold()` 判断重复，保留第一次出现的完整
   归一化对象和原始顺序；不合并后续重复对象的 tags，不改变保留标题的大小写。
   对 `json` 和 `jsonl` 两种输出格式均生效。
4. 非法 JSON、归一化失败或输入文件打不开：CLI 退出码为 `2`，stdout 必须为空，
   stderr 以 `input error:` 开头并说明原因，不输出 traceback。
   即使错误条目靠后，也不能输出前面的部分结果。
   参数使用错误保持 argparse 常规行为（例如非法 `--format` 值、缺少 input）。

实现时保留现有公开 API 和默认行为，复用标准库和现有结构。可先读取并归一化
完整批次，再按需去重和渲染，最后一次写 stdout，以保证输入错误无部分输出。
不能因后面的条目标题重复而跳过其归一化校验。

## 阶段 2 验收与收尾

- 补充真实 CLI 子进程测试，检查 stdout、stderr、退出码；覆盖文件/stdin、
  默认/显式 json/jsonl、默认保留重复/开启 `--unique` 的组合。
- JSONL 按精确输出验证紧凑格式、Unicode、末行换行和空批次零字节。
- 去重用带首尾空白、不同大小写、不同 tags 的重复标题验证保留首个完整对象
  和顺序；增加 `Straße`/`STRASSE` 一类案例区分 `casefold()` 与 `lower()`。
- 覆盖非法 JSON、非法顶层集合、后置非法条目、打不开的文件，确认输入错误
  的状态码、前缀、原因、stdout 为空且无 traceback；两种来源和格式均应满足。
  覆盖后置重复标题但 tags 非法的条目，确保不能绕过校验。
- 保留 argparse 参数错误行为测试和已有阶段 1 回归测试。
- 更新 README，记录新参数、文件/stdin 用法、JSONL 格式及空批次、去重规则、
  输入错误约定；完成后同步本交接文件的状态，避免继续显示待实现。
- 在当前目录运行 `python3 -m unittest -v` 和 `git diff --check`，检查
  `git diff` / `git status --short`，交付结果；不要 Git commit。
