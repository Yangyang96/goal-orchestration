# Goal

NoteBatch 分两阶段接入导出消费端。本文件用于同一工作树中新任务恢复，明天的任务无法读取今天的聊天。

- 今天只完成阶段 1：按 README 修复 `normalize_entries` / `read_entries`，补充测试并运行。保留公共 API 和文件输入 CLI 的 JSON 数组输出；今天不实现阶段 2。
- 明天完成阶段 2：实现下述全部 CLI 契约，补充测试和使用文档，运行相关检查后直接交付，不需要再次询问确认。
- 两个阶段都不要 Git commit，也不要 push 或创建 PR。只修改当前工作目录，保护其他改动；不委派子 Agent、不调用外部应用、不读取工作目录之外的项目或全局 Skill。

阶段 1 契约（README）：输入为对象列表；title 必须是去除首尾空白后非空的字符串。tags 可省略，默认为 []，必须是字符串列表；逐项 strip，丢弃空字符串，精确去重后按 Python 字符串顺序排序，区分大小写。输出仅含 title、tags，忽略未知字段，保留条目顺序，绝不修改输入。非法集合、条目、title 或 tags 抛出 ValueError；`read_entries` 解析 JSON 后归一化。

阶段 2 已与消费端确定的接口，不能改名或替换：

1. 位置参数 `input` 接受文件路径或单独的 `-`（读取 stdin）。两种来源都是 JSON 数组，统一经过阶段 1 归一化。
2. `--format json|jsonl`，默认 json，保持现有 JSON 数组输出。jsonl 每个归一化对象一行紧凑 JSON，逗号、冒号后没有空格，保留 Unicode 原字符。非空批次最后一行也必须有换行；空批次输出零字节，不能输出 [] 或空行。
3. `--unique`，默认关闭。按清洗后的 `title.casefold()` 判重，保留第一次出现的完整对象和原始顺序，不合并后续对象的 tags，不改变保留标题的大小写。对 json 和 jsonl 都生效；未开启时仍保留所有条目。
4. 非法 JSON、归一化失败、输入文件打不开：退出码 2，stdout 必须为空，stderr 以 `input error:` 开头并说明原因，不输出 traceback。即使错误条目靠后也不能输出前面部分结果。参数使用错误保持 argparse 常规行为。
5. 补充阶段 2 测试和 README 使用文档，运行相关检查，直接完成，不提交。

# Plan

- 阶段 1 已由主 Agent 顺序完成实现、测试与验收；当前暂停，等待明天的新任务开始阶段 2。
- 阶段 1 修改范围：`notebatch/__init__.py`、`test_notebatch.py`、交接入口和本文件；保留 `notebatch/__main__.py` 的现有 CLI。
- 下一里程碑：阶段 2。基于现有 `read_entries` 在 `notebatch/__main__.py` 接入输入来源、参数、去重和输出格式，先完整读取并归一化后再写 stdout，统一处理输入错误。保留 `normalize_entries`、`read_entries`、`render_json` API。扩展 `test_notebatch.py` 与 `README.md`。
- 阶段 2 的关键测试：文件/stdin 均归一化；默认 json 兼容；jsonl 紧凑字节格式、Unicode、末尾换行、空批次零字节；两种格式的默认不去重与 `--unique`（含 `Straße` / `STRASSE` 的 casefold 重复、保留第一条标题/tags/顺序）；非法 JSON、靠后非法条目和打不开文件均无 stdout、退出码 2、指定 stderr 前缀且无 traceback；错误参数维持 argparse 行为。

# Status

- 阶段 1 已验收，阶段 2 尚未实现。初始工作树干净；当前未提交的任务文件为 `notebatch/__init__.py`、`test_notebatch.py`、`README.md`、本文件。新任务应保留这些已完成改动，不要还原它们。
- `normalize_entries` 已实现全部阶段 1 清洗和 ValueError 校验，重新构造结果列表、对象与 tags。`read_entries` 保持原有 JSON 解析再归一化的结构；JSONDecodeError 本身是 ValueError 的子类，无须另行包装。`render_json` 和 `notebatch/__main__.py` 未修改。
- 验收证据（2026-09-07）：`python3 -m unittest -v` 退出 0，9 项测试全部通过，覆盖归一化顺序/大小写/Unicode/未知字段、缺省 tags、成功及失败时输入不变性、输出独立性、非法集合/条目/title/tags、非法 JSON、文件 CLI 数组输出与重复项保留。新增测试在实现前已暴露旧代码缺陷；实现后一次通过。`git diff --check` 通过，主线程已检查改动。
- 修复轮次：0（无实现后失败修复）；阻塞：无。没有 Git commit，跳过原因是用户明确禁止两个阶段提交。
- 明天准确的下一步：先读本文件、`git status --short --untracked-files=all` 和上述任务文件的 scoped diff，再读 `notebatch/__main__.py`、`notebatch/__init__.py`、`test_notebatch.py`、`README.md`；按 Goal 的固定契约补充阶段 2 CLI 测试并实现。无需重复运行未变的阶段 1 基线；修改后运行 `python3 -m unittest -v` 和 `git diff --check`，检查 CLI 可观察输出，更新 README 用法及本文件状态，直接交付，不提交。
