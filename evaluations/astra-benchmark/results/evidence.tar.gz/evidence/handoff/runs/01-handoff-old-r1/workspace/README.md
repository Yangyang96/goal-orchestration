# NoteBatch
A small local note-export utility using Python's standard library.

Run `python3 -m notebatch notes.json` to emit a JSON array.
Run `python3 -m unittest -v` to test the package.
Public functions: `normalize_entries(entries)`, `read_entries(text)`,
`render_json(entries)`.

## Input normalization
Input is a list of objects. Each object has a nonempty string title after
stripping whitespace. Tags are an optional list of strings, defaulting to [].
Strip each tag, discard empty tags, deduplicate exactly and sort by Python string
order. Tag matching is case-sensitive. Output contains only title and tags;
unknown fields are ignored. Preserve entry order, and never mutate input data.
Invalid entry collections, titles, or tags raise ValueError. read_entries parses
JSON and applies normalization.

## CLI usage

Both file input and stdin contain a JSON array and use the same normalization:

```sh
python3 -m notebatch notes.json
python3 -m notebatch - < notes.json
python3 -m notebatch notes.json --format jsonl
python3 -m notebatch - --format jsonl --unique < notes.json
```

The positional `input` is a UTF-8 file path or a standalone `-` to read stdin.
`--format json|jsonl` defaults to `json`, preserving the existing indented JSON
array output and final newline. `jsonl` emits one compact normalized object per
line, with no spaces after separator commas or colons, retaining Unicode
characters. Every object has a trailing newline, including the last; an empty
batch emits zero bytes in `jsonl` and `[]` followed by a newline in `json`.

Duplicates are kept by default. With `--unique`, titles are compared after
normalization using `title.casefold()`. The first object's cleaned title and tags
are kept, in input order, without merging tags or changing title casing. This
applies to both output formats. For example, ` Straße ` followed by `STRASSE`
retains only `Straße` and its own normalized tags when `--unique` is enabled.

Malformed JSON, invalid entries and files that cannot be opened produce exit
code 2, empty stdout and a reason on stderr beginning with `input error:`, without
a traceback. The complete batch is validated before anything is written to
stdout, even if a later invalid entry would be a duplicate. Argument usage
errors retain the normal argparse usage and error messages.

## Development handoff
See [.agent/STATE.md](.agent/STATE.md) for the two-stage scope, validation status,
and agreed CLI contract. Both stages are complete; neither stage creates a Git
commit.
