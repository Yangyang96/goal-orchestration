# Goal

NoteBatch 分两阶段接入导出消费端。本文件用于同一工作树中新任务恢复，明天的任务无法读取今天的聊天。

- 今天只完成阶段 1：按 README 修复 `normalize_entries` / `read_entries`，补充测试并运行。保留公共 API 和文件输入 CLI 的 JSON 数组输出；今天不实现阶段 2。
- 明天完成阶段 2：实现下述全部 CLI 契约，补充测试和使用文档，运行相关检查后直接交付，不需要再次询问确认。
- 两个阶段都不要 Git commit，也不要 push 或创建 PR。只修改当前工作目录，保护其他改动；不委派子 Agent、不调用外部应用、不读取工作目录之外的项目或全局 Skill。

阶段 1 契约（README）：输入为对象列表；title 必须是去除首尾空白后非空的字符串。tags 可省略，默认为 []，必须是字符串列表；逐项 strip，丢弃空字符串，精确去重后按 Python 字符串顺序排序，区分大小写。输出仅含 title、tags，忽略未知字段，保留条目顺序，绝不修改输入。非法集合、条目、title 或 tags 抛出 ValueError；`read_entries` 解析 JSON 后归一化。

阶段 2 已与消费端确定的接口，不能改名或替换：

1. 位置参数 `input` 接受文件路径或单独的 `-`（读取 stdin）。两种来源都是 JSON 数组，统一经过阶段 1 归一化。
2. `--format json|jsonl`，默认 json，保持现有 JSON 数组输出。jsonl 每个归一化对象一行紧凑 JSON，逗号、冒号后没有空格，保留 Unicode 原字符。非空批次最后一行也必须有换行；空批次输出零字节，不能输出 [] 或空行。
3. `--unique`，默认关闭。按清洗后的 `title.casefold()` 判重，保留第一次出现的完整对象和原始顺序，不合并后续对象的 tags，不改变保留标题的大小写。对 json 和 jsonl 都生效；未开启时仍保留所有条目。
4. 非法 JSON、归一化失败、输入文件打不开：退出码 2，stdout 必须为空，stderr 以 `input error:` 开头并说明原因，不输出 traceback。即使错误条目靠后也不能输出前面部分结果。参数使用错误保持 argparse 常规行为。
5. 补充阶段 2 测试和 README 使用文档，运行相关检查，直接完成，不提交。

# Plan

- 两个阶段均已由主 Agent 顺序完成实现、测试与验收，无剩余里程碑。
- 阶段 1 修改范围：`notebatch/__init__.py`、`test_notebatch.py`、README 交接入口和本文件；已完成的代码与测试全部保留。
- 阶段 2 修改范围：`notebatch/__main__.py`、`test_notebatch.py`、`README.md`、本文件。CLI 复用 `read_entries`，完整读取并归一化后去重、生成输出，统一处理输入错误。`normalize_entries`、`read_entries`、`render_json` API 保持不变。
- 阶段 2 的 CLI 契约测试与使用文档均已补齐；无委派、外部应用、目录外项目读取或修改，无提交、push 或 PR。

# Status

- 阶段 1 与阶段 2 均已验收。恢复时已有未提交的 `notebatch/__init__.py`、`test_notebatch.py`、`README.md` 和本文件；本次保留这些改动并完成阶段 2，另修改 `notebatch/__main__.py`。全部任务改动仍未提交，不要还原。
- 阶段 1 历史证据（2026-09-07）：9 项测试及 `git diff --check` 通过；归一化清洗、ValueError 校验、输入不变性与公共 API 已验收。恢复后未重复运行未变的阶段 1 基线。
- 阶段 2 已实现文件/stdin 输入、默认 json 数组兼容、紧凑 Unicode jsonl（最后换行、空批次零字节）、按清洗标题 casefold 保留首次对象与顺序。输入读取或校验失败返回 2，stdout 为空，stderr 以 `input error:` 开头并说明原因，无 traceback。参数错误保留 argparse 行为。
- 当前验收证据（2026-09-07）：`python3 -m unittest -v` 退出 0，全部 16 项测试通过（原有 9 项与新增 7 项）。子进程检查覆盖两种来源及格式、默认重复保留、Unicode casefold 去重不合并 tags、字节输出与转义、空批次、非法 JSON/集合/靠后条目/重复条目的非法 tags、缺失文件/目录输入、参数错误。`git diff --check` 通过，主线程已审阅 scoped diff。
- 修复轮次：阶段 1 为 0，阶段 2 为 1（Python 3.14 的尾逗号报错措辞变化，已将测试改为检查错误位置，保留退出码/stdout/stderr 契约断言）；阻塞：无。没有 Git commit，跳过原因是用户明确禁止两个阶段提交。
- 准确的下一步：直接交付本次完成结果；无剩余实现或检查，不提交。
