import copy
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from notebatch import normalize_entries, read_entries, render_json


class NoteBatchTests(unittest.TestCase):
    def test_existing_normalized_entry(self):
        value = [{'title': 'Inbox', 'tags': ['home']}]
        self.assertEqual(normalize_entries(value), value)

    def test_empty_batch(self):
        self.assertEqual(read_entries('[]'), [])

    def test_normalization_preserves_order_and_cleans_fields(self):
        value = [
            {'title': ' \t中文\n',
             'tags': [' z ', '', 'A', 'a', 'z', ' \n', ' A ', '中文'],
             'unknown': {'nested': True}},
            {'title': '\u2003Inbox\u2003'},
            {'title': '中文', 'tags': []},
        ]
        expected = [
            {'title': '中文', 'tags': ['A', 'a', 'z', '中文']},
            {'title': 'Inbox', 'tags': []},
            {'title': '中文', 'tags': []},
        ]
        self.assertEqual(normalize_entries(value), expected)
        self.assertEqual(read_entries(json.dumps(value)), expected)

    def test_input_is_unchanged_and_output_is_independent(self):
        value = [{'title': ' Inbox ', 'tags': [' z ', 'a', 'a'],
                  'unknown': {'nested': [1]}}]
        original = copy.deepcopy(value)
        normalized = normalize_entries(value)
        self.assertEqual(value, original)
        normalized[0]['title'] = 'Changed'
        normalized[0]['tags'].append('new')
        normalized.append({'title': 'Extra', 'tags': []})
        self.assertEqual(value, original)

    def test_invalid_collections_raise_value_error(self):
        for value in (None, {}, 'notes', 42, False, (), iter([])):
            with self.subTest(value=value):
                with self.assertRaises(ValueError):
                    normalize_entries(value)

    def test_invalid_entries_raise_value_error(self):
        invalid_entries = [
            None, 'note', 42, [],
            {}, {'title': None}, {'title': 42}, {'title': False},
            {'title': []}, {'title': ''}, {'title': ' \t\n\u2003'},
            {'title': 'ok', 'tags': None},
            {'title': 'ok', 'tags': 'tag'},
            {'title': 'ok', 'tags': {}},
            {'title': 'ok', 'tags': 42},
            {'title': 'ok', 'tags': ['valid', None]},
            {'title': 'ok', 'tags': [42]},
            {'title': 'ok', 'tags': [False]},
            {'title': 'ok', 'tags': [[]]},
            {'title': 'ok', 'tags': [{}]},
        ]
        for entry in invalid_entries:
            with self.subTest(entry=entry):
                value = [{'title': ' First ', 'tags': [' z ', 'a']}, entry]
                original = copy.deepcopy(value)
                with self.assertRaises(ValueError):
                    normalize_entries(value)
                self.assertEqual(value, original)
                with self.assertRaises(ValueError):
                    read_entries(json.dumps(value))
        with self.assertRaises(ValueError):
            normalize_entries([{'title': 'ok', 'tags': ('tag',)}])

    def test_read_entries_rejects_invalid_json_and_collections(self):
        for text in ('', '[', '[{"title": "ok"},]',
                     'null', '{}', '"notes"', '42', 'false'):
            with self.subTest(text=text):
                with self.assertRaises(ValueError):
                    read_entries(text)

    def test_file_cli_keeps_json_array_output(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).resolve().parent) as directory:
            input_path = Path(directory) / 'notes.json'
            input_path.write_text(json.dumps([
                {'title': ' 中文 ', 'tags': [' z ', 'a', 'a'], 'extra': 1},
                {'title': '中文'},
            ], ensure_ascii=False), encoding='utf-8')
            result = subprocess.run(
                [sys.executable, '-m', 'notebatch', str(input_path)],
                cwd=Path(__file__).resolve().parent,
                capture_output=True, text=True, encoding='utf-8',
            )
        expected = [
            {'title': '中文', 'tags': ['a', 'z']},
            {'title': '中文', 'tags': []},
        ]
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(result.stderr, '')
        self.assertEqual(result.stdout, render_json(expected))
        self.assertEqual(json.loads(result.stdout), expected)

    def test_json_output(self):
        value = [{'title': '中文', 'tags': []}]
        rendered = render_json(value)
        self.assertEqual(json.loads(rendered), value)
        self.assertTrue(rendered.endswith('\n'))
        self.assertIn('中文', rendered)


class NoteBatchCliTests(unittest.TestCase):
    def run_cli(self, *args, input_bytes=None):
        return subprocess.run(
            [sys.executable, '-m', 'notebatch', *args],
            cwd=Path(__file__).resolve().parent,
            input=input_bytes, capture_output=True,
        )

    def run_input(self, text, source, *args):
        data = text.encode('utf-8')
        if source == 'stdin':
            return self.run_cli('-', *args, input_bytes=data)
        with tempfile.TemporaryDirectory(dir=Path(__file__).resolve().parent) as directory:
            input_path = Path(directory) / 'notes.json'
            input_path.write_bytes(data)
            return self.run_cli(str(input_path), *args)

    def assert_success(self, result, expected):
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(result.stderr, b'')
        self.assertEqual(result.stdout, expected.encode('utf-8'))

    def assert_input_error(self, result, reason):
        self.assertEqual(result.returncode, 2, result.stderr)
        self.assertEqual(result.stdout, b'')
        self.assertTrue(result.stderr.startswith(b'input error:'), result.stderr)
        self.assertIn(reason.encode('utf-8'), result.stderr)
        self.assertNotIn(b'Traceback', result.stderr)

    def test_sources_and_formats_normalize_and_keep_duplicates(self):
        text = json.dumps([
            {'title': ' 中文 ', 'tags': [' z ', 'a', 'a', ' '], 'extra': 1},
            {'title': '中文'},
        ], ensure_ascii=False)
        expected = [
            {'title': '中文', 'tags': ['a', 'z']},
            {'title': '中文', 'tags': []},
        ]
        jsonl = '{"title":"中文","tags":["a","z"]}\n{"title":"中文","tags":[]}\n'
        for source in ('file', 'stdin'):
            for format_args, output in (
                ((), render_json(expected)),
                (('--format', 'json'), render_json(expected)),
                (('--format', 'jsonl'), jsonl),
            ):
                with self.subTest(source=source, format_args=format_args):
                    self.assert_success(self.run_input(text, source, *format_args), output)

    def test_unique_uses_casefold_and_preserves_first_object_and_order(self):
        text = json.dumps([
            {'title': ' Straße ', 'tags': [' 中文 ', 'a', 'a']},
            {'title': ' Other ', 'tags': ['first']},
            {'title': 'STRASSE', 'tags': ['later']},
            {'title': 'OTHER', 'tags': ['merge forbidden']},
            {'title': '中文'},
        ], ensure_ascii=False)
        all_entries = [
            {'title': 'Straße', 'tags': ['a', '中文']},
            {'title': 'Other', 'tags': ['first']},
            {'title': 'STRASSE', 'tags': ['later']},
            {'title': 'OTHER', 'tags': ['merge forbidden']},
            {'title': '中文', 'tags': []},
        ]
        for source in ('file', 'stdin'):
            for output_format in ('json', 'jsonl'):
                for unique in (False, True):
                    with self.subTest(source=source, format=output_format, unique=unique):
                        args = ['--format', output_format]
                        if unique:
                            args.append('--unique')
                        result = self.run_input(text, source, *args)
                        self.assertEqual(result.returncode, 0, result.stderr)
                        self.assertEqual(result.stderr, b'')
                        if output_format == 'json':
                            actual = json.loads(result.stdout)
                        else:
                            actual = [json.loads(line) for line in result.stdout.splitlines()]
                        expected = ([all_entries[0], all_entries[1], all_entries[4]]
                                    if unique else all_entries)
                        self.assertEqual(actual, expected)

    def test_empty_batches_have_exact_output(self):
        for source in ('file', 'stdin'):
            for output_format, expected in (('json', '[]\n'), ('jsonl', '')):
                for unique_args in ((), ('--unique',)):
                    with self.subTest(source=source, format=output_format, unique=unique_args):
                        self.assert_success(self.run_input(
                            '[]', source, '--format', output_format, *unique_args,
                        ), expected)

    def test_jsonl_escapes_embedded_newlines_and_quotes(self):
        text = json.dumps([{'title': ' A\n"B" ', 'tags': [' x\ny ', ' \\ ']}])
        expected = '{"title":"A\\n\\"B\\"","tags":["\\\\","x\\ny"]}\n'
        self.assert_success(self.run_input(text, 'stdin', '--format', 'jsonl'), expected)

    def test_input_errors_never_emit_partial_output(self):
        cases = (
            ('[{"title":"ok"},]', 'line 1 column'),
            ('{}', 'entries must be a list'),
            ('[{"title":"ok"},null]', 'entry 1 must be an object'),
            ('[{"title":"ok"},{"title":" "}]', 'entry 1 title'),
            ('[{"title":"ok"},{"title":"OK","tags":[1]}]', 'entry 1 tags'),
        )
        for source in ('file', 'stdin'):
            for output_format in ('json', 'jsonl'):
                for text, reason in cases:
                    with self.subTest(source=source, format=output_format, text=text):
                        result = self.run_input(text, source, '--format', output_format, '--unique')
                        self.assert_input_error(result, reason)

    def test_unreadable_files_report_input_errors(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).resolve().parent) as directory:
            for input_path in (Path(directory) / 'missing.json', Path(directory)):
                for output_format in ('json', 'jsonl'):
                    with self.subTest(path=input_path, format=output_format):
                        result = self.run_cli(str(input_path), '--format', output_format)
                        self.assert_input_error(result, str(input_path))

    def test_argument_errors_keep_argparse_behavior(self):
        for args in ((), ('-', '--format', 'xml'), ('-', '--format'),
                     ('-', '--unknown'), ('-', 'extra.json')):
            with self.subTest(args=args):
                result = self.run_cli(*args, input_bytes=b'[]')
                self.assertEqual(result.returncode, 2, result.stderr)
                self.assertEqual(result.stdout, b'')
                self.assertTrue(result.stderr.startswith(b'usage:'), result.stderr)
                self.assertIn(b'error:', result.stderr)
                self.assertNotIn(b'input error:', result.stderr)
                self.assertNotIn(b'Traceback', result.stderr)


if __name__ == '__main__':
    unittest.main()
