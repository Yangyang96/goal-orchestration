import copy
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from notebatch import normalize_entries, read_entries, render_json


class NoteBatchTests(unittest.TestCase):
    def test_existing_normalized_entry(self):
        value = [{'title': 'Inbox', 'tags': ['home']}]
        self.assertEqual(normalize_entries(value), value)

    def test_empty_batch(self):
        self.assertEqual(read_entries('[]'), [])

    def test_normalization_preserves_order_and_cleans_fields(self):
        value = [
            {'title': ' \t中文\n',
             'tags': [' z ', '', 'A', 'a', 'z', ' \n', ' A ', '中文'],
             'unknown': {'nested': True}},
            {'title': '\u2003Inbox\u2003'},
            {'title': '中文', 'tags': []},
        ]
        expected = [
            {'title': '中文', 'tags': ['A', 'a', 'z', '中文']},
            {'title': 'Inbox', 'tags': []},
            {'title': '中文', 'tags': []},
        ]
        self.assertEqual(normalize_entries(value), expected)
        self.assertEqual(read_entries(json.dumps(value)), expected)

    def test_input_is_unchanged_and_output_is_independent(self):
        value = [{'title': ' Inbox ', 'tags': [' z ', 'a', 'a'],
                  'unknown': {'nested': [1]}}]
        original = copy.deepcopy(value)
        normalized = normalize_entries(value)
        self.assertEqual(value, original)
        normalized[0]['title'] = 'Changed'
        normalized[0]['tags'].append('new')
        normalized.append({'title': 'Extra', 'tags': []})
        self.assertEqual(value, original)

    def test_invalid_collections_raise_value_error(self):
        for value in (None, {}, 'notes', 42, False, (), iter([])):
            with self.subTest(value=value):
                with self.assertRaises(ValueError):
                    normalize_entries(value)

    def test_invalid_entries_raise_value_error(self):
        invalid_entries = [
            None, 'note', 42, [],
            {}, {'title': None}, {'title': 42}, {'title': False},
            {'title': []}, {'title': ''}, {'title': ' \t\n\u2003'},
            {'title': 'ok', 'tags': None},
            {'title': 'ok', 'tags': 'tag'},
            {'title': 'ok', 'tags': {}},
            {'title': 'ok', 'tags': 42},
            {'title': 'ok', 'tags': ['valid', None]},
            {'title': 'ok', 'tags': [42]},
            {'title': 'ok', 'tags': [False]},
            {'title': 'ok', 'tags': [[]]},
            {'title': 'ok', 'tags': [{}]},
        ]
        for entry in invalid_entries:
            with self.subTest(entry=entry):
                value = [{'title': ' First ', 'tags': [' z ', 'a']}, entry]
                original = copy.deepcopy(value)
                with self.assertRaises(ValueError):
                    normalize_entries(value)
                self.assertEqual(value, original)
                with self.assertRaises(ValueError):
                    read_entries(json.dumps(value))
        with self.assertRaises(ValueError):
            normalize_entries([{'title': 'ok', 'tags': ('tag',)}])

    def test_read_entries_rejects_invalid_json_and_collections(self):
        for text in ('', '[', '[{"title": "ok"},]',
                     'null', '{}', '"notes"', '42', 'false'):
            with self.subTest(text=text):
                with self.assertRaises(ValueError):
                    read_entries(text)

    def test_file_cli_keeps_json_array_output(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).resolve().parent) as directory:
            input_path = Path(directory) / 'notes.json'
            input_path.write_text(json.dumps([
                {'title': ' 中文 ', 'tags': [' z ', 'a', 'a'], 'extra': 1},
                {'title': '中文'},
            ], ensure_ascii=False), encoding='utf-8')
            result = subprocess.run(
                [sys.executable, '-m', 'notebatch', str(input_path)],
                cwd=Path(__file__).resolve().parent,
                capture_output=True, text=True, encoding='utf-8',
            )
        expected = [
            {'title': '中文', 'tags': ['a', 'z']},
            {'title': '中文', 'tags': []},
        ]
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(result.stderr, '')
        self.assertEqual(result.stdout, render_json(expected))
        self.assertEqual(json.loads(result.stdout), expected)

    def test_json_output(self):
        value = [{'title': '中文', 'tags': []}]
        rendered = render_json(value)
        self.assertEqual(json.loads(rendered), value)
        self.assertTrue(rendered.endswith('\n'))
        self.assertIn('中文', rendered)


if __name__ == '__main__':
    unittest.main()
