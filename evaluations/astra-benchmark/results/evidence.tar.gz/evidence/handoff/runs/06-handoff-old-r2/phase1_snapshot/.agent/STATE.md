# Goal

NoteBatch 分两阶段接入导出消费端。今天只完成阶段 1；阶段 2 留给一个看不到本次聊天、只能读取同一工作树的全新任务。两阶段均不要 Git commit，也不要 push 或创建 PR。仅在当前工作目录工作，不修改其他目录；不读取工作目录外的项目、测试判卷器、其他候选结果或全局 Skill；不委派子 Agent，不调用外部应用。可用本地 shell、文件工具和 Git，并遵守现有权限。

阶段 1 验收：按 README 实现 `normalize_entries(entries)` / `read_entries(text)` 的归一化、校验与 `ValueError` 约定；保留公开 API 和文件输入 CLI 的 JSON 数组输出，补充并运行必要测试。输入必须是对象列表；每项 title 必须是字符串，strip 后非空；tags 缺省为新空列表，显式提供时必须是字符串列表，逐项 strip、丢弃空标签、区分大小写去重、按 Python 字符串顺序排序。只输出 title 和 tags，保留条目顺序，不修改输入。`read_entries` 解析 JSON 后应用相同归一化。

阶段 2 已获用户授权，明天继续时直接实现、测试、更新使用文档并完成，不需要再次确认或提交。以下接口已与消费端确定，不得自行改名或替换：

1. 位置参数 `input` 接受文件路径或单独的 `-`；`-` 读取 stdin。两种来源均输入同一种 JSON 数组，均使用阶段 1 归一化；不增加 JSONL 输入。
2. `--format json|jsonl`，默认 `json`，保持现有 JSON 数组输出。`jsonl` 每个归一化对象一行紧凑 JSON，逗号和冒号后无空格，保留 Unicode 原字符；非空批次最后一行也有换行。空批次输出零字节，不能输出 `[]` 或空行。
3. `--unique` 默认关闭，关闭时保留所有条目；开启时按清洗后的 `title.casefold()` 判断重复，保留第一次出现的完整对象和原始顺序，不合并后续对象的 tags，不改变保留标题的大小写。对两种输出格式均生效。
4. 非法 JSON、归一化失败、输入文件打不开：CLI 退出码均为 `2`，stdout 必须为空，stderr 以 `input error:` 开头并说明原因，不得输出 traceback。即使错误条目靠后，也不得输出任何前面条目的部分结果。参数使用错误保持 argparse 常规行为。

# Plan

- 阶段 1 已完成并验收：修改 `notebatch/__init__.py`，扩充 `test_notebatch.py`，保持 `notebatch/__main__.py` 的现有 CLI 行为；交接记录由主线程维护本文件，README 已提供入口。
- 阶段 2 待明天的新任务继续，今天不实施。依赖已验收的阶段 1；主要修改 `notebatch/__main__.py`、`test_notebatch.py`、`README.md`，必要时在 `notebatch/__init__.py` 添加最小辅助逻辑，同时保留现有 API。
- 阶段 2 验证须覆盖：文件/stdin × json/jsonl；默认数组兼容性；Unicode 和换行；空 JSONL 零字节；默认保留重复项；清洗后 casefold 去重（包括 Unicode，如 Straße/STRASSE）、首项完整对象/大小写/顺序保留且 tags 不合并；两种输出格式下非法 JSON、靠后的无效条目、不可打开的文件都以码 2 退出且 stdout 为空、错误前缀正确、无 traceback；非法参数保持 argparse 行为。复用阶段 1 测试，运行 `python3 -m unittest -v`。

# Status

- 阶段 1 已于 2026-09-07 验收，今天的任务到此结束。初始工作树干净；HEAD 为 `895c81a`（Initial fixture）。当前未提交改动均属于阶段 1 和交接：`notebatch/__init__.py`、`test_notebatch.py`、`README.md`、新增 `.agent/STATE.md`。新任务须保留这些已验收改动，不得当作临时文件丢弃。
- 实现：`normalize_entries` 验证列表/对象/非空字符串标题/字符串标签列表，构建新的对象和标签列表，完成 strip、标签排序去重、未知字段丢弃与顺序保留；错误信息包含条目/标签索引。`read_entries` 沿用 `json.loads` 后归一化；非法 JSON 的 `JSONDecodeError` 是 `ValueError` 子类。公开 API 与 `render_json` 保持兼容。
- 决定性证据：新增测试在修复前捕获原始缺陷（15 个测试，含子测试共 38 failures、6 errors）；修复后 `python3 -m unittest -v` 返回码 0，15 个测试全部通过。覆盖有效/非法输入、标签大小写敏感排序去重、重复条目和顺序保留、成功/失败时输入不变性、返回对象不共享可变输入、JSON 解析/校验、Unicode 和末尾换行。文件 CLI 子进程测试包含空数组、需清洗的中文对象和重复标题，确认数组输出、退出码 0、stderr 为空。
- 已由主线程检查最终代码差异；`git diff --check` 通过。验收后仅更新 README 交接入口和本记录，代码与测试输入未变，可复用上述测试证据。
- 阶段 2 尚未实现：`notebatch/__main__.py` 完全未改，仍仅接受文件输入并输出数组；stdin、`--format`、`--unique`、CLI 错误转换都待办。不要将阶段 1 的 API 异常测试视为阶段 2 CLI 错误行为已验证。
- 精确恢复步骤：在同一工作树先读本文件，再执行 `git status --short --untracked-files=all` 与 `git diff -- README.md notebatch/__init__.py notebatch/__main__.py test_notebatch.py`，查看上述代码/测试。按 Goal 中固定接口补充阶段 2 CLI 行为测试，实施输入读取→整批归一化→可选去重→渲染→stdout 写出的流程，确保输入失败发生在任何 stdout 输出之前；添加 README 用法。运行 `python3 -m unittest -v` 和 `git diff --check`，自行审查并更新本文件的进度与证据，直接交付，不要求用户重复说明约定或批准，不创建提交。
- 修复重试：0（测试先暴露旧实现缺陷，首次实现即通过）；阻塞：无；Git commit：用户明确要求两阶段都不执行，已跳过 checkpoint commit，未 push 或创建 PR。
