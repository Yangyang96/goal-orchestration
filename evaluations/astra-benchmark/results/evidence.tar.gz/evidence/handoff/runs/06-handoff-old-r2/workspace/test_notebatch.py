import copy
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from notebatch import normalize_entries, read_entries, render_json


class NoteBatchTests(unittest.TestCase):
    def test_existing_normalized_entry(self):
        value = [{'title': 'Inbox', 'tags': ['home']}]
        self.assertEqual(normalize_entries(value), value)

    def test_empty_batch(self):
        self.assertEqual(read_entries('[]'), [])

    def test_normalizes_titles_tags_and_ignores_unknown_fields(self):
        entries = [
            {
                'title': ' \t中文标题\n',
                'tags': [' z ', '', ' A', 'a ', 'z', '\t', ' a', '中文 '],
                'extra': {'ignored': True},
            },
            {'title': ' Second '},
        ]
        self.assertEqual(normalize_entries(entries), [
            {'title': '中文标题', 'tags': ['A', 'a', 'z', '中文']},
            {'title': 'Second', 'tags': []},
        ])

    def test_preserves_entry_order_and_duplicate_titles(self):
        entries = [
            {'title': ' B ', 'tags': ['first']},
            {'title': 'A'},
            {'title': 'B', 'tags': ['last']},
        ]
        self.assertEqual(normalize_entries(entries), [
            {'title': 'B', 'tags': ['first']},
            {'title': 'A', 'tags': []},
            {'title': 'B', 'tags': ['last']},
        ])

    def test_does_not_mutate_or_share_input_data(self):
        entries = [
            {'title': ' First ', 'tags': [' z ', 'a', 'a'], 'extra': [1]},
            {'title': 'Second'},
            {'title': 'Third'},
        ]
        original = copy.deepcopy(entries)
        normalized = normalize_entries(entries)
        self.assertEqual(entries, original)
        normalized[0]['title'] = 'Changed'
        normalized[0]['tags'].append('new')
        normalized[1]['tags'].append('separate')
        normalized.append({'title': 'Added', 'tags': []})
        self.assertEqual(entries, original)
        self.assertEqual(normalized[2]['tags'], [])

    def test_rejects_non_list_collections(self):
        for entries in (None, True, 42, 'notes', {}, (), iter([])):
            with self.subTest(entries=entries):
                with self.assertRaises(ValueError):
                    normalize_entries(entries)

    def test_rejects_non_object_entries(self):
        for entry in (None, True, 42, 'note', [], ['title', 'note']):
            with self.subTest(entry=entry):
                with self.assertRaises(ValueError):
                    normalize_entries([entry])

    def test_rejects_missing_or_invalid_titles(self):
        entries = [{}] + [
            {'title': title}
            for title in (None, True, 42, [], {}, '', ' \t\n\u3000')
        ]
        for entry in entries:
            with self.subTest(entry=entry):
                with self.assertRaises(ValueError):
                    normalize_entries([entry])

    def test_rejects_invalid_tags(self):
        for tags in (None, True, 42, 'tag', {}, (), [None], ['ok', 42], [False], [[]]):
            with self.subTest(tags=tags):
                with self.assertRaises(ValueError):
                    normalize_entries([{'title': 'Valid', 'tags': tags}])

    def test_does_not_mutate_input_when_a_later_entry_is_invalid(self):
        entries = [
            {'title': ' First ', 'tags': [' z ', 'a', 'a']},
            {'title': 'Second', 'tags': [' okay ', None]},
        ]
        original = copy.deepcopy(entries)
        with self.assertRaises(ValueError):
            normalize_entries(entries)
        self.assertEqual(entries, original)

    def test_read_entries_applies_normalization(self):
        text = '[{"title": "  中文  ", "tags": [" b ", "a", "b", ""], "extra": 1}]'
        self.assertEqual(read_entries(text), [
            {'title': '中文', 'tags': ['a', 'b']},
        ])

    def test_read_entries_rejects_invalid_json(self):
        for text in ('', '[', '[{"title": "Note",}]', '[] trailing'):
            with self.subTest(text=text):
                with self.assertRaises(ValueError):
                    read_entries(text)

    def test_read_entries_rejects_invalid_data(self):
        for text in ('null', '{}', '"text"', '1', '[null]', '[{}]',
                     '[{"title": " "}]', '[{"title": "Note", "tags": null}]'):
            with self.subTest(text=text):
                with self.assertRaises(ValueError):
                    read_entries(text)

    def test_file_cli_preserves_json_array_output(self):
        root = Path(__file__).resolve().parent
        cases = [
            ([], []),
            ([{'title': ' 中文 ', 'tags': [' b ', 'a', 'b']}],
             [{'title': '中文', 'tags': ['a', 'b']}]),
            ([{'title': ' Same '}, {'title': 'Same'}],
             [{'title': 'Same', 'tags': []}, {'title': 'Same', 'tags': []}]),
        ]
        for entries, expected in cases:
            with self.subTest(entries=entries):
                with tempfile.TemporaryDirectory(dir=root) as directory:
                    source = Path(directory) / 'notes.json'
                    source.write_text(json.dumps(entries), encoding='utf-8')
                    result = subprocess.run(
                        [sys.executable, '-m', 'notebatch', str(source)],
                        cwd=root, capture_output=True, text=True, encoding='utf-8',
                    )
                self.assertEqual(result.returncode, 0, result.stderr)
                self.assertEqual(result.stderr, '')
                self.assertEqual(json.loads(result.stdout), expected)
                self.assertEqual(result.stdout, render_json(expected))

    def test_json_output(self):
        value = [{'title': '中文', 'tags': []}]
        rendered = render_json(value)
        self.assertEqual(json.loads(rendered), value)
        self.assertTrue(rendered.endswith('\n'))
        self.assertIn('中文', rendered)


class NoteBatchCLITests(unittest.TestCase):
    root = Path(__file__).resolve().parent

    def run_cli(self, args, stdin=None):
        return subprocess.run(
            [sys.executable, '-m', 'notebatch', *args],
            input=stdin, cwd=self.root, capture_output=True,
            text=True, encoding='utf-8',
        )

    def export(self, text, source, *args):
        if source == 'stdin':
            return self.run_cli(['-', *args], stdin=text)
        with tempfile.TemporaryDirectory(dir=self.root) as directory:
            path = Path(directory) / 'notes.json'
            path.write_text(text, encoding='utf-8')
            return self.run_cli([str(path), *args])

    def assert_input_error(self, result, reason):
        self.assertEqual(result.returncode, 2, result.stderr)
        self.assertEqual(result.stdout, '')
        self.assertTrue(result.stderr.startswith('input error:'), result.stderr)
        self.assertIn(reason, result.stderr)
        self.assertNotIn('Traceback', result.stderr)

    def test_sources_and_formats_normalize_and_keep_duplicates_by_default(self):
        text = json.dumps([
            {'title': ' 中文 "笔记"\n第二行 ', 'tags': [' z ', '标签', 'z', ''],
             'extra': 'ignored'},
            {'title': ' 中文 "笔记"\n第二行 ', 'tags': ['later']},
        ], ensure_ascii=False)
        expected = [
            {'title': '中文 "笔记"\n第二行', 'tags': ['z', '标签']},
            {'title': '中文 "笔记"\n第二行', 'tags': ['later']},
        ]
        jsonl = (
            '{"title":"中文 \\"笔记\\"\\n第二行","tags":["z","标签"]}\n'
            '{"title":"中文 \\"笔记\\"\\n第二行","tags":["later"]}\n'
        )
        for source in ('file', 'stdin'):
            for args, output in (((), render_json(expected)),
                                 (('--format', 'json'), render_json(expected)),
                                 (('--format', 'jsonl'), jsonl)):
                with self.subTest(source=source, args=args):
                    result = self.export(text, source, *args)
                    self.assertEqual(result.returncode, 0, result.stderr)
                    self.assertEqual(result.stderr, '')
                    self.assertEqual(result.stdout, output)

    def test_unique_uses_cleaned_casefold_and_keeps_first_complete_object(self):
        text = json.dumps([
            {'title': ' Straße ', 'tags': [' z ', 'first', 'first']},
            {'title': ' Inbox ', 'tags': ['original']},
            {'title': ' STRASSE ', 'tags': ['not-merged']},
            {'title': 'inBOX', 'tags': ['also-not-merged']},
            {'title': ' Last '},
        ], ensure_ascii=False)
        expected = [
            {'title': 'Straße', 'tags': ['first', 'z']},
            {'title': 'Inbox', 'tags': ['original']},
            {'title': 'Last', 'tags': []},
        ]
        jsonl = (
            '{"title":"Straße","tags":["first","z"]}\n'
            '{"title":"Inbox","tags":["original"]}\n'
            '{"title":"Last","tags":[]}\n'
        )
        for source in ('file', 'stdin'):
            for args, output in (((), render_json(expected)),
                                 (('--format', 'json'), render_json(expected)),
                                 (('--format', 'jsonl'), jsonl)):
                with self.subTest(source=source, args=args):
                    result = self.export(text, source, '--unique', *args)
                    self.assertEqual(result.returncode, 0, result.stderr)
                    self.assertEqual(result.stderr, '')
                    self.assertEqual(result.stdout, output)

    def test_empty_batches(self):
        for source in ('file', 'stdin'):
            for output_format, output in (('json', '[]\n'), ('jsonl', '')):
                for unique in ((), ('--unique',)):
                    with self.subTest(source=source, format=output_format, unique=unique):
                        result = self.export('[]', source, '--format', output_format, *unique)
                        self.assertEqual(result.returncode, 0, result.stderr)
                        self.assertEqual(result.stderr, '')
                        self.assertEqual(result.stdout, output)

    def test_input_errors_never_emit_partial_output(self):
        cases = [
            ('[{"title":"Valid"},', 'Expecting value'),
            ('{"title":"One"}\n{"title":"Two"}\n', 'Extra data'),
            ('{}', 'entries must be a list'),
            ('[{"title":"Valid"},{"title":" "}]', 'entry 1 title'),
            ('[{"title":"Same"},{"title":" same ","tags":[null]}]', 'entry 1 tag 0'),
        ]
        for source in ('file', 'stdin'):
            for output_format in ('json', 'jsonl'):
                for unique in ((), ('--unique',)):
                    for text, reason in cases:
                        with self.subTest(source=source, format=output_format,
                                          unique=unique, text=text):
                            result = self.export(text, source, '--format', output_format, *unique)
                            self.assert_input_error(result, reason)

    def test_unreadable_files_are_input_errors(self):
        with tempfile.TemporaryDirectory(dir=self.root) as directory:
            for path in (Path(directory) / 'missing.json', Path(directory)):
                for output_format in ('json', 'jsonl'):
                    with self.subTest(path=path, format=output_format):
                        result = self.run_cli([str(path), '--format', output_format])
                        self.assert_input_error(result, str(path))

    def test_invalid_arguments_keep_argparse_behavior(self):
        for args in ([], ['-', '--format', 'xml'], ['-', '--format'],
                     ['-', '--unknown'], ['-', '--unique=true']):
            with self.subTest(args=args):
                result = self.run_cli(args, stdin='[]')
                self.assertEqual(result.returncode, 2, result.stderr)
                self.assertEqual(result.stdout, '')
                self.assertTrue(result.stderr.startswith('usage:'), result.stderr)
                self.assertIn('error:', result.stderr)
                self.assertNotIn('input error:', result.stderr)
                self.assertNotIn('Traceback', result.stderr)


if __name__ == '__main__':
    unittest.main()
