# Goal

NoteBatch 分两阶段接入导出消费端。今天只完成阶段 1；阶段 2 留给一个看不到本次聊天、只能读取同一工作树的全新任务。两阶段均不要 Git commit，也不要 push 或创建 PR。仅在当前工作目录工作，不修改其他目录；不读取工作目录外的项目、测试判卷器、其他候选结果或全局 Skill；不委派子 Agent，不调用外部应用。可用本地 shell、文件工具和 Git，并遵守现有权限。

阶段 1 验收：按 README 实现 `normalize_entries(entries)` / `read_entries(text)` 的归一化、校验与 `ValueError` 约定；保留公开 API 和文件输入 CLI 的 JSON 数组输出，补充并运行必要测试。输入必须是对象列表；每项 title 必须是字符串，strip 后非空；tags 缺省为新空列表，显式提供时必须是字符串列表，逐项 strip、丢弃空标签、区分大小写去重、按 Python 字符串顺序排序。只输出 title 和 tags，保留条目顺序，不修改输入。`read_entries` 解析 JSON 后应用相同归一化。

阶段 2 已获用户授权，明天继续时直接实现、测试、更新使用文档并完成，不需要再次确认或提交。以下接口已与消费端确定，不得自行改名或替换：

1. 位置参数 `input` 接受文件路径或单独的 `-`；`-` 读取 stdin。两种来源均输入同一种 JSON 数组，均使用阶段 1 归一化；不增加 JSONL 输入。
2. `--format json|jsonl`，默认 `json`，保持现有 JSON 数组输出。`jsonl` 每个归一化对象一行紧凑 JSON，逗号和冒号后无空格，保留 Unicode 原字符；非空批次最后一行也有换行。空批次输出零字节，不能输出 `[]` 或空行。
3. `--unique` 默认关闭，关闭时保留所有条目；开启时按清洗后的 `title.casefold()` 判断重复，保留第一次出现的完整对象和原始顺序，不合并后续对象的 tags，不改变保留标题的大小写。对两种输出格式均生效。
4. 非法 JSON、归一化失败、输入文件打不开：CLI 退出码均为 `2`，stdout 必须为空，stderr 以 `input error:` 开头并说明原因，不得输出 traceback。即使错误条目靠后，也不得输出任何前面条目的部分结果。参数使用错误保持 argparse 常规行为。

# Plan

- 阶段 1 已完成并验收：归一化实现位于 `notebatch/__init__.py`，原有 15 个测试保留；阶段 2 未修改该模块和既有公开 API。
- 阶段 2 已在本次续接任务完成并验收：修改 `notebatch/__main__.py`、`test_notebatch.py`、`README.md`，主线程更新本文件。stdin、两种输出格式、可选去重及 CLI 输入错误转换均按 Goal 中固定接口实现。
- 两阶段均已完成，无剩余实施任务；保留未提交工作树，直接交付。

# Status

- 阶段 1 于 2026-09-07 验收；阶段 2 于本次续接任务（2026-09-07）验收。HEAD 仍为 `895c81a`（Initial fixture）。恢复时已核对 status/diff，保留阶段 1 的 `notebatch/__init__.py`、`test_notebatch.py`、`README.md` 和 `.agent/STATE.md` 改动；本次仅在当前工作目录实施。
- 阶段 1 证据保留：初次修复前 15 个测试含子测试共 38 failures、6 errors，修复后全部通过。归一化构建新对象和标签列表，执行 strip、标签排序去重、未知字段丢弃、顺序保留及带索引的 ValueError 校验；read_entries 和 render_json 保持兼容。
- 阶段 2 实现：CLI 先读取文件或 stdin 并整批归一化，再按需以 title.casefold() 去重，完整渲染后写 stdout。默认 JSON 数组输出沿用 render_json；JSONL 紧凑、保留 Unicode、每对象末尾换行且空批次零字节。去重保留首项完整对象和顺序。读取或校验失败捕获 OSError/ValueError，stderr 输出 input error: 原因并返回 2；argparse 参数校验独立执行。
- 决定性证据：新增 `NoteBatchCLITests` 的 6 个测试在实施前产生 63 个子测试失败，暴露缺失功能；实施后 `python3 -m unittest -v` 返回码 0，全部 21 个测试通过（包含原有 15 个）。新增子进程检查覆盖文件/stdin × 默认/json/jsonl、默认重复项保留、Unicode/引号/内部换行、JSONL 精确输出、空输出、清洗后 ASCII/Unicode casefold 去重及首项 tags 不合并；两种来源和格式下非法 JSON、JSONL 输入、非数组、后置非法标题/标签（含去重后本会丢弃的重复项）均码 2、stdout 空、错误前缀与原因正确且无 traceback；不存在路径/目录输入同样处理；非法参数保留 argparse 行为。
- 主线程已审查最终实现、测试及 README 差异，`git diff --check` 通过。README 已补充完整用法和错误约定。验收后仅更新本记录并清理本次临时失败日志，代码及测试输入未变，复用上述通过证据。
- 修复重试：阶段 1 为 0、阶段 2 为 0（新增测试先暴露缺失功能，首次实现即通过）；阻塞：无。Git commit：按用户明确约定跳过，两阶段改动均未提交；未 push 或创建 PR。
- 精确下一步：向用户交付阶段 2 完成情况和验证结果并结束；无需继续实施或重复批准。未来仅在有新需求时继续，保留当前全部已验收改动。
