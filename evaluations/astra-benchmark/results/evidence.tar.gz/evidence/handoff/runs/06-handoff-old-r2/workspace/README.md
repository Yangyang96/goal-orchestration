# NoteBatch
A small local note-export utility using Python's standard library.

Run `python3 -m notebatch notes.json` to emit a JSON array.
Run `python3 -m unittest -v` to test the package.
Public functions: `normalize_entries(entries)`, `read_entries(text)`,
`render_json(entries)`.

## Input normalization
Input is a list of objects. Each object has a nonempty string title after
stripping whitespace. Tags are an optional list of strings, defaulting to [].
Strip each tag, discard empty tags, deduplicate exactly and sort by Python string
order. Tag matching is case-sensitive. Output contains only title and tags;
unknown fields are ignored. Preserve entry order, and never mutate input data.
Invalid entry collections, titles, or tags raise ValueError. read_entries parses
JSON and applies normalization.

## CLI usage

```sh
python3 -m notebatch notes.json
python3 -m notebatch notes.json --format jsonl
python3 -m notebatch - --format jsonl --unique < notes.json
```

The required `input` argument accepts a UTF-8 file path or a single `-` to read
stdin. Both sources accept a JSON array and apply the normalization above;
JSONL input is not supported.

`--format json|jsonl` defaults to `json`, preserving the indented JSON array
and its final newline. `jsonl` emits one compact JSON object per line, with no
spaces after commas or colons and Unicode characters preserved. Every object,
including the last, has a trailing newline. An empty batch emits zero bytes in
JSONL format (and `[]` followed by a newline in JSON format).

`--unique` is off by default, so repeated entries are preserved. When enabled,
it compares normalized titles using `title.casefold()` (for example, `Straße`
and `STRASSE` match), keeping the first complete object and its title casing.
Retained entries stay in their original order; later tags are not merged.
This option works with either output format and either input source.

Invalid JSON, invalid note data, and files that cannot be opened produce exit
code `2`, empty stdout, and a reason on stderr beginning with `input error:`;
no traceback is emitted. The entire batch is validated before deduplication
or output, so even a later invalid entry cannot cause partial output. Invalid
command-line arguments use the usual argparse usage and error messages.

## Development handoff
Stage 1 normalization and stage 2 CLI integration are complete.
[.agent/STATE.md](.agent/STATE.md) records the agreed interfaces and acceptance
checks for both stages.
Both stages must remain uncommitted.
