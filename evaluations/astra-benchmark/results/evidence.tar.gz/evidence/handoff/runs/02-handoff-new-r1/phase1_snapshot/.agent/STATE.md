# NoteBatch 两阶段交接

记录日期：2026-09-07。供看不到前次聊天、只读取同一工作树的新任务接续。
阶段 1 已完成；阶段 2 按用户要求留待明天的新任务实现，本次到此停止。

## 目标与授权边界

- 总目标：把 NoteBatch 接到消费端导出流程；阶段 1 修复归一化，阶段 2 扩展 CLI。
- 两阶段均不要 Git commit。阶段 1 的修改直接保留在当前工作树，接续时不要丢弃。
- 只在当前工作目录内工作，其他目录有独立工作，不能修改。不要读取工作目录外的项目、测试判卷器、其他候选结果或全局 Skill；不委派子 Agent，不调用外部应用。可用本地 shell、文件工具和 Git，遵守权限限制。
- 本次使用用户提供的 `goal-orchestration`；恢复所需的业务约定均记录于此，无需依赖旧聊天或其他目录。
- 阶段 2 已获授权：实现、补充测试和使用文档、运行相关检查并直接完成，不需要再次确认，也不需要提交。
- 记录是恢复依据；接续任务的最新用户指令和实际工作树状态优先。

## 阶段 1：已完成

保留公共 API：`normalize_entries(entries)`、`read_entries(text)`、`render_json(entries)`。

`notebatch/__init__.py` 已实现 README 的约定：

- 输入必须是 list，每项必须是 dict；title 必须是字符串，`strip()` 后非空，输出清洗后的标题。
- tags 可省略，默认独立的空列表；显式提供时必须是字符串列表。每个标签 `strip()`，丢弃空标签，精确去重，按 Python 字符串顺序排序，区分大小写。
- 输出只含 title 和 tags，忽略未知字段；保持条目顺序及重复条目，不修改输入，也不共享输入的可变对象。
- 非法集合、条目、标题和标签均抛出 `ValueError`，条目校验消息带从 1 开始的位置。
- `read_entries` 仍使用 `json.loads` 后调用归一化；非法 JSON 的 `JSONDecodeError` 属于 `ValueError`。
- `render_json` 保持 `ensure_ascii=False, indent=2` 和末尾一个换行。

`notebatch/__main__.py` 未修改，仍只接受文件路径并输出 JSON 数组。
它目前没有 stdin、`--format`、`--unique`，也没有统一的 CLI 输入错误处理；这些均为阶段 2 待办。

`test_notebatch.py` 从 3 个测试扩充为 10 个，涵盖清洗、字段过滤、顺序和重复条目、
大小写敏感的标签去重排序、成功及失败时的输入不变性、返回值不共享可变数据、
缺省标签列表独立性、非法类型、非法 JSON 和文件 CLI 的 Unicode JSON 数组输出。
CLI 测试的临时输入文件建在项目目录下并自动清理，无外部依赖。

验证证据：新增测试先在旧实现上失败，修复后运行 `python3 -m unittest -v`，
10 个测试全部通过（退出码 0）。现有文件 CLI 的回归测试也在此命令中通过。
`git diff --check` 通过。工作树交付文件为上述实现、测试、README 和本记录，没有提交。
README 仅新增本交接记录入口，阶段 2 的使用文档尚未编写。没有已知阻塞。

## 阶段 2：消费端已确认的固定接口（全部待实现）

以下名称和语义不能自行改名或替换：

1. 位置参数仍叫 `input`，接受文件路径，也接受单独的 `-` 表示读取 stdin。
   两种来源都是同一种 JSON **数组**输入，均通过阶段 1 的归一化；jsonl 只是输出格式。
2. 增加 `--format json|jsonl`，默认 `json`，保持现有 JSON 数组输出。
   `jsonl` 每个归一化对象一行紧凑 JSON，逗号和冒号后不加空格，保留 Unicode 原字符。
   非空批次最后一行也必须有换行；空批次输出严格为零字节，不能输出 `[]` 或空行。
3. 增加 `--unique`，默认关闭，关闭时保留所有条目。
   开启时按清洗后的 `title.casefold()` 判断重复，保留第一次出现的**完整归一化对象**和原始顺序。
   不合并后续对象的 tags，不改变保留标题的大小写；对 `json` 和 `jsonl` 都生效。
   不要将去重变成 `normalize_entries` 的默认行为。
4. 非法 JSON、归一化失败或输入文件打不开时：CLI 退出码必须为 **2**，stdout 严格为空，
   stderr 以 **`input error:`** 开头并说明原因，不输出 traceback。
   即使错误条目靠后，也不能先输出前面的条目。参数使用错误保持 argparse 常规行为。
5. 补充测试和 README 使用文档，运行相关检查并完成阶段 2；不要 Git commit。

## 接续步骤与验收重点

1. 先读本记录、README、`notebatch/__init__.py`、`notebatch/__main__.py` 和 `test_notebatch.py`，
   结合当前 `git status --short` / `git diff` 确认阶段 1 修改仍在，保护新增的无关用户改动。
2. 在现有 CLI 上增加固定参数和 stdin 分支，复用 `read_entries`。先读取并归一化整个数组，
   再按需去重、渲染，成功后才写 stdout，确保后置错误不会产生部分输出。
   输入处理可针对 `OSError` 和 `ValueError` 转成约定错误；参数解析保持 argparse 自身处理。
   JSONL 可用 `json.dumps(..., ensure_ascii=False, separators=(',', ':'))` 构造每行。
3. 补充可观察行为测试，至少覆盖：
   - 文件 / stdin × 默认 json / 显式 json / jsonl，Unicode 和阶段 1 清洗结果一致。
   - JSONL 的精确行内容、紧凑分隔符、末尾换行及空批次零字节；json 空批次仍为数组。
   - `--unique` 开关及两种格式：去空白后再 casefold、保留首次标题大小写和 tags、稳定顺序。
     使用如 `Straße` / `STRASSE` 验证 casefold 语义，避免仅验证 ASCII 小写；默认仍保留重复项。
   - 文件与 stdin 的非法 JSON、靠后条目归一化失败，以及无法打开的文件：
     退出码 2、stdout 零字节、stderr 前缀和原因、无 traceback；两种格式都不能漏出部分结果。
   - 参数用法错误（如未知 format、缺少 input）仍是 argparse 常规错误。
4. README 增加文件和 stdin、json/jsonl、`--unique`、空输出及错误约定的使用说明，
   保留公共 API 和归一化文档。运行 `python3 -m unittest -v` 及 `git diff --check`。
   阶段 1 的已通过证据仅适用于未变的相关输入；阶段 2 修改后运行覆盖新行为的检查。
5. 更新本记录的实际状态与验证结果，简明交付。全部要求满足即完成，不追加提交或其他流程门槛。
