import copy
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from notebatch import normalize_entries, read_entries, render_json


class NoteBatchTests(unittest.TestCase):
    def test_existing_normalized_entry(self):
        value = [{'title': 'Inbox', 'tags': ['home']}]
        self.assertEqual(normalize_entries(value), value)

    def test_empty_batch(self):
        self.assertEqual(read_entries('[]'), [])

    def test_normalization_preserves_order_and_only_known_fields(self):
        entries = [
            {'title': ' \t中文\n', 'tags': [' z ', '', 'a', 'A', 'a', '\t', ' z'],
             'ignored': {'anything': True}},
            {'title': ' Second '},
            {'title': ' 中文 ', 'tags': []},
        ]
        expected = [
            {'title': '中文', 'tags': ['A', 'a', 'z']},
            {'title': 'Second', 'tags': []},
            {'title': '中文', 'tags': []},
        ]
        self.assertEqual(normalize_entries(entries), expected)
        self.assertEqual(read_entries(json.dumps(entries)), expected)

    def test_normalization_does_not_mutate_or_alias_input(self):
        entries = [{'title': ' Note ', 'tags': [' b ', 'a', 'a'],
                    'extra': {'values': [1]}}]
        original = copy.deepcopy(entries)
        normalized = normalize_entries(entries)
        self.assertEqual(entries, original)
        normalized[0]['title'] = 'Changed'
        normalized[0]['tags'].append('new')
        normalized.append({'title': 'Another', 'tags': []})
        self.assertEqual(entries, original)

    def test_default_tag_lists_are_independent(self):
        normalized = normalize_entries([{'title': 'One'}, {'title': 'Two'}])
        normalized[0]['tags'].append('new')
        self.assertEqual(normalized[1]['tags'], [])

    def test_invalid_collections_raise_value_error(self):
        for entries in (None, {}, 'notes', 42, 1.5, True, ()):
            with self.subTest(entries=entries):
                with self.assertRaises(ValueError):
                    normalize_entries(entries)

    def test_invalid_entries_titles_and_tags_raise_value_error(self):
        invalid_entries = [None, [], 'note', 42, True, {}]
        invalid_entries.extend({'title': title} for title in
                               (None, '', ' \t\n', 42, False, [], {}))
        invalid_entries.extend({'title': 'Note', 'tags': tags} for tags in
                               (None, 'tag', 42, False, {}, ('tag',),
                                [None], [42], [False], [[]], [{}]))
        for entry in invalid_entries:
            with self.subTest(entry=entry):
                entries = [{'title': ' Valid ', 'tags': [' b ', 'a']}, entry]
                original = copy.deepcopy(entries)
                with self.assertRaises(ValueError):
                    normalize_entries(entries)
                self.assertEqual(entries, original)

    def test_read_entries_rejects_invalid_json_and_invalid_data(self):
        for text in ('', '[', '[{"title": "Note"},]', 'null', '{}', '"notes"',
                     '42', 'true', '[null]', '[{}]', '[{"title": " "}]',
                     '[{"title": "Note", "tags": null}]',
                     '[{"title": "Good"}, {"title": "Bad", "tags": [1]}]'):
            with self.subTest(text=text):
                with self.assertRaises(ValueError):
                    read_entries(text)

    def test_legacy_file_cli_emits_normalized_json_array(self):
        project_root = Path(__file__).resolve().parent
        entries = [{'title': ' 中文 ', 'tags': [' z ', 'a', 'a']},
                   {'title': '中文'}]
        with tempfile.TemporaryDirectory(dir=project_root) as directory:
            input_path = Path(directory) / 'notes.json'
            input_path.write_text(json.dumps(entries), encoding='utf-8')
            result = subprocess.run(
                [sys.executable, '-m', 'notebatch', str(input_path)],
                cwd=project_root, capture_output=True, text=True, encoding='utf-8',
            )
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(result.stderr, '')
        self.assertEqual(json.loads(result.stdout), [
            {'title': '中文', 'tags': ['a', 'z']},
            {'title': '中文', 'tags': []},
        ])
        self.assertIn('中文', result.stdout)
        self.assertTrue(result.stdout.endswith('\n'))

    def test_json_output(self):
        value = [{'title': '中文', 'tags': []}]
        rendered = render_json(value)
        self.assertEqual(json.loads(rendered), value)
        self.assertTrue(rendered.endswith('\n'))
        self.assertIn('中文', rendered)


if __name__ == '__main__':
    unittest.main()
