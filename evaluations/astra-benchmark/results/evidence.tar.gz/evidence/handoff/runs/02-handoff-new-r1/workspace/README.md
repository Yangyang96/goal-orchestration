# NoteBatch
A small local note-export utility using Python's standard library.

Run `python3 -m unittest -v` to test the package.
Public functions: `normalize_entries(entries)`, `read_entries(text)`,
`render_json(entries)`.

## Input normalization
Input is a list of objects. Each object has a nonempty string title after
stripping whitespace. Tags are an optional list of strings, defaulting to [].
Strip each tag, discard empty tags, deduplicate exactly and sort by Python string
order. Tag matching is case-sensitive. Output contains only title and tags;
unknown fields are ignored. Preserve entry order, and never mutate input data.
Invalid entry collections, titles, or tags raise ValueError. read_entries parses
JSON and applies normalization. Duplicate entries are preserved by default.

## CLI usage

The positional `input` argument accepts a UTF-8 file path or `-` to read stdin.
Both sources must contain a single JSON array and use the normalization above.

```sh
python3 -m notebatch notes.json
python3 -m notebatch notes.json --format json
python3 -m notebatch notes.json --format jsonl --unique
python3 -m notebatch - --format jsonl < notes.json
printf '%s' '[{"title":" Straße "},{"title":"STRASSE"}]' | python3 -m notebatch - --unique
```

`--format json|jsonl` defaults to `json`: a JSON array indented by two spaces,
with a final newline. `jsonl` emits one compact normalized object per line, with
no spaces after commas or colons and a newline after every object, including the
last. Both formats preserve Unicode characters. An empty batch emits `[]` plus
a newline in `json`, and exactly zero bytes in `jsonl`. JSONL is an output format;
the input must still be a JSON array.

`--unique` is off by default. When enabled, it compares stripped titles using
Python's `str.casefold()` and keeps the first complete normalized object in its
original position. For example, `Straße` and `STRASSE` are duplicates: the first
title's spelling and tags are retained, and later tags are not merged. This option
works with both output formats and does not change the public normalization API.

Invalid JSON, invalid note data, and input file read errors exit with status `2`.
Stdout is empty; stderr starts with `input error:` and explains the cause, without
a traceback. The entire input is validated before any output, even with
`--unique`. Argument usage errors, such as a missing `input` or an unsupported
format, use the standard argparse usage/error message and exit with status `2`.

Development handoff and completion record: [`.agent/STATE.md`](.agent/STATE.md).
