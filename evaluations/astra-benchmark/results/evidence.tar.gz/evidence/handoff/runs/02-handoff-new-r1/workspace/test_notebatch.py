import copy
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from notebatch import normalize_entries, read_entries, render_json


class NoteBatchTests(unittest.TestCase):
    def test_existing_normalized_entry(self):
        value = [{'title': 'Inbox', 'tags': ['home']}]
        self.assertEqual(normalize_entries(value), value)

    def test_empty_batch(self):
        self.assertEqual(read_entries('[]'), [])

    def test_normalization_preserves_order_and_only_known_fields(self):
        entries = [
            {'title': ' \t中文\n', 'tags': [' z ', '', 'a', 'A', 'a', '\t', ' z'],
             'ignored': {'anything': True}},
            {'title': ' Second '},
            {'title': ' 中文 ', 'tags': []},
        ]
        expected = [
            {'title': '中文', 'tags': ['A', 'a', 'z']},
            {'title': 'Second', 'tags': []},
            {'title': '中文', 'tags': []},
        ]
        self.assertEqual(normalize_entries(entries), expected)
        self.assertEqual(read_entries(json.dumps(entries)), expected)

    def test_normalization_does_not_mutate_or_alias_input(self):
        entries = [{'title': ' Note ', 'tags': [' b ', 'a', 'a'],
                    'extra': {'values': [1]}}]
        original = copy.deepcopy(entries)
        normalized = normalize_entries(entries)
        self.assertEqual(entries, original)
        normalized[0]['title'] = 'Changed'
        normalized[0]['tags'].append('new')
        normalized.append({'title': 'Another', 'tags': []})
        self.assertEqual(entries, original)

    def test_default_tag_lists_are_independent(self):
        normalized = normalize_entries([{'title': 'One'}, {'title': 'Two'}])
        normalized[0]['tags'].append('new')
        self.assertEqual(normalized[1]['tags'], [])

    def test_invalid_collections_raise_value_error(self):
        for entries in (None, {}, 'notes', 42, 1.5, True, ()):
            with self.subTest(entries=entries):
                with self.assertRaises(ValueError):
                    normalize_entries(entries)

    def test_invalid_entries_titles_and_tags_raise_value_error(self):
        invalid_entries = [None, [], 'note', 42, True, {}]
        invalid_entries.extend({'title': title} for title in
                               (None, '', ' \t\n', 42, False, [], {}))
        invalid_entries.extend({'title': 'Note', 'tags': tags} for tags in
                               (None, 'tag', 42, False, {}, ('tag',),
                                [None], [42], [False], [[]], [{}]))
        for entry in invalid_entries:
            with self.subTest(entry=entry):
                entries = [{'title': ' Valid ', 'tags': [' b ', 'a']}, entry]
                original = copy.deepcopy(entries)
                with self.assertRaises(ValueError):
                    normalize_entries(entries)
                self.assertEqual(entries, original)

    def test_read_entries_rejects_invalid_json_and_invalid_data(self):
        for text in ('', '[', '[{"title": "Note"},]', 'null', '{}', '"notes"',
                     '42', 'true', '[null]', '[{}]', '[{"title": " "}]',
                     '[{"title": "Note", "tags": null}]',
                     '[{"title": "Good"}, {"title": "Bad", "tags": [1]}]'):
            with self.subTest(text=text):
                with self.assertRaises(ValueError):
                    read_entries(text)

    def test_legacy_file_cli_emits_normalized_json_array(self):
        project_root = Path(__file__).resolve().parent
        entries = [{'title': ' 中文 ', 'tags': [' z ', 'a', 'a']},
                   {'title': '中文'}]
        with tempfile.TemporaryDirectory(dir=project_root) as directory:
            input_path = Path(directory) / 'notes.json'
            input_path.write_text(json.dumps(entries), encoding='utf-8')
            result = subprocess.run(
                [sys.executable, '-m', 'notebatch', str(input_path)],
                cwd=project_root, capture_output=True, text=True, encoding='utf-8',
            )
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(result.stderr, '')
        self.assertEqual(json.loads(result.stdout), [
            {'title': '中文', 'tags': ['a', 'z']},
            {'title': '中文', 'tags': []},
        ])
        self.assertIn('中文', result.stdout)
        self.assertTrue(result.stdout.endswith('\n'))

    def test_json_output(self):
        value = [{'title': '中文', 'tags': []}]
        rendered = render_json(value)
        self.assertEqual(json.loads(rendered), value)
        self.assertTrue(rendered.endswith('\n'))
        self.assertIn('中文', rendered)


class NoteBatchCLITests(unittest.TestCase):
    project_root = Path(__file__).resolve().parent
    formats = ((), ('--format', 'json'), ('--format', 'jsonl'))

    def run_cli(self, text, source, *options):
        with tempfile.TemporaryDirectory(dir=self.project_root) as directory:
            if source == 'stdin':
                input_arg = '-'
                stdin = text.encode('utf-8')
            else:
                input_path = Path(directory) / 'notes.json'
                input_path.write_text(text, encoding='utf-8')
                input_arg = str(input_path)
                stdin = b''
            return subprocess.run(
                [sys.executable, '-m', 'notebatch', input_arg, *options],
                cwd=self.project_root, input=stdin, capture_output=True,
            )

    def assert_input_error(self, result, reason):
        self.assertEqual(result.returncode, 2, result.stderr)
        self.assertEqual(result.stdout, b'')
        self.assertTrue(result.stderr.startswith(b'input error:'), result.stderr)
        self.assertIn(reason, result.stderr)
        self.assertNotIn(b'Traceback', result.stderr)

    def test_sources_and_formats_emit_exact_normalized_output(self):
        entries = [
            {'title': ' 中文 ', 'tags': [' z ', 'a', 'A', 'a', ' '],
             'ignored': True},
            {'title': ' Line\nbreak '},
            {'title': '中文'},
        ]
        expected_json = (
            '[\n'
            '  {\n'
            '    "title": "中文",\n'
            '    "tags": [\n'
            '      "A",\n'
            '      "a",\n'
            '      "z"\n'
            '    ]\n'
            '  },\n'
            '  {\n'
            '    "title": "Line\\nbreak",\n'
            '    "tags": []\n'
            '  },\n'
            '  {\n'
            '    "title": "中文",\n'
            '    "tags": []\n'
            '  }\n'
            ']\n'
        ).encode('utf-8')
        expected_jsonl = (
            '{"title":"中文","tags":["A","a","z"]}\n'
            '{"title":"Line\\nbreak","tags":[]}\n'
            '{"title":"中文","tags":[]}\n'
        ).encode('utf-8')
        for source in ('file', 'stdin'):
            for options in self.formats:
                with self.subTest(source=source, options=options):
                    result = self.run_cli(
                        json.dumps(entries, ensure_ascii=False), source, *options,
                    )
                    self.assertEqual(result.returncode, 0, result.stderr)
                    self.assertEqual(result.stderr, b'')
                    expected = expected_jsonl if 'jsonl' in options else expected_json
                    self.assertEqual(result.stdout, expected)

    def test_empty_batches(self):
        for source in ('file', 'stdin'):
            for options in self.formats:
                for unique in ((), ('--unique',)):
                    with self.subTest(source=source, options=options, unique=unique):
                        result = self.run_cli('[]', source, *options, *unique)
                        self.assertEqual(result.returncode, 0, result.stderr)
                        self.assertEqual(result.stderr, b'')
                        self.assertEqual(result.stdout, b'' if 'jsonl' in options else b'[]\n')

    def test_unique_preserves_first_complete_object_and_order(self):
        entries = [
            {'title': ' Straße ', 'tags': [' first ', 'first']},
            {'title': ' Other '},
            {'title': '\tSTRASSE\n', 'tags': ['later']},
            {'title': 'other', 'tags': ['discard']},
            {'title': ' 中文 ', 'tags': ['保留']},
            {'title': 'straße'},
        ]
        normalized = [
            {'title': 'Straße', 'tags': ['first']},
            {'title': 'Other', 'tags': []},
            {'title': 'STRASSE', 'tags': ['later']},
            {'title': 'other', 'tags': ['discard']},
            {'title': '中文', 'tags': ['保留']},
            {'title': 'straße', 'tags': []},
        ]
        for source in ('file', 'stdin'):
            for options in self.formats:
                for unique in ((), ('--unique',)):
                    with self.subTest(source=source, options=options, unique=unique):
                        result = self.run_cli(
                            json.dumps(entries, ensure_ascii=False), source, *options, *unique,
                        )
                        self.assertEqual(result.returncode, 0, result.stderr)
                        self.assertEqual(result.stderr, b'')
                        if 'jsonl' in options:
                            actual = [json.loads(line) for line in result.stdout.splitlines()]
                        else:
                            actual = json.loads(result.stdout)
                        expected = [normalized[0], normalized[1], normalized[4]] if unique else normalized
                        self.assertEqual(actual, expected)

    def test_invalid_input_never_emits_partial_output(self):
        invalid_inputs = (
            # JSON decoder wording varies by Python version; its location is stable.
            ('[{"title":"Good"},]', b': line 1 column'),
            ('{}', b'entries must be a list'),
            ('[{"title":"Good"},{"title":" "}]', b'entry 2 title'),
            ('[{"title":"Good"},{"title":"GOOD","tags":[1]}]', b'entry 2 tags'),
        )
        for source in ('file', 'stdin'):
            for options in self.formats:
                for unique in ((), ('--unique',)):
                    for text, reason in invalid_inputs:
                        with self.subTest(source=source, options=options, unique=unique, text=text):
                            result = self.run_cli(text, source, *options, *unique)
                            self.assert_input_error(result, reason)

    def test_unreadable_file_reports_input_error(self):
        with tempfile.TemporaryDirectory(dir=self.project_root) as directory:
            for input_path in (Path(directory) / 'missing.json', Path(directory)):
                for options in self.formats:
                    with self.subTest(input_path=input_path, options=options):
                        result = subprocess.run(
                            [sys.executable, '-m', 'notebatch', str(input_path), *options],
                            cwd=self.project_root, input=b'', capture_output=True,
                        )
                        self.assert_input_error(result, str(input_path).encode('utf-8'))

    def test_argument_errors_use_argparse(self):
        for args in ((), ('--format', 'yaml', '-'), ('-', '--unknown')):
            with self.subTest(args=args):
                result = subprocess.run(
                    [sys.executable, '-m', 'notebatch', *args],
                    cwd=self.project_root, input=b'[]', capture_output=True,
                )
                self.assertEqual(result.returncode, 2, result.stderr)
                self.assertEqual(result.stdout, b'')
                self.assertTrue(result.stderr.startswith(b'usage:'), result.stderr)
                self.assertIn(b'error:', result.stderr)
                self.assertNotIn(b'input error:', result.stderr)
                self.assertNotIn(b'Traceback', result.stderr)


if __name__ == '__main__':
    unittest.main()
