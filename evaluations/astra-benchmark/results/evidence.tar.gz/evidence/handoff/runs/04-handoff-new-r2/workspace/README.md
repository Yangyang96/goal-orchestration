# NoteBatch
A small local note-export utility using Python's standard library.

Run `python3 -m notebatch notes.json` to emit a JSON array.
Run `python3 -m unittest -v` to test the package.
Public functions: `normalize_entries(entries)`, `read_entries(text)`,
`render_json(entries)`.

## Input normalization
Input is a list of objects. Each object has a nonempty string title after
stripping whitespace. Tags are an optional list of strings, defaulting to [].
Strip each tag, discard empty tags, deduplicate exactly and sort by Python string
order. Tag matching is case-sensitive. Output contains only title and tags;
unknown fields are ignored. Preserve entry order, and never mutate input data.
Invalid entry collections, titles, or tags raise ValueError. read_entries parses
JSON and applies normalization.

## Command-line usage

```sh
python3 -m notebatch input [--format json|jsonl] [--unique]
```

`input` is a UTF-8 JSON file path, or `-` to read stdin. Input is always a JSON
array of note objects, including when the output format is `jsonl`. The CLI
normalizes and validates the entire batch before writing any output.

```sh
# Default: an indented JSON array, preserving all entries.
python3 -m notebatch notes.json

# Read stdin and emit one compact JSON object per line.
printf '%s\n' '[{"title":" 中文 ","tags":[" b ","a","a"]}]' | python3 -m notebatch - --format jsonl
# Output: {"title":"中文","tags":["a","b"]}

# Keep only the first entry for each case-insensitive normalized title.
python3 -m notebatch notes.json --unique --format jsonl
```

- `--format json` (default) preserves the existing indented JSON array output
  with a final newline. An empty batch produces `[]` and a newline.
- `--format jsonl` emits compact objects with no spaces after commas or colons,
  preserving Unicode characters. Each object has a final newline; an empty
  batch produces zero bytes.
- `--unique` compares stripped titles using Python's `str.casefold()`, so
  `Straße` and `STRASSE` match. It keeps the first complete normalized object,
  including its title casing and tags, in the original order. Later tags are
  never merged. It works with either output format; by default duplicates are
  preserved. The public normalization API continues to preserve duplicates.

Invalid JSON, invalid note data, and file read errors exit with status `2`, leave
stdout empty, and report the cause on stderr starting with `input error:` without
a traceback. Invalid later entries still fail the whole batch, even if `--unique`
would otherwise discard them. Argument errors (such as a missing `input` or an
unsupported format) use the usual argparse usage and error messages.

## Development handoff
Both stages are complete. The normalization and CLI contracts and verification
record are in [.agent/STATE.md](.agent/STATE.md).
