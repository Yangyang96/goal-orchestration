import copy
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from notebatch import normalize_entries, read_entries, render_json


class NoteBatchTests(unittest.TestCase):
    def test_existing_normalized_entry(self):
        value = [{'title': 'Inbox', 'tags': ['home']}]
        self.assertEqual(normalize_entries(value), value)

    def test_empty_batch(self):
        self.assertEqual(read_entries('[]'), [])

    def test_normalization_preserves_entry_order_and_duplicates(self):
        value = [
            {'title': '  中文\t', 'tags': [' z ', '', 'a', ' a ', 'a', ' A ', 'ä', '\t'],
             'extra': 'ignored'},
            {'title': '\nInbox  '},
            {'title': ' 中文 ', 'tags': ['second']},
            {'title': ' Two  words ', 'tags': ['', '\t', '\u3000']},
        ]
        self.assertEqual(normalize_entries(value), [
            {'title': '中文', 'tags': ['A', 'a', 'z', 'ä']},
            {'title': 'Inbox', 'tags': []},
            {'title': '中文', 'tags': ['second']},
            {'title': 'Two  words', 'tags': []},
        ])

    def test_input_is_unchanged_and_output_is_independent(self):
        value = [
            {'title': ' Inbox ', 'tags': [' b ', 'a', 'a'],
             'extra': {'nested': ['keep']}},
            {'title': ' Work '},
        ]
        original = copy.deepcopy(value)
        result = normalize_entries(value)
        self.assertEqual(value, original)
        result[0]['title'] = 'Changed'
        result[0]['tags'].append('new')
        result[1]['tags'].append('work')
        result.append({'title': 'Another', 'tags': []})
        self.assertEqual(value, original)

    def test_invalid_collections_raise_value_error(self):
        for value in (None, True, 1, 'notes', {}, (), iter([])):
            with self.subTest(value=value):
                with self.assertRaises(ValueError):
                    normalize_entries(value)

    def test_invalid_entries_raise_value_error(self):
        for value in (None, True, 1, 'note', [], ()):
            with self.subTest(value=value):
                with self.assertRaises(ValueError):
                    normalize_entries([value])

    def test_invalid_titles_raise_value_error(self):
        for value in (None, True, 1, [], {}, '', ' \t\n\u3000'):
            with self.subTest(value=value):
                with self.assertRaises(ValueError):
                    normalize_entries([{'title': value}])
        with self.assertRaises(ValueError):
            normalize_entries([{}])

    def test_invalid_tags_raise_value_error(self):
        for value in (None, True, 1, 'tag', {}, (), ['ok', None],
                      ['ok', True], ['ok', 1], ['ok', []], ['ok', {}]):
            with self.subTest(value=value):
                with self.assertRaises(ValueError):
                    normalize_entries([{'title': 'Inbox', 'tags': value}])

    def test_late_validation_error_does_not_mutate_input(self):
        value = [
            {'title': ' Inbox ', 'tags': [' b ', 'a', 'a']},
            {'title': 'Work', 'tags': ['ok', None]},
        ]
        original = copy.deepcopy(value)
        with self.assertRaises(ValueError):
            normalize_entries(value)
        self.assertEqual(value, original)

    def test_read_entries_applies_normalization(self):
        self.assertEqual(read_entries(
            '[{"title": " 中文 ", "tags": [" b ", "a", "a", " "], "extra": 1},'
            ' {"title": " Inbox "}]'
        ), [
            {'title': '中文', 'tags': ['a', 'b']},
            {'title': 'Inbox', 'tags': []},
        ])

    def test_read_entries_rejects_invalid_json(self):
        for text in ('', '[', '[{"title": "Inbox",}]', '[] trailing'):
            with self.subTest(text=text):
                with self.assertRaises(ValueError):
                    read_entries(text)

    def test_read_entries_rejects_invalid_data(self):
        for value in (None, True, 1, 'notes', {}, [None], [{}],
                      [{'title': ' '}], [{'title': 'Inbox', 'tags': None}],
                      [{'title': 'Inbox'}, {'title': 'Work', 'tags': [1]}]):
            with self.subTest(value=value):
                with self.assertRaises(ValueError):
                    read_entries(json.dumps(value))

    def test_json_output(self):
        value = [{'title': '中文', 'tags': []}]
        rendered = render_json(value)
        self.assertEqual(json.loads(rendered), value)
        self.assertTrue(rendered.endswith('\n'))
        self.assertIn('中文', rendered)

    def test_file_cli_preserves_json_array_output(self):
        project_dir = Path(__file__).resolve().parent
        value = [
            {'title': ' 中文 ', 'tags': [' b ', 'a', 'a'], 'extra': 1},
            {'title': '中文', 'tags': ['later']},
        ]
        expected = [
            {'title': '中文', 'tags': ['a', 'b']},
            {'title': '中文', 'tags': ['later']},
        ]
        with tempfile.TemporaryDirectory(dir=project_dir) as directory:
            input_path = Path(directory) / 'notes.json'
            input_path.write_text(json.dumps(value), encoding='utf-8')
            result = subprocess.run(
                [sys.executable, '-m', 'notebatch', str(input_path)],
                cwd=project_dir, capture_output=True, text=True, encoding='utf-8',
            )
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(result.stderr, '')
        self.assertEqual(json.loads(result.stdout), expected)
        self.assertEqual(result.stdout, render_json(expected))


class NoteBatchCliTests(unittest.TestCase):
    project_dir = Path(__file__).resolve().parent

    def run_cli(self, *args, input_text=None):
        return subprocess.run(
            [sys.executable, '-m', 'notebatch', *args],
            cwd=self.project_dir, capture_output=True,
            input=None if input_text is None else input_text.encode('utf-8'),
            timeout=10,
        )

    def run_batch(self, text, source, *options):
        if source == 'stdin':
            return self.run_cli('-', *options, input_text=text)
        with tempfile.TemporaryDirectory(dir=self.project_dir) as directory:
            input_path = Path(directory) / 'notes.json'
            input_path.write_text(text, encoding='utf-8')
            return self.run_cli(str(input_path), *options)

    def assert_input_error(self, result, reason):
        self.assertEqual(result.returncode, 2, result.stderr)
        self.assertEqual(result.stdout, b'')
        error = result.stderr.decode('utf-8')
        self.assertTrue(error.startswith('input error:'), error)
        self.assertIn(reason, error)
        self.assertNotIn('Traceback', error)

    def test_input_format_and_unique_combinations(self):
        value = [
            {'title': ' Straße ', 'tags': [' z ', 'a', ' a ', ''], 'extra': 1},
            {'title': ' 中文 ', 'tags': [' 标签 ']},
            {'title': ' STRASSE ', 'tags': ['discarded']},
            {'title': ' Inbox '},
            {'title': '中文', 'tags': ['later']},
            {'title': 'inbox', 'tags': ['also discarded']},
        ]
        all_entries = [
            {'title': 'Straße', 'tags': ['a', 'z']},
            {'title': '中文', 'tags': ['标签']},
            {'title': 'STRASSE', 'tags': ['discarded']},
            {'title': 'Inbox', 'tags': []},
            {'title': '中文', 'tags': ['later']},
            {'title': 'inbox', 'tags': ['also discarded']},
        ]
        jsonl_lines = [
            '{"title":"Straße","tags":["a","z"]}\n',
            '{"title":"中文","tags":["标签"]}\n',
            '{"title":"STRASSE","tags":["discarded"]}\n',
            '{"title":"Inbox","tags":[]}\n',
            '{"title":"中文","tags":["later"]}\n',
            '{"title":"inbox","tags":["also discarded"]}\n',
        ]
        for source in ('file', 'stdin'):
            for output_format in (None, 'json', 'jsonl'):
                for unique in (False, True):
                    with self.subTest(source=source, format=output_format, unique=unique):
                        options = [] if output_format is None else ['--format', output_format]
                        if unique:
                            options.append('--unique')
                        indices = (0, 1, 3) if unique else range(len(all_entries))
                        expected = [all_entries[index] for index in indices]
                        if output_format == 'jsonl':
                            expected_text = ''.join(jsonl_lines[index] for index in indices)
                        else:
                            expected_text = render_json(expected)
                        result = self.run_batch(
                            json.dumps(value, ensure_ascii=False), source, *options,
                        )
                        self.assertEqual(result.returncode, 0, result.stderr)
                        self.assertEqual(result.stderr, b'')
                        self.assertEqual(result.stdout, expected_text.encode('utf-8'))

    def test_empty_batches(self):
        for source in ('file', 'stdin'):
            for output_format in ('json', 'jsonl'):
                for unique in (False, True):
                    with self.subTest(source=source, format=output_format, unique=unique):
                        options = ['--format', output_format]
                        if unique:
                            options.append('--unique')
                        result = self.run_batch('[]', source, *options)
                        self.assertEqual(result.returncode, 0, result.stderr)
                        self.assertEqual(result.stderr, b'')
                        self.assertEqual(result.stdout, b'' if output_format == 'jsonl' else b'[]\n')

    def test_invalid_json_reports_input_error(self):
        cases = [
            ('', 'Expecting'),
            ('[', 'Expecting'),
            ('[{"title":"Inbox"}] trailing', 'Extra data'),
        ]
        for text, reason in cases:
            for source in ('file', 'stdin'):
                with self.subTest(text=text, source=source):
                    self.assert_input_error(self.run_batch(text, source), reason)

    def test_jsonl_output_still_requires_json_array_input(self):
        text = '{"title":"One"}\n{"title":"Two"}\n'
        for source in ('file', 'stdin'):
            with self.subTest(source=source):
                self.assert_input_error(
                    self.run_batch(text, source, '--format', 'jsonl'), 'Extra data',
                )

    def test_invalid_data_never_emits_partial_output_or_hides_duplicates(self):
        cases = [
            ('{}', 'entries must be a list'),
            ('[null]', 'entries[0]'),
            ('[{"title":"First"},{"title":" "}]', 'entries[1].title'),
            ('[{"title":"First"},{"title":"Other","tags":null}]', 'entries[1].tags'),
            ('[{"title":"Straße"},{"title":"Other"},'
             '{"title":" STRASSE ","tags":["valid",1]}]', 'entries[2].tags[1]'),
        ]
        for text, reason in cases:
            for source in ('file', 'stdin'):
                for output_format in ('json', 'jsonl'):
                    for unique in (False, True):
                        with self.subTest(text=text, source=source, format=output_format, unique=unique):
                            options = ['--format', output_format]
                            if unique:
                                options.append('--unique')
                            self.assert_input_error(
                                self.run_batch(text, source, *options), reason,
                            )

    def test_unreadable_file_reports_input_error(self):
        with tempfile.TemporaryDirectory(dir=self.project_dir) as directory:
            for input_path in (Path(directory) / 'missing.json', Path(directory)):
                with self.subTest(path=input_path):
                    self.assert_input_error(self.run_cli(str(input_path)), str(input_path))

    def test_invalid_utf8_file_reports_input_error(self):
        with tempfile.TemporaryDirectory(dir=self.project_dir) as directory:
            input_path = Path(directory) / 'invalid.json'
            input_path.write_bytes(b'\xff')
            self.assert_input_error(self.run_cli(str(input_path)), 'decode')

    def test_argument_errors_keep_argparse_behavior(self):
        for args, reason in (((), b'input'), (('-', '--format', 'xml'), b'invalid choice')):
            with self.subTest(args=args):
                result = self.run_cli(*args, input_text='[]')
                self.assertEqual(result.returncode, 2)
                self.assertEqual(result.stdout, b'')
                self.assertTrue(result.stderr.startswith(b'usage:'), result.stderr)
                self.assertIn(reason, result.stderr)
                self.assertNotIn(b'input error:', result.stderr)
                self.assertNotIn(b'Traceback', result.stderr)


if __name__ == '__main__':
    unittest.main()
