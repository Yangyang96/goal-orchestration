"""Command-line export of a note batch."""
import argparse
import json
from pathlib import Path
import sys
from . import read_entries, render_json


def main():
    parser = argparse.ArgumentParser(description='Export a note batch')
    parser.add_argument('input', help='JSON array file, or - to read from stdin')
    parser.add_argument(
        '--format', choices=('json', 'jsonl'), default='json',
        help='output format (default: json)',
    )
    parser.add_argument(
        '--unique', action='store_true',
        help='keep the first entry for each normalized, casefolded title',
    )
    args = parser.parse_args()

    try:
        if args.input == '-':
            text = sys.stdin.read()
        else:
            text = Path(args.input).read_text(encoding='utf-8')
        entries = read_entries(text)
    except (OSError, ValueError) as error:
        print(f'input error: {error}', file=sys.stderr)
        return 2

    if args.unique:
        seen_titles = set()
        unique_entries = []
        for entry in entries:
            key = entry['title'].casefold()
            if key not in seen_titles:
                seen_titles.add(key)
                unique_entries.append(entry)
        entries = unique_entries

    if args.format == 'jsonl':
        output = ''.join(
            json.dumps(entry, ensure_ascii=False, separators=(',', ':')) + '\n'
            for entry in entries
        )
    else:
        output = render_json(entries)
    sys.stdout.write(output)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
