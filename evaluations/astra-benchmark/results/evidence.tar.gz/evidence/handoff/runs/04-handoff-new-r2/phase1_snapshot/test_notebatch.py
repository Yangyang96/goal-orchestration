import copy
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from notebatch import normalize_entries, read_entries, render_json


class NoteBatchTests(unittest.TestCase):
    def test_existing_normalized_entry(self):
        value = [{'title': 'Inbox', 'tags': ['home']}]
        self.assertEqual(normalize_entries(value), value)

    def test_empty_batch(self):
        self.assertEqual(read_entries('[]'), [])

    def test_normalization_preserves_entry_order_and_duplicates(self):
        value = [
            {'title': '  中文\t', 'tags': [' z ', '', 'a', ' a ', 'a', ' A ', 'ä', '\t'],
             'extra': 'ignored'},
            {'title': '\nInbox  '},
            {'title': ' 中文 ', 'tags': ['second']},
            {'title': ' Two  words ', 'tags': ['', '\t', '\u3000']},
        ]
        self.assertEqual(normalize_entries(value), [
            {'title': '中文', 'tags': ['A', 'a', 'z', 'ä']},
            {'title': 'Inbox', 'tags': []},
            {'title': '中文', 'tags': ['second']},
            {'title': 'Two  words', 'tags': []},
        ])

    def test_input_is_unchanged_and_output_is_independent(self):
        value = [
            {'title': ' Inbox ', 'tags': [' b ', 'a', 'a'],
             'extra': {'nested': ['keep']}},
            {'title': ' Work '},
        ]
        original = copy.deepcopy(value)
        result = normalize_entries(value)
        self.assertEqual(value, original)
        result[0]['title'] = 'Changed'
        result[0]['tags'].append('new')
        result[1]['tags'].append('work')
        result.append({'title': 'Another', 'tags': []})
        self.assertEqual(value, original)

    def test_invalid_collections_raise_value_error(self):
        for value in (None, True, 1, 'notes', {}, (), iter([])):
            with self.subTest(value=value):
                with self.assertRaises(ValueError):
                    normalize_entries(value)

    def test_invalid_entries_raise_value_error(self):
        for value in (None, True, 1, 'note', [], ()):
            with self.subTest(value=value):
                with self.assertRaises(ValueError):
                    normalize_entries([value])

    def test_invalid_titles_raise_value_error(self):
        for value in (None, True, 1, [], {}, '', ' \t\n\u3000'):
            with self.subTest(value=value):
                with self.assertRaises(ValueError):
                    normalize_entries([{'title': value}])
        with self.assertRaises(ValueError):
            normalize_entries([{}])

    def test_invalid_tags_raise_value_error(self):
        for value in (None, True, 1, 'tag', {}, (), ['ok', None],
                      ['ok', True], ['ok', 1], ['ok', []], ['ok', {}]):
            with self.subTest(value=value):
                with self.assertRaises(ValueError):
                    normalize_entries([{'title': 'Inbox', 'tags': value}])

    def test_late_validation_error_does_not_mutate_input(self):
        value = [
            {'title': ' Inbox ', 'tags': [' b ', 'a', 'a']},
            {'title': 'Work', 'tags': ['ok', None]},
        ]
        original = copy.deepcopy(value)
        with self.assertRaises(ValueError):
            normalize_entries(value)
        self.assertEqual(value, original)

    def test_read_entries_applies_normalization(self):
        self.assertEqual(read_entries(
            '[{"title": " 中文 ", "tags": [" b ", "a", "a", " "], "extra": 1},'
            ' {"title": " Inbox "}]'
        ), [
            {'title': '中文', 'tags': ['a', 'b']},
            {'title': 'Inbox', 'tags': []},
        ])

    def test_read_entries_rejects_invalid_json(self):
        for text in ('', '[', '[{"title": "Inbox",}]', '[] trailing'):
            with self.subTest(text=text):
                with self.assertRaises(ValueError):
                    read_entries(text)

    def test_read_entries_rejects_invalid_data(self):
        for value in (None, True, 1, 'notes', {}, [None], [{}],
                      [{'title': ' '}], [{'title': 'Inbox', 'tags': None}],
                      [{'title': 'Inbox'}, {'title': 'Work', 'tags': [1]}]):
            with self.subTest(value=value):
                with self.assertRaises(ValueError):
                    read_entries(json.dumps(value))

    def test_json_output(self):
        value = [{'title': '中文', 'tags': []}]
        rendered = render_json(value)
        self.assertEqual(json.loads(rendered), value)
        self.assertTrue(rendered.endswith('\n'))
        self.assertIn('中文', rendered)

    def test_file_cli_preserves_json_array_output(self):
        project_dir = Path(__file__).resolve().parent
        value = [
            {'title': ' 中文 ', 'tags': [' b ', 'a', 'a'], 'extra': 1},
            {'title': '中文', 'tags': ['later']},
        ]
        expected = [
            {'title': '中文', 'tags': ['a', 'b']},
            {'title': '中文', 'tags': ['later']},
        ]
        with tempfile.TemporaryDirectory(dir=project_dir) as directory:
            input_path = Path(directory) / 'notes.json'
            input_path.write_text(json.dumps(value), encoding='utf-8')
            result = subprocess.run(
                [sys.executable, '-m', 'notebatch', str(input_path)],
                cwd=project_dir, capture_output=True, text=True, encoding='utf-8',
            )
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(result.stderr, '')
        self.assertEqual(json.loads(result.stdout), expected)
        self.assertEqual(result.stdout, render_json(expected))


if __name__ == '__main__':
    unittest.main()
