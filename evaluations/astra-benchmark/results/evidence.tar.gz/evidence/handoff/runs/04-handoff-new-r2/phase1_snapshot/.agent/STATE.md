# NoteBatch 两阶段交接

## 目标与边界

- 用户将工作分成两天：2026-09-07 的阶段 1 只修复归一化与校验、补测试并留下交接；阶段 2 由明天的新任务读取同一工作树后完成。今天不得实现阶段 2。
- 两个阶段都不要 Git commit。阶段 2 已明确要求实现、补测试与使用文档、运行相关检查并直接完成，无需再次确认同一范围。
- 只在当前工作目录内修改。不得读取其他目录的项目、测试判卷器、其他候选结果或全局 Skill；不得委派子 Agent 或调用外部应用。可使用本地 shell、文件工具和 Git，遵守运行时权限。
- 本次使用用户提供的 `goal-orchestration`；无需为接续引入依赖、worktree 或额外流程。保护工作树中已完成的阶段 1 和任何后续用户改动。

## 阶段 1：已完成

- `notebatch/__init__.py`：`normalize_entries(entries)` 只接受 list，每项为 dict；title 必须是 str，去除首尾空白后非空，保留内部空白与大小写。
- tags 缺省为新的空列表；显式提供时必须是字符串列表（包括拒绝 null）。各标签 strip 后丢弃空串，按精确字符串去重、按 Python 字符串顺序排序，区分大小写。
- 输出只包含 title、tags，忽略未知字段，保留条目顺序与重复条目；新建输出对象和标签列表，成功或失败均不修改输入。
- 非法集合、条目、标题、标签均抛出 `ValueError`，错误信息包含具体字段/索引。`read_entries(text)` 沿用 `json.loads` 再归一化；非法 JSON 的 `JSONDecodeError` 是 `ValueError` 子类。
- 保留公共 API：`normalize_entries(entries)`、`read_entries(text)`、`render_json(entries)`。`render_json` 仍输出保留 Unicode 的缩进 JSON 数组并带末尾换行。
- `notebatch/__main__.py` 未修改，仍仅支持文件输入和 JSON 数组输出。stdin、格式选项、去重及友好 CLI 错误处理均待阶段 2。
- `test_notebatch.py` 扩充至 14 个测试方法，含类型校验子用例、Unicode/空白/大小写/排序去重、默认标签、未知字段、条目顺序与重复、输入不变性、输出独立性、后部错误、JSON 解析及文件 CLI 子进程回归。

## 阶段 2：待完成，消费端接口不可改名或替换

1. 位置参数名称仍为 `input`。文件路径之外，单独的 `-` 表示读取 stdin。两者输入均为同一种 JSON 数组，均调用阶段 1 归一化；即使输出 jsonl，输入也不是 JSONL。
2. 增加 `--format json|jsonl`，默认 `json`，保留现有 JSON 数组输出。`jsonl` 每个归一化对象占一行紧凑 JSON，逗号和冒号后不加空格，保留 Unicode 原字符。非空批次最后一行也必须有换行；空批次 stdout 必须是零字节，不能是 `[]` 或空行。
3. 增加 `--unique`，默认不开启、保留所有条目。开启时按清洗后的 `title.casefold()` 判断重复，保留第一次出现的完整归一化对象及原始顺序；不得合并后续重复对象的 tags，不得改变保留标题的大小写。两种输出格式均适用。不要把去重变成公共归一化 API 的默认行为。
4. 非法 JSON、归一化失败、输入文件打不开时，CLI 退出状态码必须为 2；stdout 必须为空；stderr 必须以 `input error:` 开头并说明原因；不得输出 traceback。即使错误条目靠后也不得输出此前的部分结果。参数使用错误保持 argparse 常规行为。
5. 补充阶段 2 的测试与 README 使用文档，运行相关检查并完成交付，不提交 Git commit。

## 接续步骤与验收

1. 阅读本文件、README、当前实现与测试，检查 `git status --short` 和 `git diff`，保留阶段 1 改动。记录是恢复依据，若新用户指令或实际文件状态不同，以新指令及当前文件为准。
2. 修改 CLI，复用 `read_entries` 与默认 `render_json`。先读取并归一化完整批次，之后按需去重、渲染，最后写 stdout；确保靠后的错误（包括重复标题对象上的无效 tags）不会被去重掩盖或产生部分输出。
3. 用子进程覆盖文件/stdin × json/jsonl × unique 开关，默认兼容性，空批次，Unicode，紧凑格式与末尾换行，以及不依赖相邻位置的重复标题。用如 `Straße`/`STRASSE` 检查 casefold 而非 lower，检查第一次出现的大小写和 tags 保留且顺序不变。
4. 覆盖非法 JSON、非法归一化数据（特别是后部错误）、打不开的文件；验证状态码 2、空 stdout、stderr 前缀与原因、无 traceback。检查 argparse 对非法格式和缺少参数的常规行为。临时测试输入放在当前工作目录内并自动清理。
5. README 写明参数、默认行为、stdin 与 JSONL 示例、unique 规则及错误约定。运行 `python3 -m unittest -v` 与 `git diff --check`，检查最终差异仅在授权范围，更新此记录并直接交付。

## 验证证据与剩余状态

- 原始基线：`python3 -m unittest -v`，3 个测试通过；新增回归测试在旧实现上暴露缺失归一化、错误异常类型等问题。
- 阶段 1：`python3 -m unittest -v`，14 个测试通过，覆盖 `notebatch/__init__.py`、原有 `notebatch/__main__.py` 和 `test_notebatch.py`。
- `git diff --check` 通过；最终差异已检查，仅修改归一化模块、测试、README 交接入口并新增本记录，CLI 入口没有改动，未做 Git commit。
- 相关代码或测试输入若变化，运行受影响检查；未变化的检查结果可复用。
- 阶段 1 无阻塞；阶段 2 尚未实现和验证，须由下一任务按上述接口完成。本文件不调度或自动启动明天的任务。
