import copy
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from notebatch import normalize_entries, read_entries, render_json


class NoteBatchTests(unittest.TestCase):
    def test_existing_normalized_entry(self):
        value = [{'title': 'Inbox', 'tags': ['home']}]
        self.assertEqual(normalize_entries(value), value)

    def test_empty_batch(self):
        self.assertEqual(read_entries('[]'), [])

    def test_normalization(self):
        value = [
            {
                'title': ' \t中文 笔记\n',
                'tags': [' z ', '', 'a', 'A', 'a ', ' \t', '中文', 'Z'],
                'ignored': {'source': 'inbox'},
            },
            {'title': '\n Inbox  item \t'},
            {'title': '中文 笔记', 'tags': []},
        ]
        expected = [
            {'title': '中文 笔记', 'tags': ['A', 'Z', 'a', 'z', '中文']},
            {'title': 'Inbox  item', 'tags': []},
            {'title': '中文 笔记', 'tags': []},
        ]
        self.assertEqual(normalize_entries(value), expected)
        self.assertEqual(read_entries(json.dumps(value)), expected)

    def test_input_is_unchanged_and_output_is_independent(self):
        value = [
            {'title': ' Inbox ', 'tags': [' b ', 'a', 'a'], 'extra': [1]},
            {'title': 'Another'},
        ]
        original = copy.deepcopy(value)
        normalized = normalize_entries(value)
        self.assertEqual(value, original)
        normalized[0]['title'] = 'Changed'
        normalized[0]['tags'].append('new')
        normalized.append({'title': 'Added', 'tags': []})
        self.assertEqual(value, original)

    def test_default_tags_are_independent(self):
        normalized = normalize_entries([{'title': 'One'}, {'title': 'Two'}])
        normalized[0]['tags'].append('new')
        self.assertEqual(normalized[1]['tags'], [])

    def test_invalid_collections_raise_value_error(self):
        for value in (None, True, 42, 'notes', {}, (), set(), iter([])):
            with self.subTest(value=value):
                with self.assertRaises(ValueError):
                    normalize_entries(value)

    def test_invalid_entries_raise_value_error(self):
        for entry in (None, True, 42, 'note', [], ()):
            with self.subTest(entry=entry):
                with self.assertRaises(ValueError):
                    normalize_entries([entry])

    def test_invalid_titles_raise_value_error(self):
        entries = [{}] + [
            {'title': title}
            for title in (None, True, 42, [], {}, '', ' \t\n')
        ]
        for entry in entries:
            with self.subTest(entry=entry):
                with self.assertRaises(ValueError):
                    normalize_entries([entry])

    def test_invalid_tags_raise_value_error(self):
        invalid_tags = (None, True, 42, 'tag', {}, ('tag',), {'tag'})
        invalid_members = (None, True, 42, [], {})
        for tags in (*invalid_tags, *(['valid', tag] for tag in invalid_members)):
            with self.subTest(tags=tags):
                with self.assertRaises(ValueError):
                    normalize_entries([{'title': 'Inbox', 'tags': tags}])

    def test_failed_normalization_does_not_mutate_input(self):
        value = [
            {'title': ' Inbox ', 'tags': [' b ', 'a', 'a']},
            {'title': 'Invalid', 'tags': ['valid', None]},
        ]
        original = copy.deepcopy(value)
        with self.assertRaises(ValueError):
            normalize_entries(value)
        self.assertEqual(value, original)

    def test_read_entries_rejects_invalid_json_and_data(self):
        for text in (
            '', '[', '[{"title": "Inbox"},]', 'null', '{}', '"notes"', '42',
            '[null]', '[{}]', '[{"title": " "}]',
            '[{"title": "Inbox", "tags": "home"}]',
            '[{"title": "Inbox"}, {"title": "Invalid", "tags": [null]}]',
        ):
            with self.subTest(text=text):
                with self.assertRaises(ValueError):
                    read_entries(text)

    def test_file_cli_preserves_json_array_output(self):
        project_root = Path(__file__).resolve().parent
        with tempfile.TemporaryDirectory(dir=project_root) as directory:
            path = Path(directory) / 'notes.json'
            path.write_text(json.dumps([
                {'title': ' 中文 ', 'tags': [' z ', 'a', 'a']},
                {'title': '中文'},
            ]), encoding='utf-8')
            result = subprocess.run(
                [sys.executable, '-m', 'notebatch', str(path)],
                cwd=project_root, capture_output=True, text=True, check=False,
            )
        expected = [
            {'title': '中文', 'tags': ['a', 'z']},
            {'title': '中文', 'tags': []},
        ]
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(result.stderr, '')
        self.assertEqual(
            result.stdout, json.dumps(expected, ensure_ascii=False, indent=2) + '\n'
        )

    def test_json_output(self):
        value = [{'title': '中文', 'tags': []}]
        rendered = render_json(value)
        self.assertEqual(json.loads(rendered), value)
        self.assertTrue(rendered.endswith('\n'))
        self.assertIn('中文', rendered)


class NoteBatchCLITests(unittest.TestCase):
    def setUp(self):
        self.project_root = Path(__file__).resolve().parent
        directory = tempfile.TemporaryDirectory(dir=self.project_root)
        self.addCleanup(directory.cleanup)
        self.input_path = Path(directory.name) / 'notes.json'

    def run_cli(self, *args, input_bytes=b''):
        return subprocess.run(
            [sys.executable, '-m', 'notebatch', *args],
            input=input_bytes, cwd=self.project_root, capture_output=True,
            check=False,
        )

    def run_input(self, source, text, *args):
        payload = text.encode('utf-8')
        if source == 'stdin':
            return self.run_cli('-', *args, input_bytes=payload)
        self.input_path.write_bytes(payload)
        return self.run_cli(str(self.input_path), *args)

    def assert_output(self, result, expected):
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(result.stderr, b'')
        self.assertEqual(result.stdout, expected.encode('utf-8'))

    def assert_input_error(self, result, reason):
        self.assertEqual(result.returncode, 2, result.stderr)
        self.assertEqual(result.stdout, b'')
        self.assertTrue(result.stderr.startswith(b'input error:'), result.stderr)
        self.assertIn(reason.encode('utf-8'), result.stderr)
        self.assertNotIn(b'Traceback', result.stderr)

    def test_json_array_output_for_file_and_stdin(self):
        payload = '[{"title":" 中文 ","tags":[" z ","a","a"]},{"title":"中文"}]'
        expected = json.dumps([
            {'title': '中文', 'tags': ['a', 'z']},
            {'title': '中文', 'tags': []},
        ], ensure_ascii=False, indent=2) + '\n'
        for source in ('file', 'stdin'):
            for args in ((), ('--format', 'json')):
                with self.subTest(source=source, args=args):
                    self.assert_output(self.run_input(source, payload, *args), expected)

    def test_jsonl_output_for_file_and_stdin(self):
        payload = json.dumps([
            {'title': ' 中文 ', 'tags': [' z ', 'a', '', 'a', ' 标签 ']},
            {'title': 'Line\nbreak "quoted"', 'ignored': True},
            {'title': '中文'},
        ], ensure_ascii=False)
        expected = (
            '{"title":"中文","tags":["a","z","标签"]}\n'
            '{"title":"Line\\nbreak \\"quoted\\"","tags":[]}\n'
            '{"title":"中文","tags":[]}\n'
        )
        for source in ('file', 'stdin'):
            with self.subTest(source=source):
                result = self.run_input(source, payload, '--format', 'jsonl')
                self.assert_output(result, expected)

    def test_empty_output_for_all_modes(self):
        for source in ('file', 'stdin'):
            for format_args in ((), ('--format', 'json'), ('--format', 'jsonl')):
                for unique_args in ((), ('--unique',)):
                    with self.subTest(source=source, format=format_args, unique=unique_args):
                        result = self.run_input(source, '[]', *format_args, *unique_args)
                        expected = '' if 'jsonl' in format_args else '[]\n'
                        self.assert_output(result, expected)

    def test_unique_preserves_first_object_and_order(self):
        payload = json.dumps([
            {'title': ' Straße ', 'tags': [' z ', 'a']},
            {'title': 'Other', 'tags': ['first']},
            {'title': 'STRASSE', 'tags': ['later']},
            {'title': ' other ', 'tags': ['discarded']},
            {'title': '最後'},
        ], ensure_ascii=False)
        all_entries = [
            {'title': 'Straße', 'tags': ['a', 'z']},
            {'title': 'Other', 'tags': ['first']},
            {'title': 'STRASSE', 'tags': ['later']},
            {'title': 'other', 'tags': ['discarded']},
            {'title': '最後', 'tags': []},
        ]
        for source in ('file', 'stdin'):
            for output_format in ('json', 'jsonl'):
                for unique_args in ((), ('--unique',)):
                    with self.subTest(source=source, format=output_format, unique=unique_args):
                        result = self.run_input(
                            source, payload, '--format', output_format, *unique_args,
                        )
                        self.assertEqual(result.returncode, 0, result.stderr)
                        self.assertEqual(result.stderr, b'')
                        if output_format == 'json':
                            actual = json.loads(result.stdout)
                        else:
                            actual = [json.loads(line) for line in result.stdout.splitlines()]
                        expected = (
                            [all_entries[0], all_entries[1], all_entries[4]]
                            if unique_args else all_entries
                        )
                        self.assertEqual(actual, expected)
                        self.assertTrue(result.stdout.endswith(b'\n'))

    def test_input_errors_are_atomic(self):
        cases = (
            ('[{"title":"First"},', 'Expecting value'),
            ('{}', 'entries must be a list'),
            ('[{"title":"First"},null]', 'entry 1 must be an object'),
            ('[{"title":"First"},{"title":" "}]', 'entry 1 title'),
            ('[{"title":"First"},{"title":"Last","tags":"bad"}]', 'entry 1 tags'),
            ('[{"title":"First"},{"title":"Last","tags":[null]}]', 'entry 1 tag 0'),
            ('[{"title":" Straße "},{"title":"STRASSE","tags":[null]}]', 'entry 1 tag 0'),
        )
        for source in ('file', 'stdin'):
            for output_format in ('json', 'jsonl'):
                for unique_args in ((), ('--unique',)):
                    for payload, reason in cases:
                        with self.subTest(
                            source=source, format=output_format, unique=unique_args,
                            payload=payload,
                        ):
                            result = self.run_input(
                                source, payload, '--format', output_format, *unique_args,
                            )
                            self.assert_input_error(result, reason)

    def test_unreadable_files(self):
        for path in (self.input_path, self.input_path.parent):
            for output_format in ('json', 'jsonl'):
                with self.subTest(path=path, format=output_format):
                    result = self.run_cli(str(path), '--format', output_format)
                    self.assert_input_error(result, str(path))
                    self.assertIn(b'[Errno ', result.stderr)

    def test_invalid_utf8_file(self):
        self.input_path.write_bytes(b'\xff')
        for output_format in ('json', 'jsonl'):
            with self.subTest(format=output_format):
                result = self.run_cli(str(self.input_path), '--format', output_format)
                self.assert_input_error(result, 'decode')

    def test_argument_errors_keep_argparse_behavior(self):
        cases = (
            ((), 'required: input'),
            (('--format', 'jsonl'), 'required: input'),
            (('-', '--format', 'csv'), 'invalid choice'),
            (('-', '--unknown'), 'unrecognized arguments'),
        )
        for args, reason in cases:
            with self.subTest(args=args):
                result = self.run_cli(*args)
                self.assertEqual(result.returncode, 2, result.stderr)
                self.assertEqual(result.stdout, b'')
                self.assertTrue(result.stderr.startswith(b'usage:'), result.stderr)
                self.assertIn(reason.encode('utf-8'), result.stderr)
                self.assertNotIn(b'input error:', result.stderr)
                self.assertNotIn(b'Traceback', result.stderr)


if __name__ == '__main__':
    unittest.main()
