# NoteBatch 两阶段接续说明

## 目标、授权与当前状态

用户分两天把 NoteBatch 接入导出流程。阶段 1 和阶段 2 均已完成，
阶段 2 按已确定的范围和接口完成实现、测试与使用文档，没有剩余待实现项。
两个阶段的修改均保留在当前工作树，没有 Git commit。

只在当前工作目录内工作，保护无关改动。不要读取目录外的项目、测试判卷器、
其他候选结果或全局 Skill；只允许当前提供的 Skill（本工作树没有 Skill）。
不要委派子 Agent 或调用外部应用；可使用本地 shell、文件工具和 Git，遵守权限限制。

## 阶段 1：已完成

- `notebatch/__init__.py` 的 `normalize_entries(entries)` 按 README 校验和归一化：
  输入必须是 list，每项必须是 dict；title 必须是去除首尾空白后非空的字符串。
  tags 缺省为独立的空列表；若显式提供，必须为字符串列表。每个标签去除首尾空白、
  丢弃空标签、按精确字符串去重并按 Python 字符串顺序排序，大小写敏感。
  输出每项只含 title 和 tags，忽略其他字段，保留条目顺序和重复条目。
  返回新的列表、对象和标签列表，成功及失败时都不修改调用方输入。
- 无效集合、条目、标题或标签抛出 `ValueError`，消息说明位置/字段和原因。
  `read_entries(text)` 仍通过 `json.loads` 后调用归一化；非法 JSON 的
  `json.JSONDecodeError` 是 `ValueError` 子类，无需更改公共异常约定。
- 保留公共 API：`normalize_entries(entries)`、`read_entries(text)`、
  `render_json(entries)`。`render_json` 保留 Unicode 原字符、缩进 2 空格，末尾一个换行。
- 阶段 1 结束时 `notebatch/__main__.py` 未修改，CLI 只接受文件路径并输出归一化后的
  JSON 数组；stdin、格式选择、按标题去重和输入错误处理已在阶段 2 完成。
- 阶段 1 的 13 个测试保留，覆盖清洗、排序和大小写敏感去重、默认标签、
  未知字段、顺序和重复条目保留、输入不变性和输出独立性、各类无效值、JSON 解析、
  文件 CLI 的数组输出。测试临时文件建立在本工作树内。

阶段 1 验证：`python3 -m unittest -v` 已通过当时全部 13 个测试。新增测试在修复前确实失败，
修复后通过。当前实现和接续文档均保留在工作树中，没有 Git commit。

## 阶段 2：已完成，保留约定接口

1. 位置参数继续叫 `input`。除文件路径外，接受单独的 `-`，表示从 stdin 读取。
   文件和 stdin 都输入同一种 JSON 数组，统一使用阶段 1 的归一化规则。
2. 增加 `--format json|jsonl`，默认 `json`，保持现有 JSON 数组输出。
   `jsonl` 为每个归一化对象输出一行紧凑 JSON，逗号和冒号后不加空格，
   保留 Unicode 原字符。非空批次最后一行也有换行；空批次必须输出零字节，
   不能输出 `[]` 或空行。
3. 增加 `--unique`，默认关闭，关闭时保留全部条目。
   开启后按清洗后的 `title.casefold()` 判断重复，保留第一次出现的完整对象和
   原始顺序；不合并后续对象的 tags，不改变保留标题的大小写。
   对 `json` 和 `jsonl` 两种输出格式都生效。
4. 非法 JSON、归一化失败或输入文件打不开时，CLI 退出码必须为 `2`，
   stdout 必须为空，stderr 必须以 `input error:` 开头并说明原因，不输出 traceback。
   即使错误条目位于批次后面，也不能输出前面的部分结果。
   参数使用错误保持 argparse 的常规行为。
5. 已补充必要测试和 README 使用文档，运行相关检查，没有提交 Git。

## 阶段 2 实现与验收

`notebatch/__main__.py` 已接入 stdin、参数、错误处理和输出选择，复用已有公共 API，
保留阶段 1 行为。先完整读取并归一化全部输入，再按需去重并生成输出，最后写 stdout，
确保后面的错误不会产生部分结果。重复项也通过校验，不会因提前丢弃而漏报错误。
JSONL 使用 `json.dumps(entry, ensure_ascii=False, separators=(',', ':'))`。
标题去重仅在 CLI 指定 `--unique` 时执行，`normalize_entries` 保持原有行为。

已扩展现有标准库 unittest 和 subprocess 测试，没有引入依赖，覆盖：

- 文件与 `-` 两种输入；默认 json 与显式 `--format json` 保持数组输出。
- 文件和 stdin 的 jsonl 精确输出：标签已清洗、紧凑分隔符、Unicode 原字符、
  非空批次尾换行、空批次零字节（有无 `--unique` 都应符合）。
- 两种格式下 `--unique` 的清洗后匹配、Unicode casefold、稳定顺序和首项完整保留。
  例如 ` Straße ` 和 `STRASSE` 重复，应保留第一项标题 `Straße` 及其自身的 tags，
  不合并第二项 tags；默认无 `--unique` 时两项都保留。
- 非法 JSON、无效根类型、较后位置的非法条目或 tags、打不开的文件：
  退出码 2、stdout 零字节、stderr 前缀和原因、无 traceback。
  对 stdin 和文件以及两种格式覆盖归一化错误，特别验证开启 `--unique` 后
  较后的重复标题条目若有非法 tags，仍应报错且无部分输出。
- argparse 的缺失参数、无效 format 和未知选项保持常规错误行为。

README 已加入文件/stdin、json/jsonl、去重和错误行为的用法说明。
组合命令 `python3 -m notebatch - --format jsonl --unique` 已可使用。

阶段 2 验证（2026-09-07）：新增的 stdin 和格式选择测试在实现前因功能缺失而失败；
实现后 `python3 -m unittest -v` 通过全部 21 个测试（原有 13 个，新增 8 个，
通过 subTest 覆盖输入源、输出格式和去重开关组合）。另覆盖不可读文件、非法 UTF-8
文件和 argparse 参数错误。测试临时文件仍全部建立在当前工作树内并自动清理。
`git diff --check` 已通过。已检查最终 diff：本次仅修改 CLI、补充测试并更新
README 与本文，保留阶段 1 的归一化实现和原有测试，没有创建 Git commit。
