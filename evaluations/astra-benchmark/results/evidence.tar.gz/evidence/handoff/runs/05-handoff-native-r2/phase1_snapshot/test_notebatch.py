import copy
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from notebatch import normalize_entries, read_entries, render_json


class NoteBatchTests(unittest.TestCase):
    def test_existing_normalized_entry(self):
        value = [{'title': 'Inbox', 'tags': ['home']}]
        self.assertEqual(normalize_entries(value), value)

    def test_empty_batch(self):
        self.assertEqual(read_entries('[]'), [])

    def test_normalization(self):
        value = [
            {
                'title': ' \t中文 笔记\n',
                'tags': [' z ', '', 'a', 'A', 'a ', ' \t', '中文', 'Z'],
                'ignored': {'source': 'inbox'},
            },
            {'title': '\n Inbox  item \t'},
            {'title': '中文 笔记', 'tags': []},
        ]
        expected = [
            {'title': '中文 笔记', 'tags': ['A', 'Z', 'a', 'z', '中文']},
            {'title': 'Inbox  item', 'tags': []},
            {'title': '中文 笔记', 'tags': []},
        ]
        self.assertEqual(normalize_entries(value), expected)
        self.assertEqual(read_entries(json.dumps(value)), expected)

    def test_input_is_unchanged_and_output_is_independent(self):
        value = [
            {'title': ' Inbox ', 'tags': [' b ', 'a', 'a'], 'extra': [1]},
            {'title': 'Another'},
        ]
        original = copy.deepcopy(value)
        normalized = normalize_entries(value)
        self.assertEqual(value, original)
        normalized[0]['title'] = 'Changed'
        normalized[0]['tags'].append('new')
        normalized.append({'title': 'Added', 'tags': []})
        self.assertEqual(value, original)

    def test_default_tags_are_independent(self):
        normalized = normalize_entries([{'title': 'One'}, {'title': 'Two'}])
        normalized[0]['tags'].append('new')
        self.assertEqual(normalized[1]['tags'], [])

    def test_invalid_collections_raise_value_error(self):
        for value in (None, True, 42, 'notes', {}, (), set(), iter([])):
            with self.subTest(value=value):
                with self.assertRaises(ValueError):
                    normalize_entries(value)

    def test_invalid_entries_raise_value_error(self):
        for entry in (None, True, 42, 'note', [], ()):
            with self.subTest(entry=entry):
                with self.assertRaises(ValueError):
                    normalize_entries([entry])

    def test_invalid_titles_raise_value_error(self):
        entries = [{}] + [
            {'title': title}
            for title in (None, True, 42, [], {}, '', ' \t\n')
        ]
        for entry in entries:
            with self.subTest(entry=entry):
                with self.assertRaises(ValueError):
                    normalize_entries([entry])

    def test_invalid_tags_raise_value_error(self):
        invalid_tags = (None, True, 42, 'tag', {}, ('tag',), {'tag'})
        invalid_members = (None, True, 42, [], {})
        for tags in (*invalid_tags, *(['valid', tag] for tag in invalid_members)):
            with self.subTest(tags=tags):
                with self.assertRaises(ValueError):
                    normalize_entries([{'title': 'Inbox', 'tags': tags}])

    def test_failed_normalization_does_not_mutate_input(self):
        value = [
            {'title': ' Inbox ', 'tags': [' b ', 'a', 'a']},
            {'title': 'Invalid', 'tags': ['valid', None]},
        ]
        original = copy.deepcopy(value)
        with self.assertRaises(ValueError):
            normalize_entries(value)
        self.assertEqual(value, original)

    def test_read_entries_rejects_invalid_json_and_data(self):
        for text in (
            '', '[', '[{"title": "Inbox"},]', 'null', '{}', '"notes"', '42',
            '[null]', '[{}]', '[{"title": " "}]',
            '[{"title": "Inbox", "tags": "home"}]',
            '[{"title": "Inbox"}, {"title": "Invalid", "tags": [null]}]',
        ):
            with self.subTest(text=text):
                with self.assertRaises(ValueError):
                    read_entries(text)

    def test_file_cli_preserves_json_array_output(self):
        project_root = Path(__file__).resolve().parent
        with tempfile.TemporaryDirectory(dir=project_root) as directory:
            path = Path(directory) / 'notes.json'
            path.write_text(json.dumps([
                {'title': ' 中文 ', 'tags': [' z ', 'a', 'a']},
                {'title': '中文'},
            ]), encoding='utf-8')
            result = subprocess.run(
                [sys.executable, '-m', 'notebatch', str(path)],
                cwd=project_root, capture_output=True, text=True, check=False,
            )
        expected = [
            {'title': '中文', 'tags': ['a', 'z']},
            {'title': '中文', 'tags': []},
        ]
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(result.stderr, '')
        self.assertEqual(
            result.stdout, json.dumps(expected, ensure_ascii=False, indent=2) + '\n'
        )

    def test_json_output(self):
        value = [{'title': '中文', 'tags': []}]
        rendered = render_json(value)
        self.assertEqual(json.loads(rendered), value)
        self.assertTrue(rendered.endswith('\n'))
        self.assertIn('中文', rendered)


if __name__ == '__main__':
    unittest.main()
