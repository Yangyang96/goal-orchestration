# NoteBatch
A small local note-export utility using Python's standard library.

Run `python3 -m unittest -v` to test the package.
Public functions: `normalize_entries(entries)`, `read_entries(text)`,
`render_json(entries)`.

## CLI usage

The positional argument `input` accepts a UTF-8 JSON file or `-` to read stdin.
Both sources must contain a JSON array and use the normalization rules below.

```sh
python3 -m notebatch notes.json
python3 -m notebatch notes.json --format json
python3 -m notebatch notes.json --format jsonl
python3 -m notebatch - < notes.json
python3 -m notebatch - --format jsonl --unique < notes.json
```

`--format json|jsonl` defaults to `json`: a JSON array with two-space indentation,
Unicode characters preserved, and one final newline. `jsonl` emits one compact
JSON object per line, with no spaces after commas or colons and Unicode characters
preserved. Every object has a final newline; an empty batch emits zero bytes in
`jsonl` and `[]` followed by a newline in `json`.

By default, all entries are retained. `--unique` works with both output formats
and keeps the first complete object for each normalized `title.casefold()` value,
preserving its title casing, tags, and position. For example, ` Straße ` and
`STRASSE` match after normalization and Unicode case folding: the first title
becomes `Straße`, and the second object's tags are not merged into it.

The whole input is validated before deduplication and output, including later
duplicate entries. Invalid JSON, invalid entries, or a file that cannot be read
produce exit code `2`, empty stdout, and a reason on stderr prefixed with
`input error:` without a traceback. No partial results are emitted when a later
entry fails. Argument usage errors retain argparse's normal usage and error
messages and exit code `2`.

## Input normalization
Input is a list of objects. Each object has a nonempty string title after
stripping whitespace. Tags are an optional list of strings, defaulting to [].
Strip each tag, discard empty tags, deduplicate exactly and sort by Python string
order. Tag matching is case-sensitive. Output contains only title and tags;
unknown fields are ignored. Preserve entry order and duplicate entries, and never
mutate input data. CLI deduplication is applied only when `--unique` is supplied.
Invalid entry collections, titles, or tags raise ValueError. read_entries parses
JSON and applies normalization.

## Development handoff
Phase 1 normalization and phase 2 CLI support are complete. See
[HANDOFF.md](HANDOFF.md) for the agreed contract and verification results.
